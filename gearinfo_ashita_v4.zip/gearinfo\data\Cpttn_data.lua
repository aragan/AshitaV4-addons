return {
    [1]={
        ["Evasion"]=43, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["AGI"]=25, 
        ["DEX"]=28, 
        ["Magic Evasion"]=53, 
        ["id"]=23051, 
        ["MND"]=24, 
        ["Regain"]=3, 
        ["Haste"]=7, 
        ["discription"]="DEF:125 HP+57 MP+23 STR+32 DEX+28 VIT+27 AGI+25 INT+24 MND+24 CHR+24 Accuracy+37 Attack+31 Evasion+43 Magic Evasion+53 \"Magic Def. Bonus\"+2 Haste+7% \"Warding Circle\"+1 \"Meditate\" duration +4 \"Regain\"+3 Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["en"]="Wakido Kabuto +2", 
        ["HP"]=57, 
        ["Accuracy"]=37, 
        ["slots"]={
            [4]="Head"
        }, 
        ["STR"]=32, 
        ["INT"]=24, 
        ["DEF"]=125, 
        ["MP"]=23, 
        ["item_level"]=119, 
        ["CHR"]=24, 
        ["category"]="Armor", 
        ["Magic Def. Bonus"]=2, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=45
        }, 
        ["VIT"]=27, 
        ["Attack"]=31
    }, 
    [2]={
        ["Enmity"]=5, 
        ["en"]="Eihwaz Ring", 
        ["id"]=10798, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="HP+70 Enmity+5  Enhances resistance against \"Death\"", 
        ["HP"]=70, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [3]={
        ["discription"]="DEF:17 Occasionally annuls severe physical damage taken Dark weather: Accuracy+13 Attack+13", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Archon Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=10975, 
        ["DEF"]=17, 
        ["Accuracy"]=13, 
        ["Attack"]=13
    }, 
    [4]={
        ["Cure potency"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Mendi. Earring", 
        ["DEF"]=4, 
        ["MP"]=2, 
        ["id"]=28474, 
        ["discription"]="DEF:4 MP+30 \"Conserve MP\"+2 \"Cure\" potency +5% \"Cure\" spellcasting time -5%", 
        ["Conserve MP"]=2, 
        ["Cure spellcasting time"]=-5
    }, 
    [5]={
        ["discription"]="Occasionally annuls magic damage taken Enhances resistance against \"Death\" On Darksdays:  \"Magic Def. Bonus\"", 
        ["id"]=14646, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Shadow Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [6]={
        ["discription"]="DEF:143 HP+61 STR+33 DEX+30 VIT+26 AGI+24 INT+20 MND+17 CHR+20 Accuracy+40 Attack+40 Magic Accuracy+40 Evasion+91 Magic Evasion+69 \"Magic Def. Bonus\"+12 Haste+6% \"Triple Attack\"+3% \"Killer\" effects +2 Critical hit rate+4% \"TP Bonus\"+200 Physical Damage taken-7% Pet: Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50", 
        ["item_level"]=119, 
        ["id"]=23758, 
        ["Attack"]=53, 
        ["Evasion"]=91, 
        ["Skillchain Damage"]=15, 
        ["Aug_DB_Source"]=true, 
        ["PDT"]=-10, 
        ["Double Attack"]=15, 
        ["DEX"]=30, 
        ["DEF"]=143, 
        ["en"]="Mpaca's Cap", 
        ["Critical hit rate"]=4, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["Triple Attack"]=3, 
        ["MND"]=17, 
        ["AGI"]=24, 
        ["HP"]=61, 
        ["category"]="Armor", 
        ["INT"]=20, 
        ["TP Bonus"]=200, 
        ["VIT"]=26, 
        ["Accuracy"]=75, 
        ["CHR"]=20, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Unity Ranking Bonus Applied"]="Attack + 20", 
        ["Magic Def. Bonus"]=12, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["Ranged Accuracy"]=50, 
        ["Haste"]=6, 
        ["STR"]=63, 
        ["Killer"]=2, 
        ["Magic Accuracy"]=65, 
        ["_aug_only"]={
            ["Skillchain Damage"]=15, 
            ["STR"]=30, 
            ["Double Attack"]=15, 
            ["Attack"]=50, 
            ["Magic Accuracy"]=15, 
            ["Accuracy"]=35, 
            ["PDT"]=-10
        }, 
        ["Magic Evasion"]=69, 
        ["DT"]=-7
    }, 
    [7]={
        ["discription"]="Right ear: \"Double Attack\"+8% \"Subtle Blow\"+6", 
        ["Magic Accuracy"]=11, 
        ["_aug_only"]={
            ["Accuracy"]=11, 
            ["Magic Accuracy"]=11
        }, 
        ["category"]="Armor", 
        ["augments"]={
            [1]="System: 1 ID: 1676 Val: 0", 
            [2]="Accuracy+11", 
            [3]="Mag. Acc.+11", 
            [4]="Crit.hit rate+3", 
            [5]="none"
        }, 
        ["en"]="Boii Earring +1", 
        ["Double Attack"]=8, 
        ["Extdata Augments Applied"]=true, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Subtle Blow"]=6, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["Accuracy"]=11, 
        ["id"]=25421, 
        ["Attack"]=8
    }, 
    [8]={
        ["discription"]="DMG:333 Delay:480 DEX+20 INT+20 MND+20 Accuracy+40 Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+21 Magic Damage+226 Polearm skill +250 Parrying skill +250 Magic Accuracy skill +250 \"Impulse Drive\" \"Impulse Drive\" damage +40% Weapon Skill: Increases critical hit rate based on amount of TP consumed", 
        ["MND"]=20, 
        ["skill"]="Polearm", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=20, 
        ["Attack"]=30, 
        ["en"]="Shining One", 
        ["Magic Damage"]=226, 
        ["item_level"]=119, 
        ["delay"]=480, 
        ["id"]=21883, 
        ["Parrying skill"]=250, 
        ["slots"]={
            [0]="Main"
        }, 
        ["Polearm skill"]=250, 
        ["Accuracy"]=40, 
        ["INT"]=20, 
        ["Magic Atk. Bonus"]=21, 
        ["category"]="Weapon", 
        ["damage"]=333, 
        ["Magic Accuracy"]=40
    }, 
    [9]={
        ["MDT"]=1, 
        ["category"]="Armor", 
        ["Unity Ranking Bonus Applied"]="VIT + 15", 
        ["en"]="Gelatinous Ring +1", 
        ["_aug_only"]={
            ["HP"]=100, 
            ["VIT"]=15
        }, 
        ["HP"]=100, 
        ["VIT"]=15, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["discription"]="Physical Damage taken-7% Magic damage taken +1% Unity Ranking: HP+10～35", 
        ["id"]=10769, 
        ["DT"]=-7
    }, 
    [10]={
        ["Evasion"]=78, 
        ["DEX"]=24, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["Magic Damage"]=21, 
        ["Accuracy"]=51, 
        ["id"]=23089, 
        ["AGI"]=20, 
        ["Magic Evasion"]=115, 
        ["Haste"]=6, 
        ["item_level"]=119, 
        ["MND"]=33, 
        ["en"]="Leth. Chappel +2", 
        ["STR"]=20, 
        ["HP"]=56, 
        ["Magic Accuracy"]=51, 
        ["VIT"]=20, 
        ["slots"]={
            [4]="Head"
        }, 
        ["INT"]=33, 
        ["DEF"]=116, 
        ["MP"]=85, 
        ["discription"]="DEF:116 HP+56 MP+85 STR+20 DEX+24 VIT+20 AGI+20 INT+33 MND+33 CHR+25 Accuracy+51 Attack+51 Magic Accuracy+51 \"Magic Atk. Bonus\"+51 Magic Damage+21 Evasion+78 Magic Evasion+115 \"Magic Def. Bonus\"+9 Enfeebling magic casting time -16% Haste+6% Damage taken-9% Set: Augments \"Composure\"", 
        ["CHR"]=25, 
        ["category"]="Armor", 
        ["Attack"]=51, 
        ["Magic Def. Bonus"]=9, 
        ["Magic Atk. Bonus"]=51, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Composure"]=2
                }, 
                [3]={
                    ["Composure"]=3
                }, 
                [4]={
                    ["Composure"]=4
                }, 
                [5]={
                    ["Composure"]=5
                }
            }, 
            ["set id"]=290
        }, 
        ["DT"]=-9
    }, 
    [11]={
        ["discription"]="HP+40 Enmity+4 \"Counter\"+3", 
        ["category"]="Armor", 
        ["en"]="Cryptic Earring", 
        ["HP"]=40, 
        ["Enmity"]=4, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=28483, 
        ["Counter"]=3
    }, 
    [12]={
        ["discription"]="DEF:10 Attack+20 \"Store TP\"+7 \"Resist Stun\"+10", 
        ["category"]="Armor", 
        ["en"]="Anu Torque", 
        ["Store TP"]=7, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [14]="DRG", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=10, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=26029, 
        ["Attack"]=20
    }, 
    [13]={
        ["discription"]="Accuracy-10 Attack+10 \"Double Attack\"+2%", 
        ["category"]="Weapon", 
        ["en"]="Focal Orb", 
        ["skill"]="(N/A)", 
        ["Double Attack"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=21345, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["Accuracy"]=-10, 
        ["Attack"]=2
    }, 
    [14]={
        ["discription"]="STR+10 Attack+30 Ranged Attack+30 Citizen of Bastok: \"Regain\"+2 ", 
        ["category"]="Armor", 
        ["en"]="Rep. Plat. Medal", 
        ["STR"]=10, 
        ["Ranged Attack"]=30, 
        ["Regain"]=2, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=25415, 
        ["Attack"]=30
    }, 
    [15]={
        ["discription"]="MND+5 Magic Accuracy+8 All magic skills +5", 
        ["category"]="Armor", 
        ["en"]="Stikini Ring", 
        ["All magic skills"]=5, 
        ["MND"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26183, 
        ["Magic Accuracy"]=8
    }, 
    [16]={
        ["Evasion"]=102, 
        ["discription"]="DEF:189 HP+136 MP+88 STR+35 DEX+24 VIT+35 AGI+33 INT+42 MND+37 CHR+35 Accuracy+40 Attack+30 Ranged Accuracy+40 Ranged Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+30 Evasion+102 Magic Evasion+139 \"Magic Def. Bonus\"+8 Haste+3% Magic burst damage +7 \"Skillchain Bonus\"+7 Damage taken-9% Pet: Acc.+50 Ranged Acc.+50 Magic Acc.+50", 
        ["Ranged Attack"]=60, 
        ["id"]=23768, 
        ["en"]="Nyame Mail", 
        ["PDT"]=-10, 
        ["Weapon skill damage"]=12, 
        ["Double Attack"]=5, 
        ["Magic Atk. Bonus"]=30, 
        ["Attack"]=80, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["item_level"]=119, 
        ["Store TP"]=10, 
        ["DEX"]=44, 
        ["AGI"]=33, 
        ["MND"]=37, 
        ["category"]="Armor", 
        ["DEF"]=189, 
        ["HP"]=136, 
        ["Aug_DB_Source"]=true, 
        ["Magic Def. Bonus"]=8, 
        ["VIT"]=40, 
        ["Accuracy"]=80, 
        ["augments"]={
            [1]="Path: B"
        }, 
        ["Skillchain Bonus"]=7, 
        ["Unity Ranking Bonus Applied"]="Attack + 20", 
        ["CHR"]=35, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Magic Burst Damage"]=7, 
        ["Ranged Accuracy"]=40, 
        ["Magic Evasion"]=139, 
        ["STR"]=40, 
        ["INT"]=42, 
        ["_aug_only"]={
            ["Ranged Attack"]=30, 
            ["STR"]=5, 
            ["VIT"]=5, 
            ["Store TP"]=10, 
            ["Double Attack"]=5, 
            ["Attack"]=50, 
            ["DEX"]=20, 
            ["Weapon skill damage"]=12, 
            ["Accuracy"]=30, 
            ["PDT"]=-10
        }, 
        ["Haste"]=3, 
        ["Magic Accuracy"]=50, 
        ["MP"]=88, 
        ["DT"]=-9
    }, 
    [17]={
        ["discription"]="DEF:8  Enhances \"Fast Cast\" effect Haste+3% Occ. quickens spellcasting +3%", 
        ["category"]="Armor", 
        ["en"]="Witful Belt", 
        ["Haste"]=3, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=10826, 
        ["Quick Cast"]=3
    }, 
    [18]={
        ["Magic Burst Damage II"]=5, 
        ["en"]="Mujin Band", 
        ["Skillchain Bonus"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="\"Skillchain Bonus\"+5 Magic burst damage II +5", 
        ["id"]=11672, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [19]={
        ["discription"]="STR+5 \"Double Attack\"+6% \"Subtle Blow\"+3 Melee attack: Consumes 20 MP and reduces enmity by 20", 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["STP"]=5, 
        ["category"]="Armor", 
        ["STR"]=5, 
        ["en"]="Schere Earring", 
        ["Double Attack"]=6, 
        ["_aug_only"]={
            ["STP"]=5, 
            ["Attack"]=15, 
            ["Accuracy"]=15
        }, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Subtle Blow"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [8]="DRK", 
            [12]="SAM", 
            [18]="PUP"
        }, 
        ["Accuracy"]=15, 
        ["Aug_DB_Source"]=true, 
        ["id"]=26116, 
        ["Attack"]=21
    }, 
    [20]={
        ["discription"]="MP+15～30 INT+2～5 MND+2～5 Enmity-3", 
        ["INT"]=2, 
        ["MND"]=2, 
        ["category"]="Armor", 
        ["en"]="Tamas Ring", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15545, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["MP"]=15, 
        ["Enmity"]=-3
    }, 
    [21]={
        ["Evasion"]=82, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["STR"]=24, 
        ["DEX"]=45, 
        ["AGI"]=22, 
        ["id"]=23996, 
        ["MND"]=40, 
        ["item_level"]=119, 
        ["discription"]="DEF:128 HP+60 STR+24 DEX+45 VIT+40 AGI+22 INT+20 MND+40 CHR+30 Accuracy+58 Magic Accuracy+58 Evasion+82 Magic Evasion+71 \"Magic Def. Bonus\"+3 Haste+4% \"Store TP\"+7 \"Hasso\"+4 Able to fully appreciate rice balls Set: Accuracy+ Ranged Accuracy+ Magic Accuracy+", 
        ["Store TP"]=7, 
        ["en"]="Wakido Kote +4", 
        ["HP"]=60, 
        ["Accuracy"]=58, 
        ["Magic Evasion"]=71, 
        ["INT"]=20, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=128, 
        ["Haste"]=4, 
        ["CHR"]=30, 
        ["category"]="Armor", 
        ["Magic Def. Bonus"]=3, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=45
        }, 
        ["VIT"]=40, 
        ["Magic Accuracy"]=58
    }, 
    [22]={
        ["discription"]="HP+70 Accuracy+30 Attack+30 Weapon skill DEX +10%", 
        ["category"]="Weapon", 
        ["en"]="Utu Grip", 
        ["skill"]="(N/A)", 
        ["HP"]=70, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG", 
            [22]="RUN"
        }, 
        ["id"]=22212, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["Accuracy"]=30, 
        ["Attack"]=30
    }, 
    [23]={
        ["discription"]="DEF:43 HP+25 MP+25 +20  +20 +20 +20  Movement speed +12%", 
        ["jobs"]={
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [11]="RNG", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Crimson Cuisses", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=14280, 
        ["DEF"]=43, 
        ["MP"]=25, 
        ["HP"]=25
    }, 
    [24]={
        ["discription"]="MP+20 Magic Accuracy+5 \"Magic Atk. Bonus\"+11", 
        ["category"]="Armor", 
        ["en"]="Eddy Necklace", 
        ["Magic Atk. Bonus"]=11, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=28401, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["MP"]=20, 
        ["Magic Accuracy"]=5
    }, 
    [25]={
        ["Evasion"]=81, 
        ["DEX"]=24, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["Refresh"]=3, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enfeebling Magic duration", 
            [4]="Magic Accuracy"
        }, 
        ["Accuracy"]=42, 
        ["Magic Evasion"]=135, 
        ["Haste"]=6, 
        ["discription"]="DEF:123 HP+91 MP+87 STR+27 DEX+24 VIT+29 AGI+24 INT+34 MND+42 CHR+29 Accuracy+42 Attack+72 Magic Accuracy+42 Evasion+81 Magic Evasion+135 \"Magic Def. Bonus\"+8 Enfeebling magic skill +27 Haste+6% \"Refresh\"+3 Weapon skill damage +9%", 
        ["MND"]=42, 
        ["en"]="Viti. Chapeau +4", 
        ["item_level"]=119, 
        ["HP"]=91, 
        ["AGI"]=24, 
        ["STR"]=27, 
        ["slots"]={
            [4]="Head"
        }, 
        ["INT"]=34, 
        ["DEF"]=123, 
        ["MP"]=87, 
        ["id"]=23922, 
        ["CHR"]=29, 
        ["category"]="Armor", 
        ["Magic Def. Bonus"]=8, 
        ["VIT"]=29, 
        ["Attack"]=72, 
        ["Magic Accuracy"]=42
    }, 
    [26]={
        ["Evasion"]=49, 
        ["DEX"]=32, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["Magic Evasion"]=53, 
        ["Accuracy"]=54, 
        ["id"]=25569, 
        ["AGI"]=16, 
        ["Haste"]=4, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Store TP"]=13, 
        ["MND"]=12, 
        ["en"]="Flam. Zucchetto +2", 
        ["_aug_only"]={
            ["Store TP"]=7, 
            ["Accuracy"]=10, 
            ["Attack"]=4
        }, 
        ["HP"]=80, 
        ["discription"]="DEF:123 HP+80 MP+20 STR+36 DEX+32 VIT+24 AGI+16 INT+12 MND+12 CHR+12 Accuracy+44 Magic Accuracy+44 Evasion+49 Magic Evasion+53 \"Magic Def. Bonus\"+3 Haste+4% \"Triple Attack\"+5% \"Store TP\"+6 Set: Increases Strength, Dexterity, and Vitality", 
        ["VIT"]=24, 
        ["Unity Ranking Bonus Applied"]="Accuracy + 10", 
        ["INT"]=12, 
        ["STR"]=36, 
        ["MP"]=20, 
        ["DEF"]=123, 
        ["item_level"]=119, 
        ["CHR"]=12, 
        ["category"]="Armor", 
        ["Attack"]=9, 
        ["Magic Def. Bonus"]=3, 
        ["Triple Attack"]=5, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["DEX"]=8, 
                    ["STR"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["DEX"]=16, 
                    ["STR"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["DEX"]=24, 
                    ["STR"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["DEX"]=32, 
                    ["STR"]=32, 
                    ["VIT"]=32
                }
            }, 
            ["set id"]=218
        }, 
        ["Magic Accuracy"]=44
    }, 
    [27]={
        ["Evasion"]=36, 
        ["DEX"]=46, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["AGI"]=8, 
        ["id"]=25835, 
        ["Accuracy"]=43, 
        ["Magic Evasion"]=48, 
        ["Haste"]=4, 
        ["Store TP"]=6, 
        ["MND"]=24, 
        ["en"]="Flam. Manopolas +2", 
        ["Critical hit rate"]=8, 
        ["HP"]=60, 
        ["discription"]="DEF:111 HP+60 MP+15 STR+23 DEX+46 VIT+35 AGI+8 INT+7 MND+24 CHR+17 Accuracy+43 Magic Accuracy+43 Evasion+36 Magic Evasion+48 \"Magic Def. Bonus\"+2 Haste+4% \"Store TP\"+6 Critical hit rate+8% Set: Increases Strength, Dexterity, and Vitality", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["STR"]=23, 
        ["INT"]=7, 
        ["DEF"]=111, 
        ["MP"]=15, 
        ["item_level"]=119, 
        ["CHR"]=17, 
        ["category"]="Armor", 
        ["Magic Def. Bonus"]=2, 
        ["VIT"]=35, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["DEX"]=8, 
                    ["STR"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["DEX"]=16, 
                    ["STR"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["DEX"]=24, 
                    ["STR"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["DEX"]=32, 
                    ["STR"]=32, 
                    ["VIT"]=32
                }
            }, 
            ["set id"]=218
        }, 
        ["Magic Accuracy"]=43
    }, 
    [28]={
        ["Attack"]=-2, 
        ["en"]="Reraise Earring", 
        ["id"]=14790, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Attack-2 Evasion+2 Enchantment: \"Reraise\"", 
        ["Evasion"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [29]={
        ["discription"]="DEF:18 \"Meditate\" effect duration +8 \"Skillchain Bonus\" +3", 
        ["_aug_only"]={
            ["Attack"]=20, 
            ["STR"]=30, 
            ["Accuracy"]=20, 
            ["PDT"]=-10
        }, 
        ["STR"]=30, 
        ["category"]="Armor", 
        ["Skillchain Bonus"]=3, 
        ["en"]="Smertrios's Mantle", 
        ["id"]=26257, 
        ["Attack"]=20, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Extdata Augments Applied"]=true, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["Accuracy"]=20, 
        ["DEF"]=18, 
        ["augments"]={
            [1]="STR+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="STR+10", 
            [4]="Weapon skill damage +10%", 
            [5]="Phys. dmg. taken-10%"
        }, 
        ["PDT"]=-10
    }, 
    [30]={
        ["Ranged Attack"]=45, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["AGI"]=30, 
        ["id"]=24041, 
        ["Accuracy"]=59, 
        ["Magic Evasion"]=120, 
        ["Haste"]=5, 
        ["Store TP"]=9, 
        ["MND"]=29, 
        ["en"]="Wakido Haidate +4", 
        ["Evasion"]=82, 
        ["HP"]=95, 
        ["item_level"]=119, 
        ["discription"]="DEF:152 HP+95 STR+44 VIT+29 AGI+30 INT+37 MND+29 CHR+22 Accuracy+59 Attack+45 Ranged Attack+45 Magic Accuracy+59 Evasion+82 Magic Evasion+120 \"Magic Def. Bonus\"+5 Parrying skill +20 Haste+5% \"Store TP\"+9 Weapon skill damage +12% Set: Accuracy+ Ranged Accuracy+ Magic Accuracy+", 
        ["INT"]=37, 
        ["CHR"]=22, 
        ["STR"]=44, 
        ["DEF"]=152, 
        ["Parrying skill"]=20, 
        ["Magic Def. Bonus"]=5, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=45
        }, 
        ["category"]="Armor", 
        ["VIT"]=29, 
        ["Attack"]=45, 
        ["Magic Accuracy"]=59
    }, 
    [31]={
        ["Evasion"]=67, 
        ["en"]="Leth. Fuseau +2", 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["AGI"]=25, 
        ["id"]=23290, 
        ["Accuracy"]=53, 
        ["Magic Evasion"]=152, 
        ["Haste"]=5, 
        ["discription"]="DEF:127 HP+65 MP+107 STR+33 VIT+15 AGI+25 INT+43 MND+38 CHR+25 Accuracy+53 Attack+53 Magic Accuracy+53 \"Magic Atk. Bonus\"+53 Magic Damage+23 Evasion+67 Magic Evasion+152 \"Magic Def. Bonus\"+9 Haste+5% Magic burst damage +10 \"Refresh\" potency +3 Set: Augments \"Composure\"", 
        ["MND"]=38, 
        ["item_level"]=119, 
        ["STR"]=33, 
        ["HP"]=65, 
        ["Magic Damage"]=23, 
        ["Magic Accuracy"]=53, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["INT"]=43, 
        ["DEF"]=127, 
        ["MP"]=107, 
        ["Magic Burst Damage"]=10, 
        ["CHR"]=25, 
        ["category"]="Armor", 
        ["VIT"]=15, 
        ["Magic Def. Bonus"]=9, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Composure"]=2
                }, 
                [3]={
                    ["Composure"]=3
                }, 
                [4]={
                    ["Composure"]=4
                }, 
                [5]={
                    ["Composure"]=5
                }
            }, 
            ["set id"]=290
        }, 
        ["Magic Atk. Bonus"]=53, 
        ["Attack"]=53
    }, 
    [32]={
        ["skill"]="(N/A)", 
        ["en"]="Knobkierrie", 
        ["id"]=22281, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["discription"]="Attack+23 Weapon skill damage +6%", 
        ["Attack"]=23, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG", 
            [22]="RUN"
        }
    }, 
    [33]={
        ["Evasion"]=24, 
        ["AGI"]=21, 
        ["Magic Evasion"]=80, 
        ["id"]=27301, 
        ["STR"]=29, 
        ["Accuracy"]=25, 
        ["Extdata Augments Applied"]=true, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["MND"]=17, 
        ["Store TP"]=13, 
        ["Haste"]=5, 
        ["item_level"]=119, 
        ["Ranged Attack"]=33, 
        ["_aug_only"]={
            ["Store TP"]=5, 
            ["Accuracy"]=25, 
            ["PDT"]=-4
        }, 
        ["HP"]=50, 
        ["augments"]={
            [1]="Accuracy+25", 
            [2]="\"Store TP\"+5", 
            [3]="Phys. dmg. taken -4"
        }, 
        ["Double Attack"]=4, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["discription"]="DEF:128 HP+50 STR+29 VIT+15 AGI+21 INT+30 MND+17 CHR+11 Attack+33 Ranged Attack+33 Evasion+24 Magic Evasion+80 \"Magic Def. Bonus\"+3 Haste+5% \"Double Attack\"+4% \"Store TP\"+8 \"Skillchain Bonus\"+11 Set: Increases Attack", 
        ["DEF"]=128, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Attack"]=20
                }, 
                [3]={
                    ["Attack"]=30
                }, 
                [4]={
                    ["Attack"]=40
                }, 
                [5]={
                    ["Attack"]=50
                }
            }, 
            ["set id"]=239
        }, 
        ["en"]="Ryuo Hakama +1", 
        ["VIT"]=15, 
        ["INT"]=30, 
        ["Magic Def. Bonus"]=3, 
        ["Skillchain Bonus"]=11, 
        ["CHR"]=11, 
        ["PDT"]=-4, 
        ["category"]="Armor", 
        ["Attack"]=4
    }, 
    [34]={
        ["Enmity"]=4, 
        ["en"]="Odium Ring", 
        ["DEF"]=10, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:10 Enmity+4", 
        ["id"]=11643, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [35]={
        ["Ranged Attack"]=79, 
        ["DEX"]=30, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["Snapshot"]=5, 
        ["Accuracy"]=45, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Ikishoten\" effect", 
            [4]="none"
        }, 
        ["id"]=23409, 
        ["Haste"]=7, 
        ["Ranged Accuracy"]=45, 
        ["Store TP"]=8, 
        ["MND"]=29, 
        ["en"]="Sakonji Kabuto +3", 
        ["item_level"]=119, 
        ["HP"]=78, 
        ["Evasion"]=53, 
        ["VIT"]=32, 
        ["Attack"]=79, 
        ["INT"]=29, 
        ["slots"]={
            [4]="Head"
        }, 
        ["MP"]=43, 
        ["DEF"]=135, 
        ["Magic Evasion"]=63, 
        ["CHR"]=29, 
        ["category"]="Armor", 
        ["AGI"]=30, 
        ["Magic Def. Bonus"]=4, 
        ["discription"]="DEF:135 HP+78 MP+43 STR+34 DEX+30 VIT+32 AGI+30 INT+29 MND+29 CHR+29 Accuracy+45 Attack+79 Ranged Accuracy+45 Ranged Attack+79 Magic Accuracy+37 Evasion+53 Magic Evasion+63 \"Magic Def. Bonus\"+4 Haste+7% \"Snapshot\"+5 \"Store TP\"+8", 
        ["STR"]=34, 
        ["Magic Accuracy"]=37
    }, 
    [36]={
        ["Attack"]=10, 
        ["Ranged Accuracy"]=10, 
        ["discription"]="DEF:14 HP+35 MP+35 Attack+10 Accuracy+10 Ranged Attack+10 Ranged Accuracy+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Regen\"+2", 
        ["MP"]=35, 
        ["category"]="Armor", 
        ["Magic Atk. Bonus"]=10, 
        ["en"]="Sanctity Necklace", 
        ["HP"]=35, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=14, 
        ["Ranged Attack"]=10, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Regen"]=2, 
        ["id"]=26023, 
        ["Accuracy"]=10, 
        ["Magic Accuracy"]=10
    }, 
    [37]={
        ["Evasion"]=52, 
        ["Magic Evasion"]=80, 
        ["DEX"]=28, 
        ["id"]=27383, 
        ["discription"]="DEF:79 HP+15 STR+14 DEX+16 VIT+15 AGI+33 MND+11 CHR+28 Evasion+52 Magic Evasion+80 \"Magic Def. Bonus\"+3 Haste+4% \"Double Attack\"+4% \"Fast Cast\"+8% \"Store TP\"+8 \"Conserve MP\"+8 Set: Increases Accuracy", 
        ["Accuracy"]=12, 
        ["Extdata Augments Applied"]=true, 
        ["jobs"]={
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [11]="RNG", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["MND"]=31, 
        ["Store TP"]=8, 
        ["Haste"]=4, 
        ["item_level"]=119, 
        ["Fast Cast"]=8, 
        ["_aug_only"]={
            ["MND"]=20, 
            ["DEX"]=12, 
            ["Accuracy"]=12
        }, 
        ["HP"]=15, 
        ["en"]="Carmine Greaves +1", 
        ["Double Attack"]=4, 
        ["STR"]=14, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=20
                }, 
                [3]={
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=40
                }, 
                [5]={
                    ["Accuracy"]=50
                }
            }, 
            ["set id"]=51
        }, 
        ["DEF"]=79, 
        ["Conserve MP"]=8, 
        ["MP"]=8, 
        ["VIT"]=15, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Magic Def. Bonus"]=3, 
        ["augments"]={
            [1]="Accuracy+12", 
            [2]="DEX+12", 
            [3]="MND+20"
        }, 
        ["CHR"]=28, 
        ["AGI"]=33, 
        ["category"]="Armor", 
        ["Attack"]=4
    }, 
    [38]={
        ["Ranged Attack"]=32, 
        ["DEX"]=19, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEF"]=88, 
        ["Magic Evasion"]=80, 
        ["augments"]={
            [1]="HP+65", 
            [2]="\"Store TP\"+5", 
            [3]="\"Subtle Blow\"+8"
        }, 
        ["AGI"]=38, 
        ["Zanshin"]=5, 
        ["STR"]=27, 
        ["Store TP"]=5, 
        ["MND"]=5, 
        ["en"]="Ryuo Sune-Ate +1", 
        ["_aug_only"]={
            ["Store TP"]=5, 
            ["HP"]=65, 
            ["Subtle Blow"]=8
        }, 
        ["HP"]=83, 
        ["Extdata Augments Applied"]=true, 
        ["VIT"]=11, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Attack"]=20
                }, 
                [3]={
                    ["Attack"]=30
                }, 
                [4]={
                    ["Attack"]=40
                }, 
                [5]={
                    ["Attack"]=50
                }
            }, 
            ["set id"]=239
        }, 
        ["Haste"]=3, 
        ["Subtle Blow"]=8, 
        ["Evasion"]=55, 
        ["CHR"]=19, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["Magic Def. Bonus"]=2, 
        ["id"]=27472, 
        ["discription"]="DEF:88 HP+18 STR+27 DEX+19 VIT+11 AGI+38 MND+5 CHR+19 Attack+32 Ranged Attack+32 Evasion+55 Magic Evasion+80 \"Magic Def. Bonus\"+2 Haste+3% \"Zanshin\"+5 Zanshin: Occasionally attacks twice +11% Set: Increases Attack", 
        ["Attack"]=32
    }, 
    [39]={
        ["discription"]="DEF:1", 
        ["category"]="Armor", 
        ["Ranged Accuracy"]=4, 
        ["en"]="Mecisto. Mantle", 
        ["_aug_only"]={
            ["DEF"]=6, 
            ["Ranged Accuracy"]=4, 
            ["HP"]=29
        }, 
        ["HP"]=29, 
        ["Extdata Augments Applied"]=true, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["augments"]={
            [1]="Cap. Point+43%", 
            [2]="HP+29", 
            [3]="Rng.Acc.+4", 
            [4]="DEF+6", 
            [5]="none"
        }, 
        ["DEF"]=7, 
        ["id"]=27596
    }, 
    [40]={
        ["discription"]="Magic Critical hit rate+5% Bonus damage added to magic burst", 
        ["id"]=28582, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Locus Ring", 
        ["Critical hit rate"]=5, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [41]={
        ["Cure potency"]=11, 
        ["Magic Accuracy"]=11, 
        ["Extdata Augments Applied"]=true, 
        ["category"]="Armor", 
        ["_aug_only"]={
            ["Accuracy"]=11, 
            ["Magic Accuracy"]=11, 
            ["DT"]=-3
        }, 
        ["en"]="Chev. Earring +1", 
        ["augments"]={
            [1]="System: 1 ID: 1676 Val: 0", 
            [2]="Accuracy+11", 
            [3]="Mag. Acc.+11", 
            [4]="Damage taken-3%", 
            [5]="none"
        }, 
        ["Shield skill"]=11, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["discription"]="Right ear: DEF:+22 Shield skill +11 \"Cure\" potency +11%", 
        ["jobs"]={
            [7]="PLD"
        }, 
        ["Accuracy"]=11, 
        ["DEF"]=22, 
        ["id"]=25457, 
        ["DT"]=-3
    }, 
    [42]={
        ["Magic Accuracy"]=5, 
        ["en"]="Archon Ring", 
        ["Magic Atk. Bonus"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Occasionally annuls severe magic damage taken Dark Elemental Magic Accuracy+5 Dark Elemental \"Magic Atk. Bonus\"+5", 
        ["id"]=11674, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [43]={
        ["discription"]="DMG:15 Delay:264 Enchantment: \"Warp\"", 
        ["en"]="Warp Cudgel", 
        ["skill"]="Club", 
        ["delay"]=264, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=17040, 
        ["damage"]=15
    }, 
    [44]={
        ["discription"]="Right ear: \"Fast Cast\"+8% Enhancing magic duration +8%", 
        ["_aug_only"]={
            ["Accuracy"]=11, 
            ["Double Attack"]=3, 
            ["Magic Accuracy"]=11, 
            ["Attack"]=3
        }, 
        ["Magic Accuracy"]=11, 
        ["category"]="Armor", 
        ["augments"]={
            [1]="System: 1 ID: 1676 Val: 0", 
            [2]="Accuracy+11", 
            [3]="Mag. Acc.+11", 
            [4]="\"Dbl.Atk.\"+3", 
            [5]="none"
        }, 
        ["en"]="Leth. Earring +1", 
        ["Double Attack"]=3, 
        ["Fast Cast"]=8, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Accuracy"]=11, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["id"]=25445, 
        ["Extdata Augments Applied"]=true, 
        ["Attack"]=3
    }, 
    [45]={
        ["discription"]="INT+10 \"Magic Atk. Bonus\"+10 Citizen of Windurst: \"Refresh\"+1", 
        ["INT"]=10, 
        ["category"]="Armor", 
        ["en"]="Sibyl Scarf", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Refresh"]=1, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=25416, 
        ["Magic Atk. Bonus"]=10
    }, 
    [46]={
        ["discription"]="Magic Accuracy+3 Enhances \"Fast Cast\" effect", 
        ["id"]=11707, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Estq. Earring", 
        ["Magic Accuracy"]=3, 
        ["category"]="Armor", 
        ["jobs"]={
            [5]="RDM"
        }
    }, 
    [47]={
        ["discription"]="INT+4 MND+4 \"Magic Atk. Bonus\"+8 Magic burst damage +10 \"Resist Charm\"+5", 
        ["MND"]=4, 
        ["category"]="Armor", 
        ["en"]="Mizu. Kubikazari", 
        ["Magic Atk. Bonus"]=8, 
        ["INT"]=4, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=28379, 
        ["Magic Burst Damage"]=10
    }, 
    [48]={
        ["discription"]="Accuracy+30 \"Store TP\"+7", 
        ["category"]="Armor", 
        ["Unity Ranking Bonus Applied"]="PDL + 10", 
        ["en"]="Sam. Nodowa +2", 
        ["Store TP"]=14, 
        ["_aug_only"]={
            ["PDL"]=10, 
            ["Store TP"]=7, 
            ["STR"]=25
        }, 
        ["STR"]=25, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["Accuracy"]=30, 
        ["PDL"]=10, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=25485
    }, 
    [49]={
        ["discription"]="DEF:30 Magic Accuracy+3 Divine magic skill +5 Enfeebling magic skill +5 Haste+2% ", 
        ["category"]="Armor", 
        ["en"]="Nashira Seraweels", 
        ["Haste"]=2, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [16]="BLU"
        }, 
        ["DEF"]=30, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15577, 
        ["Magic Accuracy"]=3
    }, 
    [50]={
        ["discription"]="DMG:25 Delay:407", 
        ["en"]="Uchigatana +1", 
        ["skill"]="Great Katana", 
        ["delay"]=407, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["id"]=16978, 
        ["damage"]=25
    }, 
    [51]={
        ["Evasion"]=22, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["discription"]="DEF:105 HP+27 STR+6 DEX+30 VIT+30 AGI+7 INT+10 MND+26 CHR+20 Accuracy+18 Attack+18 Evasion+22 Magic Evasion+26 \"Magic Def. Bonus\"+1 Haste+4% \"Meditate\" duration +2 Physical Damage taken-4%", 
        ["DEX"]=30, 
        ["STR"]=6, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Blade Bash\" effect", 
            [4]="none"
        }, 
        ["MND"]=26, 
        ["Haste"]=4, 
        ["id"]=26999, 
        ["Magic Evasion"]=26, 
        ["item_level"]=119, 
        ["HP"]=27, 
        ["Accuracy"]=18, 
        ["Attack"]=18, 
        ["INT"]=10, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=105, 
        ["AGI"]=7, 
        ["CHR"]=20, 
        ["category"]="Armor", 
        ["Magic Def. Bonus"]=1, 
        ["en"]="Sakonji Kote +1", 
        ["VIT"]=30, 
        ["DT"]=-4
    }, 
    [52]={
        ["id"]=28452, 
        ["en"]="Fucho-no-Obi", 
        ["DEF"]=10, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:10 MP+30 \"Drain\" and \"Aspir\" potency +8 Latent effect: \"Refresh\"+1", 
        ["MP"]=30, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [53]={
        ["id"]=26030, 
        ["en"]="Erra Pendant", 
        ["DEF"]=6, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:6 Magic Accuracy+17 Dark magic skill +10 \"Absorb\" effect +5% \"Drain\" and \"Aspir\" potency +5", 
        ["Magic Accuracy"]=17, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [54]={
        ["discription"]="DEF:10 VIT+8 CHR+8 \"Resist Charm\"+8 Enmity+9 Unity Ranking: Accuracy+1～5", 
        ["CHR"]=8, 
        ["Enmity"]=9, 
        ["category"]="Armor", 
        ["en"]="Unmoving Collar", 
        ["Unity Ranking Bonus Applied"]="Accuracy + 5", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=10, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=5, 
        ["id"]=27508, 
        ["VIT"]=8
    }, 
    [55]={
        ["Evasion"]=22, 
        ["DEX"]=25, 
        ["jobs"]={
            [3]="WHM", 
            [5]="RDM", 
            [10]="BRD", 
            [20]="SCH"
        }, 
        ["AGI"]=5, 
        ["Magic Evasion"]=37, 
        ["augments"]={
            [1]="MP+60", 
            [2]="\"Conserve MP\"+6", 
            [3]="\"Fast Cast\"+3"
        }, 
        ["STR"]=6, 
        ["Enmity"]=-5, 
        ["Haste"]=3, 
        ["discription"]="DEF:85 HP+20 MP+20 STR+6 DEX+25 VIT+25 AGI+5 INT+19 MND+35 CHR+16 Magic Accuracy+23 Evasion+22 Magic Evasion+37 \"Magic Def. Bonus\"+3 Enfeebling magic skill +15 Haste+3% Enmity-5 \"Cure\" potency +10%", 
        ["MND"]=35, 
        ["en"]="Kaykaus Cuffs", 
        ["_aug_only"]={
            ["Fast Cast"]=3, 
            ["Conserve MP"]=6, 
            ["MP"]=66
        }, 
        ["HP"]=20, 
        ["Extdata Augments Applied"]=true, 
        ["VIT"]=25, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["INT"]=19, 
        ["DEF"]=85, 
        ["Conserve MP"]=6, 
        ["MP"]=86, 
        ["Cure potency"]=10, 
        ["CHR"]=16, 
        ["category"]="Armor", 
        ["Fast Cast"]=3, 
        ["Magic Def. Bonus"]=3, 
        ["item_level"]=119, 
        ["id"]=27121, 
        ["Magic Accuracy"]=23
    }, 
    [56]={
        ["discription"]="Capacity point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["id"]=27557, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Trizek Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [57]={
        ["Evasion"]=61, 
        ["DEX"]=31, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["Magic Evasion"]=100, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Chainspell\" effect", 
            [4]="none"
        }, 
        ["Accuracy"]=40, 
        ["Haste"]=3, 
        ["Fast Cast"]=15, 
        ["discription"]="DEF:146 HP+74 MP+99 STR+31 DEX+31 VIT+31 AGI+31 INT+39 MND+45 CHR+39 Accuracy+40 Attack+65 Magic Accuracy+40 Evasion+61 Magic Evasion+100 \"Magic Def. Bonus\"+8 Healing magic skill +23 Enhancing magic skill +23 Haste+3% \"Fast Cast\"+15% Enhancing magic duration +15%", 
        ["MND"]=45, 
        ["en"]="Viti. Tabard +3", 
        ["item_level"]=119, 
        ["HP"]=74, 
        ["AGI"]=31, 
        ["STR"]=31, 
        ["slots"]={
            [5]="Body"
        }, 
        ["INT"]=39, 
        ["DEF"]=146, 
        ["MP"]=99, 
        ["id"]=23469, 
        ["CHR"]=39, 
        ["category"]="Armor", 
        ["Magic Def. Bonus"]=8, 
        ["VIT"]=31, 
        ["Attack"]=65, 
        ["Magic Accuracy"]=40
    }, 
    [58]={
        ["discription"]="Right ear: Healing magic skill +10 Enmity-7", 
        ["category"]="Armor", 
        ["Extdata Augments Applied"]=true, 
        ["en"]="Ebers Earring", 
        ["_aug_only"]={
            ["Accuracy"]=9, 
            ["Magic Accuracy"]=9
        }, 
        ["augments"]={
            [1]="System: 1 ID: 1676 Val: 0", 
            [2]="Accuracy+9", 
            [3]="Mag. Acc.+9", 
            [4]="none", 
            [5]="none"
        }, 
        ["Enmity"]=-7, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [3]="WHM"
        }, 
        ["Accuracy"]=9, 
        ["id"]=25432, 
        ["Magic Accuracy"]=9
    }, 
    [59]={
        ["Attack"]=-2, 
        ["en"]="Reraise Earring", 
        ["id"]=14790, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Attack-2 Evasion+2 Enchantment: \"Reraise\"", 
        ["Evasion"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [60]={
        ["Evasion"]=56, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["Haste"]=6, 
        ["DEX"]=29, 
        ["AGI"]=29, 
        ["id"]=23379, 
        ["MND"]=37, 
        ["item_level"]=119, 
        ["Fast Cast"]=16, 
        ["discription"]="DEF:116 HP+64 MP+58 STR+29 DEX+29 VIT+29 AGI+29 INT+37 MND+37 CHR+34 Magic Accuracy+54 Evasion+56 Magic Evasion+95 \"Magic Def. Bonus\"+7 Haste+6% Elemental magic skill +17 Magic burst damage +10 \"Fast Cast\"+16% Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["en"]="Atrophy Chapeau +3", 
        ["HP"]=64, 
        ["Magic Evasion"]=95, 
        ["slots"]={
            [4]="Head"
        }, 
        ["STR"]=29, 
        ["INT"]=37, 
        ["DEF"]=116, 
        ["MP"]=58, 
        ["Magic Burst Damage"]=10, 
        ["CHR"]=34, 
        ["category"]="Armor", 
        ["Magic Def. Bonus"]=7, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=7
        }, 
        ["VIT"]=29, 
        ["Magic Accuracy"]=54
    }, 
    [61]={
        ["discription"]="DEF:30 HP+50 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Damage taken-5%", 
        ["category"]="Armor", 
        ["Ranged Accuracy"]=50, 
        ["en"]="Null Loop", 
        ["Magic Accuracy"]=50, 
        ["HP"]=50, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=30, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=50, 
        ["id"]=26042, 
        ["DT"]=-5
    }, 
    [62]={
        ["discription"]="MP+30 Enhances \"Fast Cast\" effect", 
        ["id"]=14812, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Loquac. Earring", 
        ["MP"]=30, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [63]={
        ["Evasion"]=47, 
        ["AGI"]=27, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=7
        }, 
        ["MND"]=39, 
        ["Magic Evasion"]=127, 
        ["discription"]="DEF:128 HP+74 MP+53 STR+35 VIT+22 AGI+27 INT+44 MND+39 CHR+29 Accuracy+49 Evasion+47 Magic Evasion+127 \"Magic Def. Bonus\"+8 Healing magic skill +17 Enhancing magic skill +21 Haste+5% \"Cure\" potency +12% Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["Haste"]=5, 
        ["item_level"]=119, 
        ["HP"]=74, 
        ["id"]=23580, 
        ["Cure potency"]=12, 
        ["STR"]=35, 
        ["DEF"]=128, 
        ["MP"]=53, 
        ["Accuracy"]=49, 
        ["INT"]=44, 
        ["Magic Def. Bonus"]=8, 
        ["CHR"]=29, 
        ["VIT"]=22, 
        ["category"]="Armor", 
        ["en"]="Atrophy Tights +3"
    }, 
    [64]={
        ["discription"]="DEF:15 VIT+4 Physical Damage taken-4% Converts 2% of damage taken to MP", 
        ["category"]="Armor", 
        ["en"]="Flume Belt +1", 
        ["VIT"]=4, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=15, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28437, 
        ["DT"]=-4
    }, 
    [65]={
        ["discription"]="DMG:300 Delay:450 STR+15 DEX+15 Accuracy+40 Attack+30 Magic Accuracy+40 Great Katana skill +255 Parrying skill +255 Magic Accuracy skill +242 \"Double Attack\"+10% \"Meditate\" duration +4", 
        ["Attack"]=10, 
        ["skill"]="Great Katana", 
        ["Great Katana skill"]=255, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["en"]="Gekkei", 
        ["item_level"]=119, 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=450, 
        ["DEX"]=15, 
        ["Accuracy"]=40, 
        ["category"]="Weapon", 
        ["STR"]=15, 
        ["id"]=21979, 
        ["Double Attack"]=10, 
        ["Parrying skill"]=255, 
        ["damage"]=300, 
        ["Magic Accuracy"]=40
    }, 
    [66]={
        ["Pet: Magic Accuracy"]=15, 
        ["SIRD"]=6, 
        ["discription"]="DEF:10 MP+30 Spell interruption rate down 3% Damage taken-10% Pet: Accuracy+15 Ranged Accuracy+15 Magic Accuracy+15", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Ranged Accuracy"]=15, 
        ["en"]="Murky Ring", 
        ["_aug_only"]={
            ["Pet: Magic Accuracy"]=15, 
            ["Pet: Ranged Accuracy"]=15, 
            ["SIRD"]=3, 
            ["Pet: Accuracy"]=15, 
            ["DT"]=-10
        }, 
        ["id"]=26234, 
        ["Pet: Ranged Accuracy"]=15, 
        ["Magic Accuracy"]=15, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["MP"]=30, 
        ["Pet: Accuracy"]=15, 
        ["Aug_DB_Source"]=true, 
        ["DEF"]=10, 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["DT"]=-20
    }, 
    [67]={
        ["discription"]="Experience point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["id"]=26164, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Caliber Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [68]={
        ["discription"]="DEF:1 Enchantment: Emporox's Gift", 
        ["DEF"]=1, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Emporox's Ring", 
        ["id"]=28470, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [69]={
        ["Accuracy"]=7, 
        ["en"]="Patricius Ring", 
        ["id"]=28578, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Accuracy+7 Physical Damage taken-5%", 
        ["DT"]=-5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [70]={
        ["id"]=11698, 
        ["en"]="Hecate's Earring", 
        ["Magic Atk. Bonus"]=6, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="\"Magic Atk. Bonus\"+6 Magic Critical hit rate+3%", 
        ["Critical hit rate"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [71]={
        ["discription"]="Experience point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["id"]=27556, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Echad Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [72]={
        ["Evasion"]=85, 
        ["Ranged Attack"]=60, 
        ["id"]=23782, 
        ["discription"]="DEF:169 HP+114 MP+59 STR+43 VIT+30 AGI+34 INT+44 MND+32 CHR+24 Accuracy+40 Attack+30 Ranged Accuracy+40 Ranged Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+30 Evasion+85 Magic Evasion+150 \"Magic Def. Bonus\"+7 Haste+5% Magic burst damage +6 \"Skillchain Bonus\"+6 Damage taken-8% Pet: Acc.+50 Ranged Acc.+50 Magic Acc.+50", 
        ["Attack"]=80, 
        ["Aug_DB_Source"]=true, 
        ["Weapon skill damage"]=11, 
        ["PDT"]=-10, 
        ["Double Attack"]=5, 
        ["DEX"]=20, 
        ["DEF"]=169, 
        ["item_level"]=119, 
        ["en"]="Nyame Flanchard", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["AGI"]=34, 
        ["MND"]=32, 
        ["category"]="Armor", 
        ["HP"]=114, 
        ["Magic Atk. Bonus"]=30, 
        ["Magic Def. Bonus"]=7, 
        ["VIT"]=30, 
        ["Accuracy"]=80, 
        ["augments"]={
            [1]="Path: B"
        }, 
        ["Skillchain Bonus"]=6, 
        ["Unity Ranking Bonus Applied"]="Attack + 20", 
        ["CHR"]=24, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Magic Burst Damage"]=6, 
        ["Ranged Accuracy"]=40, 
        ["Magic Evasion"]=150, 
        ["STR"]=53, 
        ["INT"]=44, 
        ["_aug_only"]={
            ["Weapon skill damage"]=11, 
            ["Attack"]=50, 
            ["DEX"]=20, 
            ["Double Attack"]=5, 
            ["Accuracy"]=30, 
            ["Ranged Attack"]=30, 
            ["STR"]=10, 
            ["PDT"]=-10
        }, 
        ["Haste"]=5, 
        ["Magic Accuracy"]=50, 
        ["MP"]=59, 
        ["DT"]=-8
    }, 
    [73]={
        ["discription"]="DMG:141 Delay:216 INT+25 MND+25 \"Magic Atk. Bonus\"+16 Magic Damage+124 Club skill +242 Parrying skill +242 Magic Accuracy skill +215 \"Cure\" potency +24% \"Refresh\"+1", 
        ["MND"]=25, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["Refresh"]=1, 
        ["skill"]="Club", 
        ["item_level"]=119, 
        ["Club skill"]=242, 
        ["Magic Damage"]=124, 
        ["delay"]=216, 
        ["id"]=22021, 
        ["Cure potency"]=24, 
        ["INT"]=25, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Parrying skill"]=242, 
        ["category"]="Weapon", 
        ["damage"]=141, 
        ["Magic Atk. Bonus"]=16, 
        ["en"]="Ames"
    }, 
    [74]={
        ["Evasion"]=5, 
        ["en"]="Ethereal Earring", 
        ["discription"]="HP+15 Attack+5 Evasion+5  Converts 3% of damage taken to MP", 
        ["HP"]=15, 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15965, 
        ["Attack"]=5
    }, 
    [75]={
        ["Evasion"]=74, 
        ["DEX"]=54, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["AGI"]=26, 
        ["Accuracy"]=72, 
        ["id"]=25953, 
        ["discription"]="DEF:93 HP+40 MP+10 STR+31 DEX+34 VIT+20 AGI+26 MND+6 CHR+20 Accuracy+42 Magic Accuracy+42 Evasion+74 Magic Evasion+86 \"Magic Def. Bonus\"+5 Haste+2% \"Double Attack\"+6% \"Store TP\"+6 Set: Increases Strength, Dexterity, and Vitality", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Magic Evasion"]=86, 
        ["Store TP"]=6, 
        ["MND"]=6, 
        ["en"]="Flam. Gambieras +2", 
        ["_aug_only"]={
            ["Accuracy"]=30, 
            ["Double Attack"]=10, 
            ["DEX"]=20, 
            ["Attack"]=20, 
            ["PDT"]=-10
        }, 
        ["HP"]=40, 
        ["item_level"]=119, 
        ["VIT"]=20, 
        ["Unity Ranking Bonus Applied"]="Attack + 20", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["DEX"]=8, 
                    ["STR"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["DEX"]=16, 
                    ["STR"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["DEX"]=24, 
                    ["STR"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["DEX"]=32, 
                    ["STR"]=32, 
                    ["VIT"]=32
                }
            }, 
            ["set id"]=218
        }, 
        ["STR"]=31, 
        ["MP"]=10, 
        ["DEF"]=93, 
        ["Attack"]=26, 
        ["CHR"]=20, 
        ["category"]="Armor", 
        ["Double Attack"]=16, 
        ["Magic Def. Bonus"]=5, 
        ["Haste"]=2, 
        ["PDT"]=-10, 
        ["Magic Accuracy"]=42
    }, 
    [76]={
        ["discription"]="MP+70 Magic Accuracy+8 Enmity-2", 
        ["Enmity"]=-2, 
        ["category"]="Armor", 
        ["en"]="Sangoma Ring", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=28580, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["MP"]=70, 
        ["Magic Accuracy"]=8
    }, 
    [77]={
        ["Cure potency"]=2, 
        ["_aug_only"]={
            ["Cure potency"]=2, 
            ["Cure spellcasting time"]=-5
        }, 
        ["Cure spellcasting time"]=-5, 
        ["category"]="Armor", 
        ["id"]=12296, 
        ["en"]="Genbu's Shield", 
        ["Evasion"]=10, 
        ["Extdata Augments Applied"]=true, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["discription"]="DEF:24 -10 +10 Evasion+10  Physical Damage taken-10%", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["augments"]={
            [1]="\"Cure\" potency +2%", 
            [2]="\"Cure\" spellcasting time -5%", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["DEF"]=24, 
        ["DT"]=-10
    }, 
    [78]={
        ["discription"]="DEF:17 Accuracy+15 Attack+15 \"Store TP\"+10", 
        ["_aug_only"]={
            ["Zanshin"]=5, 
            ["Store TP"]=2, 
            ["STR"]=4
        }, 
        ["STR"]=4, 
        ["category"]="Armor", 
        ["Store TP"]=12, 
        ["en"]="Takaha Mantle", 
        ["id"]=28628, 
        ["Zanshin"]=5, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Extdata Augments Applied"]=true, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["Accuracy"]=15, 
        ["DEF"]=17, 
        ["augments"]={
            [1]="STR+4", 
            [2]="\"Zanshin\"+5", 
            [3]="\"Store TP\"+2", 
            [4]="Meditate eff. dur. +5", 
            [5]="none"
        }, 
        ["Attack"]=15
    }, 
    [79]={
        ["discription"]="Capacity point bonus: +200% Maximum duration: 720 minutes Maximum bonus: 30000", 
        ["id"]=28469, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Endorsement Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [80]={
        ["discription"]="Experience point bonus: +50% Skill gains increased by 100% when under 400 skill.", 
        ["id"]=27593, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Jubilee Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [81]={
        ["discription"]="Accuracy+5 Attack+10 \"Store TP\"+3", 
        ["category"]="Weapon", 
        ["en"]="Ginsen", 
        ["Store TP"]=3, 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=21371, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["Accuracy"]=5, 
        ["Attack"]=10
    }, 
    [82]={
        ["discription"]="Accuracy+10 Magic Accuracy+10 \"Subtle Blow\"+5 \"Store TP\"+3", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Digni. Earring", 
        ["Store TP"]=3, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Accuracy"]=10, 
        ["id"]=27547, 
        ["Subtle Blow"]=5, 
        ["Magic Accuracy"]=10
    }, 
    [83]={
        ["discription"]="DEF:7 \"Conserve TP\"+7 TP not depleted when weapon skill used +1% Latent effect: Weapon Skill Accuracy+10 Weapon skill damage +10%", 
        ["DEF"]=7, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Fotia Belt", 
        ["id"]=28420, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [84]={
        ["discription"]="DMG:200 Delay:288 INT+15 MND+15 CHR+15 Accuracy+40 Magic Accuracy+40 \"Magic Atk. Bonus\"+21 Magic Damage+232 Club skill +250 Parrying skill +250 Magic Accuracy skill +250 Main hand: \"Black Halo\" \"Black Halo\" damage +50% Increases magic burst damage based on skillchain length", 
        ["MND"]=15, 
        ["skill"]="Club", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["item_level"]=119, 
        ["en"]="Maxentius", 
        ["Club skill"]=250, 
        ["Magic Damage"]=232, 
        ["delay"]=288, 
        ["id"]=22031, 
        ["Parrying skill"]=250, 
        ["INT"]=15, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Accuracy"]=40, 
        ["CHR"]=15, 
        ["Magic Atk. Bonus"]=21, 
        ["category"]="Weapon", 
        ["damage"]=200, 
        ["Magic Accuracy"]=40
    }, 
    [85]={
        ["discription"]="MND+7 Magic Accuracy+15 Enfeebling magic effect +10", 
        ["category"]="Weapon", 
        ["en"]="Regal Gem", 
        ["skill"]="(N/A)", 
        ["MND"]=7, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["id"]=21396, 
        ["Magic Accuracy"]=15
    }, 
    [86]={
        ["discription"]="DMG:1 Delay:294 Latent effect: Increases rate of critical hits Enchantment: VIT+10", 
        ["en"]="Trollbane", 
        ["skill"]="Throwing", 
        ["delay"]=294, 
        ["category"]="Weapon", 
        ["slots"]={
            [2]="Range"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18694, 
        ["damage"]=1
    }, 
    [87]={
        ["Subtle Blow II"]=5, 
        ["category"]="Armor", 
        ["DEX"]=5, 
        ["en"]="Sherida Earring", 
        ["Store TP"]=5, 
        ["Double Attack"]=5, 
        ["STR"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [14]="DRG", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["discription"]="STR+5 DEX+5 \"Double Attack\"+5% \"Store TP\"+5 \"Subtle Blow II\"+5", 
        ["id"]=26084, 
        ["Attack"]=5
    }, 
    [88]={
        ["discription"]="Right ear: \"Triple Attack\"+4% \"Subtle Blow\"+6", 
        ["augments"]={
            [1]="System: 1 ID: 1676 Val: 0", 
            [2]="Accuracy+11", 
            [3]="Mag. Acc.+11", 
            [4]="\"Store TP\"+3", 
            [5]="none"
        }, 
        ["_aug_only"]={
            ["Store TP"]=3, 
            ["Accuracy"]=11, 
            ["Magic Accuracy"]=11
        }, 
        ["category"]="Armor", 
        ["Store TP"]=3, 
        ["en"]="Skulk. Earring +1", 
        ["Triple Attack"]=4, 
        ["Magic Accuracy"]=11, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Subtle Blow"]=6, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["Accuracy"]=11, 
        ["Extdata Augments Applied"]=true, 
        ["id"]=25451, 
        ["Attack"]=4
    }, 
    [89]={
        ["Evasion"]=20, 
        ["id"]=21567, 
        ["jobs"]={
            [5]="RDM", 
            [6]="THF", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=15, 
        ["Dagger skill"]=255, 
        ["AGI"]=15, 
        ["item_level"]=119, 
        ["Triple Attack"]=6, 
        ["discription"]="DMG:133 Delay:200 DEX+15 AGI+15 Accuracy+40 Attack+30 Magic Accuracy+40 Evasion+20 Dagger skill +255 Parrying skill +255 Magic Accuracy skill +242 Haste+2% \"Triple Attack\"+6% \"Waltz\" potency +10% Critical hit rate +5%", 
        ["en"]="Gleti's Knife", 
        ["Waltz"]=10, 
        ["Critical hit rate"]=5, 
        ["delay"]=200, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Haste"]=2, 
        ["Accuracy"]=40, 
        ["skill"]="Dagger", 
        ["Attack"]=6, 
        ["damage"]=133, 
        ["Parrying skill"]=255, 
        ["Magic Accuracy"]=40
    }, 
    [90]={
        ["discription"]="DMG:166 Delay:240 DEX+15 INT+15 MND+15 Accuracy+40 Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+16 Magic Damage+217 Sword skill +250 Parrying skill +250 Magic Accuracy skill +250 Main hand: \"Savage Blade\" \"Savage Blade\" damage +15% Weapon Skill: Attack Bonus based on the number of upgrades", 
        ["MND"]=15, 
        ["Attack"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["DEX"]=15, 
        ["Magic Damage"]=217, 
        ["en"]="Naegling", 
        ["Magic Atk. Bonus"]=16, 
        ["item_level"]=119, 
        ["delay"]=240, 
        ["skill"]="Sword", 
        ["Accuracy"]=40, 
        ["INT"]=15, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=21621, 
        ["category"]="Weapon", 
        ["damage"]=166, 
        ["Sword skill"]=250, 
        ["Parrying skill"]=250, 
        ["Magic Accuracy"]=40
    }, 
    [91]={
        ["discription"]="DMG:160 Delay:240 HP+100 MP+40 VIT+15 MND+15 Accuracy+40 Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+20 Magic Damage+217 Sword skill +248 Parrying skill +248 Magic Accuracy skill +248 \"Fast Cast\"+10% \"Phalanx\" received +5 Damage taken -10%", 
        ["Fast Cast"]=10, 
        ["jobs"]={
            [5]="RDM", 
            [7]="PLD", 
            [16]="BLU"
        }, 
        ["Magic Atk. Bonus"]=20, 
        ["HP"]=100, 
        ["MND"]=15, 
        ["Magic Accuracy"]=40, 
        ["Attack"]=30, 
        ["item_level"]=119, 
        ["en"]="Sakpata's Sword", 
        ["delay"]=240, 
        ["id"]=21637, 
        ["VIT"]=15, 
        ["Magic Damage"]=217, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["MP"]=40, 
        ["Accuracy"]=40, 
        ["category"]="Weapon", 
        ["damage"]=160, 
        ["Sword skill"]=248, 
        ["Parrying skill"]=248, 
        ["skill"]="Sword", 
        ["DT"]=-10
    }, 
    [92]={
        ["discription"]="DEF:142 HP+91 MP+73 STR+17 DEX+42 VIT+39 AGI+12 INT+28 MND+40 CHR+24 Accuracy+40 Attack+30 Ranged Accuracy+40 Ranged Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+30 Eva.+80 Magic Eva.+112 \"Magic Def. Bonus\"+4 Haste+3% Magic burst damage+5 \"Skillchain Bonus\"+5 Damage taken-7% Pet: Acc.+50 Ranged Acc.+50 Magic Acc.+50", 
        ["Magic Burst Damage"]=5, 
        ["id"]=23775, 
        ["Ranged Attack"]=60, 
        ["Weapon skill damage"]=10, 
        ["PDT"]=-10, 
        ["Aug_DB_Source"]=true, 
        ["Double Attack"]=4, 
        ["DEX"]=62, 
        ["DEF"]=142, 
        ["item_level"]=119, 
        ["en"]="Nyame Gauntlets", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["AGI"]=12, 
        ["MND"]=40, 
        ["Attack"]=80, 
        ["HP"]=91, 
        ["Magic Atk. Bonus"]=30, 
        ["Magic Def. Bonus"]=4, 
        ["Skillchain Bonus"]=5, 
        ["VIT"]=49, 
        ["Accuracy"]=80, 
        ["CHR"]=24, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Unity Ranking Bonus Applied"]="Attack + 20", 
        ["category"]="Armor", 
        ["Ranged Accuracy"]=40, 
        ["Magic Accuracy"]=50, 
        ["INT"]=28, 
        ["_aug_only"]={
            ["Weapon skill damage"]=10, 
            ["Attack"]=50, 
            ["DEX"]=20, 
            ["Double Attack"]=4, 
            ["Accuracy"]=30, 
            ["Ranged Attack"]=30, 
            ["VIT"]=10, 
            ["PDT"]=-10
        }, 
        ["STR"]=17, 
        ["MP"]=73, 
        ["Haste"]=3, 
        ["DT"]=-7
    }, 
    [93]={
        ["Cure potency"]=10, 
        ["Magic Accuracy"]=20, 
        ["Extdata Augments Applied"]=true, 
        ["category"]="Armor", 
        ["id"]=26250, 
        ["en"]="Sucellos's Cape", 
        ["_aug_only"]={
            ["Cure potency"]=10, 
            ["Magic Accuracy"]=20, 
            ["MP"]=60, 
            ["PDT"]=-8
        }, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["DEF"]=15, 
        ["discription"]="DEF:15 Enfeebling magic effect +10 Enhancing magic duration +20%", 
        ["slots"]={
            [15]="Back"
        }, 
        ["MP"]=60, 
        ["augments"]={
            [1]="MP+60", 
            [2]="Mag. Acc+20 /Mag. Dmg.+20", 
            [3]="none", 
            [4]="\"Cure\" potency +10%", 
            [5]="Phys. dmg. taken-8%"
        }, 
        ["PDT"]=-8
    }, 
    [94]={
        ["discription"]="Accuracy+5 \"Magic Atk. Bonus\"+10 Enmity-5 \"Conserve MP\"+2", 
        ["Enmity"]=-5, 
        ["category"]="Armor", 
        ["en"]="Deviant Necklace", 
        ["Magic Atk. Bonus"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27507, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Conserve MP"]=2, 
        ["MP"]=2, 
        ["Accuracy"]=5
    }, 
    [95]={
        ["discription"]="Damage taken-6% Unity Ranking: DEF:+10～15", 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={
                    ["DEF"]=45
                }, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=770
        }, 
        ["en"]="Loricate Torque +1", 
        ["Unity Ranking Bonus Applied"]="DEF + 45", 
        ["_aug_only"]={
            ["DEF"]=45, 
            ["SIRD"]=5
        }, 
        ["SIRD"]=5, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26002, 
        ["DEF"]=45, 
        ["DT"]=-6
    }, 
    [96]={
        ["discription"]="Enchantment: Teleport (Crag of Dem) Destination is close to the dimensional portal in Konschtat Highlands.", 
        ["id"]=26177, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Dim. Ring (Dem)", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [97]={
        ["discription"]="Enchantment: Warp", 
        ["id"]=28540, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Warp Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [98]={
        ["Evasion"]=61, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["Magic Evasion"]=100, 
        ["DEX"]=31, 
        ["Refresh"]=3, 
        ["id"]=23446, 
        ["MND"]=43, 
        ["Haste"]=3, 
        ["AGI"]=31, 
        ["item_level"]=119, 
        ["en"]="Atrophy Tabard +3", 
        ["HP"]=91, 
        ["discription"]="DEF:146 HP+91 MP+98 STR+31 DEX+31 VIT+31 AGI+31 INT+43 MND+43 CHR+39 Magic Accuracy+55 Evasion+61 Magic Evasion+100 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+8 Enfeebling magic skill +21 Haste+3% \"Refresh\" potency +2 \"Refresh\"+3 Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=7
        }, 
        ["slots"]={
            [5]="Body"
        }, 
        ["INT"]=43, 
        ["DEF"]=146, 
        ["MP"]=98, 
        ["STR"]=31, 
        ["CHR"]=39, 
        ["category"]="Armor", 
        ["Magic Def. Bonus"]=8, 
        ["VIT"]=31, 
        ["Magic Atk. Bonus"]=20, 
        ["Magic Accuracy"]=55
    }, 
    [99]={
        ["discription"]="\"Double Attack\"+3% \"Store TP\"+3", 
        ["skill"]="(N/A)", 
        ["DEX"]=10, 
        ["category"]="Weapon", 
        ["Store TP"]=3, 
        ["en"]="Coiste Bodhar", 
        ["Double Attack"]=3, 
        ["_aug_only"]={
            ["DEX"]=10, 
            ["STR"]=10, 
            ["Attack"]=15
        }, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["Aug_DB_Source"]=true, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=21431, 
        ["STR"]=10, 
        ["Attack"]=18
    }, 
    [100]={
        ["discription"]="Enchantment: \"Teleport\" (Tavnazian Safehold)", 
        ["id"]=14672, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Tavnazian Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [101]={
        ["discription"]="MP+50 Accuracy+5 Enemy critical hit rate -7% Magic Damage taken-5%", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Fortified Ring", 
        ["MP"]=50, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=5, 
        ["id"]=10773, 
        ["Enemy critical hit rate"]=-7, 
        ["DT"]=-5
    }, 
    [102]={
        ["Aug_DB_Source"]=true, 
        ["id"]=23789, 
        ["Skillchain Bonus"]=5, 
        ["DEX"]=26, 
        ["Accuracy"]=58, 
        ["AGI"]=46, 
        ["Haste"]=3, 
        ["Magic Accuracy"]=50, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["MND"]=26, 
        ["discription"]="DEF:122 HP+68 MP+44 STR+23 DEX+26 VIT+24 AGI+46 INT+25 MND+26 CHR+38 Accuracy+40 Attack+30 Ranged Accuracy+40 Ranged Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+30 Eva.+119 Magic Eva.+150 \"Magic Def. Bonus\"+5 Haste+3% Magic burst damage +5 \"Skillchain Bonus\"+5 Damage taken-7% Pet: Acc.+50 Ranged Acc.+50 Magic Acc.+50", 
        ["en"]="Nyame Sollerets", 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=48, 
        ["_aug_only"]={
            ["Ranged Attack"]=30, 
            ["Weapon skill damage"]=10, 
            ["Double Attack"]=4, 
            ["Accuracy"]=8, 
            ["Ranged Accuracy"]=8, 
            ["Attack"]=30
        }, 
        ["HP"]=68, 
        ["VIT"]=24, 
        ["Magic Atk. Bonus"]=30, 
        ["Magic Burst Damage"]=5, 
        ["DEF"]=122, 
        ["MP"]=44, 
        ["Ranged Attack"]=60, 
        ["Weapon skill damage"]=10, 
        ["Double Attack"]=4, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["INT"]=25, 
        ["Attack"]=60, 
        ["STR"]=23, 
        ["category"]="Armor", 
        ["CHR"]=38, 
        ["Magic Def. Bonus"]=5, 
        ["DT"]=-7
    }, 
    [103]={
        ["Enmity"]=2, 
        ["en"]="Friomisi Earring", 
        ["Magic Atk. Bonus"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="\"Magic Atk. Bonus\"+10 Enmity+2", 
        ["id"]=28514, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [104]={
        ["discription"]="Accuracy-10 Attack-10 Ranged Accuracy-10 Ranged Attack-10 \"Store TP\"+8", 
        ["category"]="Armor", 
        ["en"]="Dedition Earring", 
        ["Store TP"]=8, 
        ["Ranged Attack"]=-10, 
        ["Ranged Accuracy"]=-10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=-10, 
        ["id"]=27544, 
        ["Attack"]=-10
    }, 
    [105]={
        ["Pet: Magic Accuracy"]=15, 
        ["id"]=26119, 
        ["discription"]="DEF:10 HP+100 Haste+5% Damage taken-5% Pet: Accuracy+15 Ranged Accuracy+15 Magic Accuracy+15", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Ranged Accuracy"]=15, 
        ["en"]="Alabaster Earring", 
        ["_aug_only"]={
            ["Pet: Magic Accuracy"]=15, 
            ["Pet: Ranged Accuracy"]=15, 
            ["Haste"]=5, 
            ["Pet: Accuracy"]=15, 
            ["DT"]=-5
        }, 
        ["Magic Accuracy"]=15, 
        ["HP"]=100, 
        ["Haste"]=10, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["DEF"]=10, 
        ["Pet: Accuracy"]=15, 
        ["Pet: Ranged Accuracy"]=15, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Aug_DB_Source"]=true, 
        ["category"]="Armor", 
        ["DT"]=-10
    }, 
    [106]={
        ["Evasion"]=91, 
        ["Haste"]=3, 
        ["DEX"]=12, 
        ["id"]=23788, 
        ["en"]="Bunzi's Sabots", 
        ["Accuracy"]=40, 
        ["Magic Evasion"]=150, 
        ["jobs"]={
            [3]="WHM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN"
        }, 
        ["MND"]=33, 
        ["discription"]="DEF:102 HP+38 MP+35 STR+12 DEX+12 VIT+12 AGI+32 INT+32 MND+33 CHR+44 Accuracy+40 Attack+40 Magic Accuracy+40 \"Magic Atk. Bonus\"+30 Magic Damage+30 Evasion+91 Magic Evasion+150 \"Magic Def. Bonus\"+8 Haste+3% Enmity-6 Magic burst damage +6 Damage taken-6% Pet: Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Avatar: Lv.+1", 
        ["Enmity"]=-6, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=50, 
        ["STR"]=12, 
        ["HP"]=38, 
        ["Magic Damage"]=30, 
        ["AGI"]=32, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Magic Burst Damage"]=6, 
        ["DEF"]=102, 
        ["MP"]=35, 
        ["Attack"]=40, 
        ["VIT"]=12, 
        ["INT"]=32, 
        ["Magic Def. Bonus"]=8, 
        ["Magic Atk. Bonus"]=30, 
        ["CHR"]=44, 
        ["Magic Accuracy"]=50, 
        ["category"]="Armor", 
        ["DT"]=-6
    }, 
    [107]={
        ["discription"]="Resistance to all status ailments +10 Spell interruption rate -10% Damage taken -2%", 
        ["category"]="Weapon", 
        ["en"]="Staunch Tathlum", 
        ["skill"]="(N/A)", 
        ["SIRD"]=10, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=22278, 
        ["DT"]=-2
    }, 
    [108]={
        ["Evasion"]=55, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["discription"]="DEF:67 HP+13 MP+45 STR+8 DEX+9 VIT+8 AGI+31 INT+20 MND+22 CHR+32 Magic Accuracy+15 \"Magic Atk. Bonus\"+15 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+3% Enfeebling magic skill +12", 
        ["DEX"]=9, 
        ["STR"]=8, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Immunobreak Chance", 
            [4]="none"
        }, 
        ["MND"]=22, 
        ["Haste"]=3, 
        ["id"]=27337, 
        ["item_level"]=119, 
        ["en"]="Vitiation Boots +1", 
        ["HP"]=13, 
        ["AGI"]=31, 
        ["VIT"]=8, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=67, 
        ["MP"]=45, 
        ["Magic Evasion"]=107, 
        ["INT"]=20, 
        ["Magic Def. Bonus"]=5, 
        ["CHR"]=32, 
        ["Magic Atk. Bonus"]=15, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=15
    }, 
    [109]={
        ["discription"]="Accuracy+10 Attack+10 Ranged Accuracy+10 Ranged Attack+10 \"Double Attack\"+1% \"Store TP\"+5", 
        ["category"]="Armor", 
        ["Ranged Accuracy"]=10, 
        ["en"]="Telos Earring", 
        ["Store TP"]=5, 
        ["Double Attack"]=1, 
        ["Ranged Attack"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=10, 
        ["id"]=27545, 
        ["Attack"]=1
    }, 
    [110]={
        ["discription"]="STR+3 DEX+3 VIT+3 AGI+3 Enmity+4 \"Double Attack\"+1% \"Store TP\"+5", 
        ["AGI"]=3, 
        ["STR"]=3, 
        ["category"]="Armor", 
        ["Store TP"]=5, 
        ["en"]="Petrov Ring", 
        ["Double Attack"]=1, 
        ["Enmity"]=4, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["VIT"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=10772, 
        ["DEX"]=3, 
        ["Attack"]=1
    }, 
    [111]={
        ["Subtle Blow II"]=5, 
        ["category"]="Armor", 
        ["en"]="Niqmaddu Ring", 
        ["DEX"]=10, 
        ["STR"]=10, 
        ["VIT"]=10, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG", 
            [18]="PUP", 
            [22]="RUN"
        }, 
        ["discription"]="STR+10 DEX+10 VIT+10 \"Quad Attack\"+3% \"Subtle Blow II\"+5", 
        ["id"]=26185, 
        ["Attack"]=3
    }, 
    [112]={
        ["discription"]="DEF:119 HP+50 MP+53 STR+10 DEX+29 VIT+26 AGI+7 INT+34 MND+47 CHR+30 Accuracy+40 Attack+40 Magic Accuracy+40 \"Magic Atk. Bonus\"+30 Magic Damage+30 Evasion+52 Magic Evasion+112 \"Magic Def. Bonus\"+7 Haste+3% Enmity-8 \"Double Attack\"+8% Magic burst damage +8 Damage taken-8% Pet: Accuracy+50 Ranged Acc.+50 Magic Acc.+50", 
        ["Attack"]=28, 
        ["id"]=23774, 
        ["DEF"]=119, 
        ["Evasion"]=52, 
        ["en"]="Bunzi's Gloves", 
        ["Magic Burst Damage"]=8, 
        ["PDT"]=-10, 
        ["DEX"]=49, 
        ["Enmity"]=-8, 
        ["item_level"]=119, 
        ["Store TP"]=10, 
        ["jobs"]={
            [3]="WHM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN"
        }, 
        ["AGI"]=7, 
        ["MND"]=47, 
        ["INT"]=34, 
        ["HP"]=50, 
        ["Double Attack"]=8, 
        ["category"]="Armor", 
        ["VIT"]=26, 
        ["Accuracy"]=80, 
        ["_aug_only"]={
            ["Accuracy"]=30, 
            ["DEX"]=20, 
            ["Store TP"]=10, 
            ["Attack"]=20, 
            ["PDT"]=-10
        }, 
        ["CHR"]=30, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Unity Ranking Bonus Applied"]="Attack + 20", 
        ["Magic Atk. Bonus"]=30, 
        ["Magic Evasion"]=112, 
        ["MP"]=53, 
        ["Magic Def. Bonus"]=7, 
        ["Magic Accuracy"]=50, 
        ["Magic Damage"]=30, 
        ["Haste"]=3, 
        ["STR"]=10, 
        ["DT"]=-8
    }, 
    [113]={
        ["Evasion"]=63, 
        ["Fast Cast"]=10, 
        ["DEX"]=16, 
        ["id"]=23760, 
        ["en"]="Bunzi's Hat", 
        ["Accuracy"]=40, 
        ["Haste"]=6, 
        ["jobs"]={
            [3]="WHM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN"
        }, 
        ["MND"]=33, 
        ["discription"]="DEF:131 HP+50 MP+44 STR+16 DEX+16 VIT+16 INT+34 MND+33 CHR+30 Accuracy+40 Attack+40 Magic Accuracy+40 \"Magic Atk. Bonus\"+30 Magic Damage+30 Evasion+63 Magic Evasion+123 \"Magic Def. Bonus\"+8 Haste+6% Enmity-7 Magic burst damage +7 \"Fast Cast\"+10% Damage taken-7% Pet: Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50", 
        ["Enmity"]=-7, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=50, 
        ["STR"]=16, 
        ["HP"]=50, 
        ["Magic Damage"]=30, 
        ["Magic Evasion"]=123, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Magic Burst Damage"]=7, 
        ["DEF"]=131, 
        ["MP"]=44, 
        ["Attack"]=40, 
        ["VIT"]=16, 
        ["INT"]=34, 
        ["Magic Def. Bonus"]=8, 
        ["Magic Atk. Bonus"]=30, 
        ["CHR"]=30, 
        ["Magic Accuracy"]=50, 
        ["category"]="Armor", 
        ["DT"]=-7
    }, 
    [114]={
        ["discription"]="MP+30 Magic Accuracy+1 Increases \"Fast Cast\" effect Enmity-3", 
        ["Enmity"]=-3, 
        ["category"]="Armor", 
        ["en"]="Orunmila's Torque", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=10394, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["MP"]=30, 
        ["Magic Accuracy"]=1
    }, 
    [115]={
        ["discription"]="Weapon skill damage +2%", 
        ["id"]=27537, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Ishvara Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [116]={
        ["Ranged Attack"]=15, 
        ["Ranged Accuracy"]=15, 
        ["discription"]="DEF:9 HP+20 MP+20 Accuracy+15 Ranged Accuracy+15 Attack+15 Ranged Attack+15 Magic Accuracy+7 \"Magic Atk. Bonus\"+7", 
        ["category"]="Armor", 
        ["Magic Atk. Bonus"]=7, 
        ["en"]="Eschan Stone", 
        ["HP"]=20, 
        ["MP"]=20, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["Attack"]=15, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=15, 
        ["DEF"]=9, 
        ["id"]=28415, 
        ["Magic Accuracy"]=7
    }, 
    [117]={
        ["discription"]="DEF:10 HP+60 DEX+10 AGI+10 Attack+25 \"Store TP\"+5 ", 
        ["category"]="Armor", 
        ["DEX"]=10, 
        ["en"]="Ilabrat Ring", 
        ["Store TP"]=5, 
        ["HP"]=60, 
        ["AGI"]=10, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=26186, 
        ["DEF"]=10, 
        ["Attack"]=25
    }, 
    [118]={
        ["Ranged Attack"]=20, 
        ["AGI"]=10, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]={
                [1]=91, 
                [2]=9, 
                [3]=47, 
                [4]=87, 
                [5]=6, 
                [6]=46, 
                [7]=133, 
                [8]=45, 
                [9]=84, 
                [10]=129, 
                [11]=92, 
                [12]=10, 
                [13]=50, 
                [14]=88
            }
        }, 
        ["category"]="Armor", 
        ["discription"]="HP+50 STR+10 DEX+10 VIT+10 AGI+10 Attack+20 Ranged Attack+20 Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["en"]="Regal Ring", 
        ["HP"]=50, 
        ["STR"]=10, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["DEX"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=26191, 
        ["VIT"]=10, 
        ["Attack"]=20
    }, 
    [119]={
        ["Evasion"]=80, 
        ["DEX"]=56, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=23734, 
        ["Accuracy"]=50, 
        ["Magic Evasion"]=112, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=12, 
        ["MND"]=42, 
        ["en"]="Malignance Gloves", 
        ["PDL"]=4, 
        ["HP"]=57, 
        ["Haste"]=4, 
        ["discription"]="DEF:108 HP+57 MP+36 STR+25 DEX+56 VIT+32 AGI+24 INT+11 MND+42 CHR+21 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+80 Magic Evasion+112 \"Magic Def. Bonus\"+4 Haste+4% \"Store TP\"+12 Physical damage limit+4% Damage taken-5%", 
        ["STR"]=25, 
        ["INT"]=11, 
        ["DEF"]=108, 
        ["MP"]=36, 
        ["AGI"]=24, 
        ["CHR"]=21, 
        ["category"]="Armor", 
        ["VIT"]=32, 
        ["Magic Def. Bonus"]=4, 
        ["item_level"]=119, 
        ["Magic Accuracy"]=50, 
        ["DT"]=-5
    }, 
    [120]={
        ["Evasion"]=100, 
        ["DEX"]=34, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Magic Evasion"]=64, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["Accuracy"]=40, 
        ["Enmity"]=10, 
        ["STR"]=35, 
        ["Haste"]=4, 
        ["MND"]=33, 
        ["en"]="Emet Harness +1", 
        ["_aug_only"]={
            ["Evasion"]=30, 
            ["AGI"]=10, 
            ["CHR"]=10, 
            ["DEX"]=10, 
            ["MND"]=10, 
            ["STR"]=10, 
            ["INT"]=10, 
            ["Accuracy"]=40, 
            ["VIT"]=10
        }, 
        ["HP"]=61, 
        ["discription"]="DEF:131 HP+61 STR+25 DEX+24 VIT+25 AGI+23 INT+23 MND+23 CHR+23 Evasion+70 Magic Evasion+64 \"Magic Def. Bonus\"+5 Haste+4% Enmity+10 Physical Damage taken-6% Unity Ranking: Accuracy+10～20", 
        ["id"]=26871, 
        ["Unity Ranking Bonus Applied"]="VIT + 10", 
        ["INT"]=33, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=131, 
        ["item_level"]=119, 
        ["CHR"]=33, 
        ["category"]="Armor", 
        ["Magic Def. Bonus"]=5, 
        ["VIT"]=35, 
        ["AGI"]=33, 
        ["DT"]=-6
    }, 
    [121]={
        ["discription"]="Enhances \"Fast Cast\" effect", 
        ["id"]=19049, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["en"]="Vivid Strap", 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [122]={
        ["discription"]="A tasty white pasta with a creamy sauce made from Selbina milk and ground black pepper. HP+14% (Max. 175) MP+10 STR+4 VIT+2 INT-3 Attack+17% (Max. 65) \"Store TP\"+6", 
        ["category"]="Usable", 
        ["STR"]=4, 
        ["en"]="Carbonara", 
        ["Store TP"]=6, 
        ["HP"]=14, 
        ["VIT"]=2, 
        ["jobs"]={}, 
        ["MP"]=10, 
        ["INT"]=-3, 
        ["id"]=5190, 
        ["slots"]={}, 
        ["Attack"]=17
    }, 
    [123]={
        ["Evasion"]=94, 
        ["DEX"]=39, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["Great Katana skill"]=21, 
        ["Accuracy"]=64, 
        ["id"]=23498, 
        ["Magic Evasion"]=109, 
        ["Zanshin"]=16, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Store TP"]=14, 
        ["MND"]=34, 
        ["en"]="Kasuga Domaru +3", 
        ["Haste"]=3, 
        ["HP"]=96, 
        ["Attack"]=74, 
        ["VIT"]=43, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Zanshin"]=2
                }, 
                [3]={
                    ["Zanshin"]=3
                }, 
                [4]={
                    ["Zanshin"]=4
                }, 
                [5]={
                    ["Zanshin"]=5
                }
            }, 
            ["set id"]=98
        }, 
        ["INT"]=34, 
        ["STR"]=43, 
        ["DEF"]=176, 
        ["AGI"]=34, 
        ["CHR"]=34, 
        ["category"]="Armor", 
        ["discription"]="DEF:176 HP+96 STR+43 DEX+39 VIT+43 AGI+34 INT+34 MND+34 CHR+34 Accuracy+64 Attack+74 Magic Accuracy+64 Evasion+94 Magic Evasion+109 \"Magic Def. Bonus\"+8 Great Katana skill +21 Haste+3% \"Store TP\"+14 \"Zanshin\"+16 Damage taken-14% Set: Augments \"Zanshin\"", 
        ["Magic Def. Bonus"]=8, 
        ["item_level"]=119, 
        ["Magic Accuracy"]=64, 
        ["DT"]=-14
    }, 
    [124]={
        ["discription"]="Attack+18 Haste+4% \"Store TP\"+6", 
        ["category"]="Armor", 
        ["en"]="Sweordfaetels +1", 
        ["Store TP"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=4, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28447, 
        ["Attack"]=18
    }, 
    [125]={
        ["discription"]="A soft grape rice cake. HP+30 STR+3 VIT+4 Acc.+11% (Max. 85) Atk.+11% (Max. 55) Rng. Acc.+11% (Max. 85) Rng. Atk.+11% (Max. 55) \"M. Atk. Bonus\"+4 Pet: HP+30 STR+3 VIT+4 Acc.+11% (Max. 110) Atk.+11% (Max. 80) Rng. Acc.+11% (Max. 110) Rng. Atk.+11% (Max. 80) \"M. Atk. Bonus\"+15", 
        ["category"]="Usable", 
        ["Ranged Accuracy"]=11, 
        ["en"]="Grape Daifuku +1", 
        ["Ranged Attack"]=11, 
        ["HP"]=30, 
        ["STR"]=3, 
        ["jobs"]={}, 
        ["Accuracy"]=11, 
        ["VIT"]=4, 
        ["id"]=6344, 
        ["slots"]={}, 
        ["Attack"]=11
    }, 
    [126]={
        ["discription"]="Given to adventurers who have proven themselves in Records of Eminence, this tawny and reflective ticket is indispensable for acquiring rewards from the Adventurers' Mutual Aid Network.", 
        ["id"]=8711, 
        ["slots"]={}, 
        ["en"]="Copper Voucher", 
        ["category"]="General", 
        ["jobs"]={}
    }, 
    [127]={
        ["Ranged Attack"]=22, 
        ["category"]="Usable", 
        ["discription"]="A delightful blend of pomodoro sauce and dragon meat served over spaghetti al dente, with enough mustard to make your eyes pop in surprise. HP+17% (Max. 140) STR+5 VIT+2 INT-7 Attack+22% (Max. 90) Ranged Attack+22% (Max. 90) \"Store TP\"+6 \"Resist Sleep\"+8", 
        ["en"]="Arrabbiata", 
        ["Store TP"]=6, 
        ["HP"]=17, 
        ["STR"]=5, 
        ["jobs"]={}, 
        ["id"]=5211, 
        ["INT"]=-7, 
        ["VIT"]=2, 
        ["slots"]={}, 
        ["Attack"]=22
    }, 
    [128]={
        ["discription"]="A brilliant blue gemstone found within Outer Ra'Kaznar.", 
        ["id"]=9927, 
        ["slots"]={}, 
        ["en"]="Ra'Kaz. Sapphire", 
        ["category"]="General", 
        ["jobs"]={}
    }, 
    [129]={
        ["Ranged Attack"]=62, 
        ["DEX"]=47, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["Magic Evasion"]=82, 
        ["id"]=23565, 
        ["Accuracy"]=62, 
        ["Haste"]=4, 
        ["Ranged Accuracy"]=62, 
        ["discription"]="DEF:134 HP+57 STR+24 DEX+47 VIT+47 AGI+23 INT+21 MND+39 CHR+31 Accuracy+62 Attack+62 Ranged Accuracy+62 Ranged Attack+62 Magic Accuracy+62 Evasion+74 Magic Evasion+82 \"Magic Def. Bonus\"+5 Haste+4% Weapon skill damage +12% \"Sekkanoki\": TP bonus based on remaining TP+100% Set: Augments \"Zanshin\"", 
        ["MND"]=39, 
        ["en"]="Kasuga Kote +3", 
        ["Evasion"]=74, 
        ["HP"]=57, 
        ["AGI"]=23, 
        ["item_level"]=119, 
        ["INT"]=21, 
        ["CHR"]=31, 
        ["STR"]=24, 
        ["DEF"]=134, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Magic Def. Bonus"]=5, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Zanshin"]=2
                }, 
                [3]={
                    ["Zanshin"]=3
                }, 
                [4]={
                    ["Zanshin"]=4
                }, 
                [5]={
                    ["Zanshin"]=5
                }
            }, 
            ["set id"]=98
        }, 
        ["category"]="Armor", 
        ["VIT"]=47, 
        ["Attack"]=62, 
        ["Magic Accuracy"]=62
    }, 
    [130]={
        ["discription"]="High-level alchemic techniques have been used to brew this medicine.", 
        ["id"]=4149, 
        ["slots"]={}, 
        ["en"]="Panacea", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [131]={
        ["Evasion"]=86, 
        ["DEX"]=37, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["Magic Evasion"]=113, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Overwhelm\" effect", 
            [4]="none"
        }, 
        ["Accuracy"]=52, 
        ["Haste"]=3, 
        ["id"]=23974, 
        ["Store TP"]=10, 
        ["MND"]=31, 
        ["en"]="Sakonji Do. +4", 
        ["item_level"]=119, 
        ["HP"]=111, 
        ["AGI"]=31, 
        ["STR"]=47, 
        ["slots"]={
            [5]="Body"
        }, 
        ["INT"]=34, 
        ["DEF"]=170, 
        ["MP"]=74, 
        ["discription"]="DEF:170 HP+111 MP+74 STR+47 DEX+37 VIT+41 AGI+31 INT+34 MND+31 CHR+31 Accuracy+52 Attack+90 Magic Accuracy+45 Evasion+86 Magic Evasion+113 \"Magic Def. Bonus\"+7 Haste+3% \"Store TP\"+10 Weapon skill damage +12%", 
        ["CHR"]=31, 
        ["category"]="Armor", 
        ["Magic Def. Bonus"]=7, 
        ["VIT"]=41, 
        ["Attack"]=90, 
        ["Magic Accuracy"]=45
    }, 
    [132]={
        ["discription"]="This potion remedies status ailments. Works on paralysis, silence, blindness, poison, and disease.", 
        ["id"]=4155, 
        ["slots"]={}, 
        ["en"]="Remedy", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [133]={
        ["discription"]="High-level alchemic techniques have been used to brew this medicine.", 
        ["id"]=4149, 
        ["slots"]={}, 
        ["en"]="Panacea", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [134]={
        ["Ranged Attack"]=25, 
        ["category"]="Usable", 
        ["STR"]=7, 
        ["en"]="R. Curry Bun +1", 
        ["AGI"]=3, 
        ["HP"]=35, 
        ["discription"]="With a generous portion of red curry bursting from its crust, this piping hot bun is a treat to all five senses. HP+35 STR+7 AGI+3 Attack+25% (Max. 150) Ranged Attack+25% (Max. 150) \"Demon Killer\"+6 \"Resist Sleep\"+5 HP recovered while healing +6 MP recovered while healing +3", 
        ["slots"]={}, 
        ["jobs"]={}, 
        ["id"]=5765, 
        ["Killer"]=6, 
        ["Attack"]=25
    }, 
    [135]={
        ["discription"]="Linkpearls are used to communicate with linkshells. They have no market value.", 
        ["id"]=515, 
        ["slots"]={}, 
        ["en"]="Linkpearl", 
        ["category"]="General", 
        ["jobs"]={}
    }, 
    [136]={
        ["discription"]="The tiny crystals in this dust reflect light. When applied, it makes things invisible.", 
        ["id"]=4164, 
        ["slots"]={}, 
        ["en"]="Prism Powder", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [137]={
        ["discription"]="Right ear: \"Fast Cast\"+7% Enhancing magic duration +7%", 
        ["category"]="Armor", 
        ["_aug_only"]={
            ["Accuracy"]=7, 
            ["Magic Accuracy"]=7
        }, 
        ["en"]="Lethargy Earring", 
        ["augments"]={
            [1]="System: 1 ID: 1676 Val: 0", 
            [2]="Accuracy+7", 
            [3]="Mag. Acc.+7", 
            [4]="none", 
            [5]="none"
        }, 
        ["Fast Cast"]=7, 
        ["Extdata Augments Applied"]=true, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["Accuracy"]=7, 
        ["id"]=25444, 
        ["Magic Accuracy"]=7
    }, 
    [138]={
        ["discription"]="The demonically frightful patterns etched into this crest skillfully convey the power possessed by the unholiest of Kindred houses.", 
        ["id"]=2957, 
        ["slots"]={}, 
        ["en"]="S. Kindred Crest", 
        ["category"]="General", 
        ["jobs"]={}
    }, 
    [139]={
        ["discription"]="DMG:310 Delay:437 STR+25 DEX+25 Accuracy+25 Magic Accuracy+25 Great Katana skill +260 Parrying skill +260 Magic Accuracy skill +260 \"Double Attack\"+5% Sortie: Tachi: Mumei Aftermath: Physical damage limit+", 
        ["Attack"]=5, 
        ["skill"]="Great Katana", 
        ["Great Katana skill"]=260, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["en"]="Kusanagi", 
        ["item_level"]=119, 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=437, 
        ["DEX"]=25, 
        ["Accuracy"]=25, 
        ["category"]="Weapon", 
        ["STR"]=25, 
        ["id"]=21984, 
        ["Double Attack"]=5, 
        ["Parrying skill"]=260, 
        ["damage"]=310, 
        ["Magic Accuracy"]=25
    }, 
    [140]={
        ["discription"]="DMG:40 Delay:450 Occasionally attacks 2 to 3 times", 
        ["en"]="Soboro Sukehiro", 
        ["skill"]="Great Katana", 
        ["delay"]=450, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["id"]=17813, 
        ["damage"]=40
    }, 
    [141]={
        ["discription"]="This lubricant cuts down 99.99% of all friction. When applied, it can nearly erase all noise emitted from a person or object.", 
        ["id"]=4165, 
        ["slots"]={}, 
        ["en"]="Silent Oil", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [142]={
        ["discription"]="The tiny crystals in this dust reflect light. When applied, it makes things invisible.", 
        ["id"]=4164, 
        ["slots"]={}, 
        ["en"]="Prism Powder", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [143]={
        ["discription"]="A ninjutsu tool used in casting \"Utsusemi.\"", 
        ["id"]=1179, 
        ["slots"]={}, 
        ["en"]="Shihei", 
        ["category"]="General", 
        ["jobs"]={}
    }, 
    [144]={
        ["discription"]="This potion remedies status ailments. Works on paralysis, silence, blindness, poison, and disease.", 
        ["id"]=4155, 
        ["slots"]={}, 
        ["en"]="Remedy", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [145]={
        ["discription"]="A ninjutsu tool used in casting \"Utsusemi.\"", 
        ["id"]=1179, 
        ["slots"]={}, 
        ["en"]="Shihei", 
        ["category"]="General", 
        ["jobs"]={}
    }, 
    [146]={
        ["discription"]="Accuracy+30 Ranged Accuracy+30 Magic Accuracy+30 Evasion+30 Magic Evasion+30 \"Magic Def. Bonus\"+3 \"Regen\"+3", 
        ["category"]="Armor", 
        ["Ranged Accuracy"]=30, 
        ["en"]="Null Belt", 
        ["Magic Def. Bonus"]=3, 
        ["Magic Evasion"]=30, 
        ["Regen"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=30, 
        ["Evasion"]=30, 
        ["id"]=26367, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["Magic Accuracy"]=30
    }, 
    [147]={
        ["discription"]="This medicine helps remove meal effects.", 
        ["id"]=4153, 
        ["slots"]={}, 
        ["en"]="Antacid", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [148]={
        ["discription"]="DEF:15 Enfeebling magic effect +10 Enhancing magic duration +20%", 
        ["STR"]=20, 
        ["Attack"]=20, 
        ["category"]="Armor", 
        ["_aug_only"]={
            ["Attack"]=20, 
            ["STR"]=20, 
            ["Accuracy"]=30, 
            ["PDT"]=-10
        }, 
        ["en"]="Sucellos's Cape", 
        ["id"]=26250, 
        ["Extdata Augments Applied"]=true, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=30, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["augments"]={
            [1]="STR+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="Accuracy+10", 
            [4]="Weapon skill damage +10%", 
            [5]="Phys. dmg. taken-10%"
        }, 
        ["DEF"]=15, 
        ["PDT"]=-10
    }, 
    [149]={
        ["discription"]="DMG:37 Delay:238", 
        ["category"]="Weapon", 
        ["_aug_only"]={
            ["damage"]=19
        }, 
        ["en"]="Machaera", 
        ["augments"]={
            [1]="DMG:+9", 
            [2]="none", 
            [3]="Circle Blade:DMG:+10%", 
            [4]="none"
        }, 
        ["delay"]=238, 
        ["Extdata Augments Applied"]=true, 
        ["jobs"]={
            [5]="RDM", 
            [7]="PLD", 
            [16]="BLU"
        }, 
        ["skill"]="Sword", 
        ["id"]=19423, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["damage"]=56
    }, 
    [150]={
        ["discription"]="A metallic rock whose origins are best left for experts to debate.", 
        ["id"]=9931, 
        ["slots"]={}, 
        ["en"]="Hexahedrite", 
        ["category"]="General", 
        ["jobs"]={}
    }, 
    [151]={
        ["discription"]="High-level alchemic techniques have been used to brew this medicine.", 
        ["id"]=4149, 
        ["slots"]={}, 
        ["en"]="Panacea", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [152]={
        ["discription"]="The white magic spell Reraise is inscribed on this parchment.", 
        ["id"]=4182, 
        ["slots"]={}, 
        ["en"]="Instant Reraise", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [153]={
        ["discription"]="Linkpearls are used to communicate with linkshells. They have no market value.", 
        ["id"]=515, 
        ["slots"]={}, 
        ["en"]="Linkpearl", 
        ["category"]="General", 
        ["jobs"]={}
    }, 
    [154]={
        ["discription"]="This potion remedies status ailments. Works on paralysis, silence, blindness, poison, and disease.", 
        ["id"]=4155, 
        ["slots"]={}, 
        ["en"]="Remedy", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [155]={
        ["Evasion"]=105, 
        ["DEX"]=34, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["AGI"]=40, 
        ["Accuracy"]=80, 
        ["id"]=23699, 
        ["discription"]="DEF:116 HP+45 STR+31 DEX+34 VIT+31 AGI+40 MND+20 CHR+34 Accuracy+60 Attack+70 Magic Accuracy+60 Evasion+105 Magic Evasion+130 \"Magic Def. Bonus\"+6 Haste+3% \"Conserve TP\"+14 Physical damage limit+10% \"Sengikori\"+13 Set: Augments \"Zanshin\"", 
        ["STR"]=61, 
        ["Attack"]=90, 
        ["Magic Evasion"]=130, 
        ["MND"]=20, 
        ["item_level"]=119, 
        ["_aug_only"]={
            ["Accuracy"]=20, 
            ["Weapon skill damage"]=10, 
            ["STR"]=30, 
            ["Attack"]=20, 
            ["PDT"]=-10
        }, 
        ["HP"]=45, 
        ["en"]="Kas. Sune-Ate +3", 
        ["VIT"]=31, 
        ["Unity Ranking Bonus Applied"]="Attack + 20", 
        ["PDL"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=116, 
        ["Haste"]=3, 
        ["CHR"]=34, 
        ["category"]="Armor", 
        ["PDT"]=-10, 
        ["Magic Def. Bonus"]=6, 
        ["Weapon skill damage"]=10, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Zanshin"]=2
                }, 
                [3]={
                    ["Zanshin"]=3
                }, 
                [4]={
                    ["Zanshin"]=4
                }, 
                [5]={
                    ["Zanshin"]=5
                }
            }, 
            ["set id"]=98
        }, 
        ["Magic Accuracy"]=60
    }, 
    [156]={
        ["discription"]="This potion remedies curse. ", 
        ["id"]=4154, 
        ["slots"]={}, 
        ["en"]="Holy Water", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [157]={
        ["Evasion"]=91, 
        ["DEX"]=40, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=23732, 
        ["Accuracy"]=50, 
        ["Magic Evasion"]=123, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=8, 
        ["MND"]=16, 
        ["en"]="Malignance Chapeau", 
        ["PDL"]=3, 
        ["HP"]=45, 
        ["Haste"]=6, 
        ["discription"]="DEF:121 HP+45 MP+29 STR+11 DEX+40 VIT+19 AGI+33 INT+25 MND+16 CHR+17 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+91 Magic Evasion+123 \"Magic Def. Bonus\"+5 Haste+6% \"Store TP\"+8 Physical damage limit+3% Damage taken-6%", 
        ["STR"]=11, 
        ["INT"]=25, 
        ["DEF"]=121, 
        ["MP"]=29, 
        ["AGI"]=33, 
        ["CHR"]=17, 
        ["category"]="Armor", 
        ["VIT"]=19, 
        ["Magic Def. Bonus"]=5, 
        ["item_level"]=119, 
        ["Magic Accuracy"]=50, 
        ["DT"]=-6
    }, 
    [158]={
        ["discription"]="Surreal, nightmarish patterns adorn this crest, symbolizing a Kindred house of the purest lineage.", 
        ["id"]=2956, 
        ["slots"]={}, 
        ["en"]="H. Kindred Crest", 
        ["category"]="General", 
        ["jobs"]={}
    }, 
    [159]={
        ["discription"]="Right ear: \"Store TP\"+8 \"Skillchain Bonus\"+6", 
        ["category"]="Armor", 
        ["id"]=25487, 
        ["en"]="Kasuga Earring +1", 
        ["Skillchain Bonus"]=6, 
        ["Store TP"]=8, 
        ["_aug_only"]={
            ["Accuracy"]=12, 
            ["Magic Accuracy"]=12
        }, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["Accuracy"]=12, 
        ["Extdata Augments Applied"]=true, 
        ["augments"]={
            [1]="System: 1 ID: 1676 Val: 0", 
            [2]="Accuracy+12", 
            [3]="Mag. Acc.+12", 
            [4]="Weapon skill damage +2%", 
            [5]="none"
        }, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Magic Accuracy"]=12
    }, 
    [160]={
        ["Ranged Attack"]=23, 
        ["AGI"]=5, 
        ["discription"]="Deep-fried pork cutlets served over Tarutaru rice. HP+60 MP+60 STR+7 VIT+3 AGI+5 INT-7 +20 Attack+23% (Max. 125) Ranged Attack+23% (Max. 125) \"Store TP\"+4", 
        ["category"]="Usable", 
        ["Store TP"]=4, 
        ["en"]="Pork Cutlet Bowl", 
        ["HP"]=60, 
        ["INT"]=-7, 
        ["slots"]={}, 
        ["VIT"]=3, 
        ["jobs"]={}, 
        ["MP"]=60, 
        ["STR"]=7, 
        ["id"]=6406, 
        ["Attack"]=23
    }, 
    [161]={
        ["discription"]="This lubricant cuts down 99.99% of all friction. When applied, it can nearly erase all noise emitted from a person or object.", 
        ["id"]=4165, 
        ["slots"]={}, 
        ["en"]="Silent Oil", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [162]={
        ["\"Subtle Blow\""]=8, 
        ["Attack"]=7, 
        ["discription"]="Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+50 Magic Evasion+50 \"Double Attack\"+7% \"Store TP\"+7", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Ranged Accuracy"]=50, 
        ["en"]="Null Shawl", 
        ["_aug_only"]={
            ["\"Subtle Blow\""]=8, 
            ["Store TP"]=5, 
            ["HP"]=65
        }, 
        ["Store TP"]=12, 
        ["HP"]=65, 
        ["Magic Evasion"]=50, 
        ["Accuracy"]=50, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Evasion"]=50, 
        ["id"]=26274, 
        ["Unity Ranking Bonus Applied"]="HP + 65", 
        ["Double Attack"]=7, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=50
    }, 
    [163]={
        ["Ranged Attack"]=23, 
        ["category"]="Usable", 
        ["STR"]=7, 
        ["en"]="Red Curry Bun", 
        ["AGI"]=1, 
        ["HP"]=25, 
        ["discription"]="A crispy fried bun with an aromatic red curry filling. HP+25 STR+7 AGI+1 INT-2 Attack+23% (Max. 150) Ranged Attack+23% (Max. 150) \"Demon Killer\"+4 \"Resist Sleep\"+3 HP recovered while healing +2 MP recovered while healing +1", 
        ["jobs"]={}, 
        ["id"]=5759, 
        ["INT"]=-2, 
        ["Killer"]=4, 
        ["slots"]={}, 
        ["Attack"]=23
    }, 
    [164]={
        ["discription"]="This potion instantly restores a lot of MP.", 
        ["id"]=4140, 
        ["slots"]={}, 
        ["en"]="Pro-Ether", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [165]={
        ["discription"]="DMG:38 Delay:236  Latent effect: HP+20 +10 +10", 
        ["en"]="Sapara of Trials", 
        ["skill"]="Sword", 
        ["delay"]=236, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["id"]=17654, 
        ["damage"]=38
    }, 
    [166]={
        ["Evasion"]=74, 
        ["DEX"]=19, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["Attack"]=63, 
        ["id"]=23632, 
        ["Accuracy"]=63, 
        ["Magic Evasion"]=130, 
        ["Haste"]=3, 
        ["Store TP"]=11, 
        ["MND"]=27, 
        ["en"]="Kasuga Haidate +3", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["HP"]=80, 
        ["AGI"]=30, 
        ["item_level"]=119, 
        ["INT"]=38, 
        ["CHR"]=25, 
        ["STR"]=53, 
        ["DEF"]=156, 
        ["discription"]="DEF:156 HP+80 STR+53 DEX+19 VIT+40 AGI+30 INT+38 MND+27 CHR+25 Accuracy+63 Attack+63 Magic Accuracy+63 Evasion+74 Magic Evasion+130 \"Magic Def. Bonus\"+7 Haste+5% \"Store TP\"+11 Damage taken-11% \"Hasso\": Haste+3% Set: Augments \"Zanshin\"", 
        ["Magic Def. Bonus"]=7, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Zanshin"]=2
                }, 
                [3]={
                    ["Zanshin"]=3
                }, 
                [4]={
                    ["Zanshin"]=4
                }, 
                [5]={
                    ["Zanshin"]=5
                }
            }, 
            ["set id"]=98
        }, 
        ["category"]="Armor", 
        ["VIT"]=40, 
        ["Magic Accuracy"]=63, 
        ["DT"]=-11
    }, 
    [167]={
        ["discription"]="A small wooden chest is floating inside this gem. ", 
        ["id"]=9275, 
        ["slots"]={}, 
        ["en"]="Mars Orb", 
        ["category"]="General", 
        ["jobs"]={}
    }, 
    [168]={
        ["discription"]="A brilliant crimson gemstone found within Outer Ra'Kaznar.", 
        ["id"]=9928, 
        ["slots"]={}, 
        ["en"]="Ra'Kaz. Starstone", 
        ["category"]="General", 
        ["jobs"]={}
    }, 
    [169]={
        ["skill"]="Great Katana", 
        ["Great Katana skill"]=269, 
        ["TP Bonus"]=500, 
        ["Magic Damage"]=155, 
        ["category"]="Weapon", 
        ["Store TP"]=10, 
        ["en"]="Dojikiri Yasutsuna", 
        ["delay"]=450, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["Parrying skill"]=269, 
        ["discription"]="DMG:315 Delay:450 Magic Damage+155 Great Katana skill +269 Parrying skill +269 Magic Accuracy skill +228 \"Store TP\"+10 \"TP Bonus\"+500 \"Tachi: Shoha\" Aftermath: Increases skillchain potency Increases magic burst potency Ultimate Skillchain", 
        ["slots"]={
            [0]="Main"
        }, 
        ["item_level"]=119, 
        ["id"]=21025, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["damage"]=315
    }, 
    [170]={
        ["discription"]="Linkpearls are used to communicate with linkshells. They have no market value.", 
        ["id"]=515, 
        ["slots"]={}, 
        ["en"]="Linkpearl", 
        ["category"]="General", 
        ["jobs"]={}
    }, 
    [171]={
        ["discription"]="When used, these man-made wings instantly raise TP. Due to muscle strain, repeated use is prohibited.", 
        ["id"]=4213, 
        ["slots"]={}, 
        ["en"]="Icarus Wing", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [172]={
        ["Evasion"]=86, 
        ["DEX"]=34, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["Attack"]=61, 
        ["id"]=23431, 
        ["Accuracy"]=61, 
        ["Magic Evasion"]=98, 
        ["Haste"]=7, 
        ["Store TP"]=12, 
        ["MND"]=26, 
        ["en"]="Kasuga Kabuto +3", 
        ["slots"]={
            [4]="Head"
        }, 
        ["HP"]=73, 
        ["AGI"]=30, 
        ["item_level"]=119, 
        ["INT"]=26, 
        ["CHR"]=26, 
        ["STR"]=36, 
        ["DEF"]=144, 
        ["discription"]="DEF:144 HP+73 STR+36 DEX+34 VIT+35 AGI+30 INT+26 MND+26 CHR+26 Accuracy+61 Attack+61 Magic Accuracy+61 Evasion+86 Magic Evasion+98 \"Magic Def. Bonus\"+6 Haste+7% \"Store TP\"+12 Damage taken-10% Seigan: \"Counter\" rate +18 Set: Augments \"Zanshin\"", 
        ["Magic Def. Bonus"]=6, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Zanshin"]=2
                }, 
                [3]={
                    ["Zanshin"]=3
                }, 
                [4]={
                    ["Zanshin"]=4
                }, 
                [5]={
                    ["Zanshin"]=5
                }
            }, 
            ["set id"]=98
        }, 
        ["category"]="Armor", 
        ["VIT"]=35, 
        ["Magic Accuracy"]=61, 
        ["DT"]=-10
    }, 
    [173]={
        ["discription"]="This potion remedies poison. ", 
        ["id"]=4148, 
        ["slots"]={}, 
        ["en"]="Antidote", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [174]={
        ["discription"]="A primer on the basics of Trust magic.", 
        ["id"]=6716, 
        ["slots"]={}, 
        ["en"]="Trust Primer", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [175]={
        ["discription"]="The white magic spell Stoneskin is inscribed on this parchment.", 
        ["id"]=5990, 
        ["slots"]={}, 
        ["en"]="Instant Stoneskin", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [176]={
        ["discription"]="This potion functions in the same way as the spell Reraise.", 
        ["id"]=4172, 
        ["slots"]={}, 
        ["en"]="Reraiser", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [177]={
        ["discription"]="This potion instantly restores a few HP and MP.", 
        ["id"]=4145, 
        ["slots"]={}, 
        ["en"]="Elixir", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [178]={
        ["discription"]="This potion instantly restores a moderate amount of both HP and MP.", 
        ["id"]=4144, 
        ["slots"]={}, 
        ["en"]="Hi-Elixir", 
        ["category"]="Usable", 
        ["jobs"]={}
    }, 
    [179]={
        ["discription"]="DEF:156 HP+91 MP+59 STR+26 DEX+25 VIT+24 AGI+23 INT+28 MND+26 CHR+24 Accuracy+40 Attack+30 Ranged Accuracy+40 Ranged Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+30 Evasion+91 Magic Evasion+123 \"Magic Def. Bonus\"+5 Haste+6% Magic burst damage +5 \"Skillchain Bonus\"+5 Damage taken-7% Pet: Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50", 
        ["Ranged Attack"]=60, 
        ["id"]=23761, 
        ["Attack"]=80, 
        ["Magic Burst Damage"]=5, 
        ["Aug_DB_Source"]=true, 
        ["Weapon skill damage"]=10, 
        ["PDT"]=-10, 
        ["Double Attack"]=4, 
        ["DEX"]=45, 
        ["DEF"]=156, 
        ["item_level"]=119, 
        ["en"]="Nyame Helm", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Evasion"]=91, 
        ["MND"]=26, 
        ["AGI"]=23, 
        ["HP"]=91, 
        ["Magic Atk. Bonus"]=30, 
        ["Magic Def. Bonus"]=5, 
        ["Skillchain Bonus"]=5, 
        ["VIT"]=24, 
        ["Accuracy"]=75, 
        ["CHR"]=24, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Unity Ranking Bonus Applied"]="Attack + 20", 
        ["category"]="Armor", 
        ["Ranged Accuracy"]=55, 
        ["Magic Evasion"]=123, 
        ["STR"]=26, 
        ["INT"]=28, 
        ["_aug_only"]={
            ["Weapon skill damage"]=10, 
            ["Attack"]=50, 
            ["DEX"]=20, 
            ["Double Attack"]=4, 
            ["Accuracy"]=35, 
            ["Ranged Attack"]=30, 
            ["Ranged Accuracy"]=5, 
            ["PDT"]=-10
        }, 
        ["Haste"]=6, 
        ["Magic Accuracy"]=50, 
        ["MP"]=59, 
        ["DT"]=-7
    }, 
    [180]={
        ["discription"]="STR+3 VIT+3 Physical damage limit +3% Damage taken -3%", 
        ["category"]="Weapon", 
        ["en"]="Crepuscular Pebble", 
        ["VIT"]=3, 
        ["STR"]=3, 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["PDL"]=3, 
        ["id"]=22300, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["DT"]=-3
    }
}