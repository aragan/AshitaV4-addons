return {
    code = 'SCH',
    extra2 = true,
    dd_melee = false,
    extra5 = false,
    extra_preset = {
        'show_cursna',
        'show_emed',
        'show_hmct',
        'show_cst',
        'show_qc',
        'show_hms',
        'show_cp',
        'show_cp2',
        'show_phalanx',
        'show_stats',
        'show_sird',
    },
}
