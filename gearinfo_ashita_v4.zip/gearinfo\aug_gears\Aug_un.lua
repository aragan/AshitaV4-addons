return {
    -- unity gear augment entries (only max rank values)
    [10767] = { ["STR"] = 15, ["HP"] = 100 }, -- Behemoth Ring +1
    [10769] = { ["VIT"] = 15, ["HP"] = 100 }, -- Gelatinous Ring +1
    [10771] = { ["DEX"] = 10, ["AGI"] = 10 }, -- Cacoethic Ring +1
    [20508] = { ["DEX"] = 20, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Store TP"] = 10, ["Pet: Accuracy"] = 40, ["Pet: Magic Accuracy"] = 40 }, -- Comeuppances +1
    [20522] = { ["DMG"] = 30, ["Accuracy"] = 30, ["Magic Accuracy"] = 30, ["Critical Hit Rate"] = 10 }, -- Emeici +1
    [20528] = { ["DMG"] = 14, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Regen"] = 5 }, -- Fists of Fury +1
    [20581] = { ["Ranged Attack"] = 20, ["Ranged Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Enmity"] = -5 }, -- Kustawi +1
    [20604] = { ["DMG"] = 17, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Weapon Skill Damage"] = 5 }, -- Ternion Dagger +1
    [20607] = { ["DMG"] = 20, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Critical Hit Rate"] = 10 }, -- Anathema Harpe +1
    [20609] = { ["DMG"] = 13, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Evasion"] = 20 }, -- Jugo Kukri +1
    [20612] = { ["DMG"] = 35, ["Accuracy"] = 30, ["Magic Accuracy"] = 30, ["Quadruple Attack"] = 3 }, -- Sangarius +1
    [20680] = { ["DMG"] = 11, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Attack"] = 40 }, -- Tanmogayi +1
    [20682] = { ["DMG"] = 10, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Damage Taken"] = -5 }, -- Flyssa +1
    [20697] = { ["DMG"] = 19, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Store TP"] = 10 }, -- Combuster +1
    [20709] = { ["Accuracy"] = 45, ["Magic Accuracy"] = 45, ["DEX"] = 10, ["Sword Enhancement Spell Damage"] = 50 }, -- Demers. Degen +1
    [20800] = { ["DMG"] = 24, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Pet: Accuracy"] = 50, ["Pet: Magic Accuracy"] = 50 }, -- Mdomo Axe +1
    [20805] = { ["Ranged Attack"] = 45, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Pet: Accuracy"] = 50, ["Pet: Magic Accuracy"] = 50 }, -- Perun +1
    [20807] = { ["DMG"] = 30, ["Pet: Accuracy"] = 30, ["Pet: Magic Accuracy"] = 30, ["Accuracy"] = 35, ["Magic Accuracy"] = 35 }, -- Buramgh +1
    [20852] = { ["Accuracy"] = 45, ["Magic Accuracy"] = 45, ["Triple Attack"] = 3, ["Quadruple Attack"] = 3 }, -- Aizkora +1
    [20854] = { ["DMG"] = 53, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Haste"] = 10 }, -- Beheader +1
    [20899] = { ["DMG"] = 56, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Critical Hit Rate"] = 10 }, -- Triska Scythe +1
    [20943] = { ["DMG"] = 62, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Store TP"] = 10 }, -- Gae Derg +1
    [20981] = { ["DMG"] = 20, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Magic Defense Bonus"] = 5 }, -- Raicho +1
    [20988] = { ["DMG"] = 25, ["Aug2"] = "Acc.", ["Ranged Accuracy"] = 20, ["Magic Accuracy"] = 20, ["Magic Atk. Bonus"] = 20 }, -- Tancho +1
    [21030] = { ["DMG"] = 10, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Skillchain Damage"] = 20 }, -- Norifusa +1
    [21035] = { ["TP Bonus"] = 500, ["Accuracy"] = 30, ["Magic Accuracy"] = 30, ["STR"] = 10 }, -- Kunimune +1
    [21076] = { ["DMG"] = 10, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Magic Atk. Bonus"] = 30 }, -- Septoptic +1
    [21091] = { ["DMG"] = 33, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Weapon Skill Damage"] = 10 }, -- Loxotic Mace +1
    [21100] = { ["DMG"] = 45, ["Accuracy"] = 30, ["Magic Accuracy"] = 30, ["Weapon Skill Damage"] = 15 }, -- Magesmasher +1
    [21160] = { ["Magic Atk. Bonus"] = 40, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["INT/MND"] = 10 }, -- Marin Staff +1
    [21163] = { ["DMG"] = 45, ["Accuracy"] = 30, ["Magic Accuracy"] = 30, ["Store TP"] = 10 }, -- Pouwhenua +1
    [21220] = { ["DMG"] = 9, ["Ranged Accuracy"] = 40, ["Rapid Shot"] = 15 }, -- Paloma Bow +1
    [21223] = { ["Snapshot"] = 15, ["DMG"] = 10, ["Ranged Accuracy"] = 20 }, -- Mengado +1
    [21344] = { ["Magic Damage"] = 10, ["INT"] = 5 }, -- Ghastly Tathlum +1
    [21350] = { ["Accuracy"] = 10, ["Evasion"] = 10 }, -- Wingcutter +1
    [21403] = {}, -- Damani Horn +1
    [21417] = { ["DEF"] = 20, ["Parrying Skill"] = 10 }, -- Refined Grip +1
    [21419] = { ["Attack"] = 30, ["STR"] = 15 }, -- Rigorous Grip +1
    [21484] = { ["Ranged Attack"] = 45, ["Ranged Accuracy"] = 40, ["Magic Accuracy"] = 40, ["DMG"] = 5 }, -- Malison +1
    [21689] = { ["DMG"] = 20, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["HP"] = 100 }, -- Montante +1
    [21691] = { ["DMG"] = 28, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Cure Potency Recieved"] = 10 }, -- Ushenzi +1
    [21696] = { ["DMG"] = 33, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Dark Magic Skill"] = 10 }, -- Nullis +1
    [21703] = { ["DMG"] = 50, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Fast Cast"] = 10 }, -- Kladenets +1
    [21749] = { ["DMG"] = 21, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["STR/DEX/CHR"] = 10, ["Pet: Accuracy"] = 40, ["Pet: Magic Accuracy"] = 40 }, -- Habilitator +1
    [21806] = { ["DMG"] = 36, ["Accuracy"] = 40, ["Magic Accuracy"] = 40, ["Magic Atk. Bonus"] = 50 }, -- Pixquizpan +1
    [22058] = { ["Magic Accuracy"] = 70, ["Enfeebling Magic Skill"] = 20, ["MND"] = 10 }, -- Contemplator +1
    [22121] = { ["DMG"] = 17, ["Ranged Accuracy"] = 40, ["Snapshot"] = 10 }, -- Imati +1
    [22255] = { ["STR"] = 10, ["Haste"] = 5 }, -- Seeth. Bomblet +1
    [22267] = { ["Magic Evasion"] = 15, ["Double Attack"] = 3 }, -- Antitail +1
    [25602] = { ["Accuracy"] = 45, ["Magic Accuracy"] = 45, ["Critical Hit Rate"] = 10, ["STR/DEX"] = 25 }, -- Blistering Sallet +1
    [25636] = { ["Enmity"] = 10, ["Damage Taken"] = -10, ["All Attr."] = 10 }, -- Loess Barbuta +1
    [25681] = { ["Magic Accuracy"] = 100, ["Magic Attack Bonus"] = 100, ["All Base Stats"] = 20 }, -- Cohort Cloak +1
    [25710] = { ["Magic Evasion"] = 60, ["Enmity"] = 5, ["All Attr."] = 10 }, -- Obviat. Cuirass +1
    [25733] = { ["Accuracy"] = 30, ["All Attr."] = 10, ["Triple Attack"] = 5 }, -- Tatena. Harama. +1
    [25856] = { ["Accuracy"] = 75, ["All Attr."] = 10, ["Triple Attack"] = 3 }, -- Tatena. Haidate +1
    [25924] = { ["Accuracy"] = 60, ["All Attr."] = 10, ["Triple Attack"] = 3 }, -- Tatena. Sune. +1
    [26002] = { ["DEF"] = 45, ["Spell Interruption Rate"] = -5 }, -- Loricate Torque +1
    [26022] = { ["Accuracy"] = 15, ["Store TP"] = 10 }, -- Vim Torque +1
    [26402] = { ["Accuracy"] = 15, ["Magic Accuracy"] = 15, ["Enhancing Magic Skill"] = 10 }, -- Forfend +1
    [26710] = { ["Accuracy"] = 35, ["Magic Evasion"] = 100, ["Critical Hit Rate"] = 10 }, -- Imp. Wing Hair. +1
    [26711] = {}, -- Perle Salade +1
    [26712] = {}, -- Aurore Beret +1
    [26713] = {}, -- Teal Chapeau +1
    [26715] = { ["Accuracy"] = 45, ["Magic Accuracy"] = 45, ["Attack"] = 50, ["All Base Stats"] = 10 }, -- Adorned Helm +1
    [26732] = { ["Accuracy"] = 30, ["Magic Accuracy"] = 30, ["Physical Damage Limit"] = 5, ["All Base Stats"] = 10 }, -- Stinger Helm +1
    [26785] = { ["Physical Damage Taken"] = -10, ["Pet: Damage Taken"] = -5, ["All Base Stats"] = 10 }, -- Hike Khat +1
    [26787] = { ["All Base Stats"] = 30, ["Evasion"] = 50, ["Accuracy"] = 25, ["Ranged Accuracy"] = 25, ["Magic Accuracy"] = 25 }, -- Alhazen Hat +1
    [26869] = { ["Magic Accuracy"] = 45, ["Damage Taken"] = -5, ["All Base Stats"] = 10 }, -- Ros. Jaseran +1
    [26871] = { ["Evasion"] = 30, ["Accuracy"] = 40, ["All Base Stats"] = 10 }, -- Emet Harness +1
    [26873] = { ["Accuracy"] = 45, ["Double Attack"] = 5, ["All Base Stats"] = 10 }, -- Hime Domaru +1
    [26888] = { ["Avatar: TP Bonus"] = 300, ["Avatar: Accuracy"] = 30, ["Avatar: Magic Accuracy"] = 30, ["Avatar: All Base Stats"] = 10 }, -- Shomonjijoe +1
    [26897] = { ["Magic Accuracy"] = 60, ["Spell Interruption Rate"] = -20, ["All Base Stats"] = 20 }, -- Lugra Cloak +1
    [26943] = { ["Attack"] = 60, ["Store TP"] = 10, ["All Base Stats"] = 10 }, -- Agony Jerkin +1
    [27051] = { ["Attack"] = 45, ["Accuracy"] = 30, ["Magic Accuracy"] = 30, ["All Base Stats"] = 10 }, -- Kachi. Kote +1
    [27107] = { ["MP"] = 45, ["Avatar: Accuracy"] = 40, ["Avatar: Magic Accuracy"] = 40, ["Avatar: Magic Burst Bonus"] = 10 }, -- Asteria Mitts +1
    [27109] = { ["Avatar: All Base Stats"] = 30, ["Avatar: Accuracy"] = 40, ["Avatar: Magic Accuracy"] = 40, ["Avatar Perpetuation Cost"] = -5 }, -- Lamassu Mitts +1
    [27149] = { ["Accuracy"] = 40, ["All Attr."] = 10, ["Triple Attack"] = 4 }, -- Tatena. Gote +1
    [27151] = { ["Accuracy"] = 50, ["Haste"] = 10, ["All Base Stats"] = 10 }, -- Gazu Bracelets +1
    [27231] = { ["Accuracy"] = 30, ["Critical Hit Rate"] = 5, ["All Base Stats"] = 10 }, -- Zoar Subligar +1
    [27408] = { ["Cure Potency"] = 15, ["Healing Magic Skill"] = 10, ["All Base Stats"] = 10 }, -- Hygieia Clogs +1
    [27410] = { ["Resist Bind"] = 45, ["Evasion"] = 20, ["All Base Stats"] = 10 }, -- Hippo. Socks +1
    [27505] = { ["Skillchain Damage"] = 15, ["Magic Burst Bonus"] = 10 }, -- Warder's Charm +1
    [27509] = { ["DEF"] = 30, ["HP"] = 200 }, -- Unmoving Collar +1
    [27518] = { ["Evasion"] = 15, ["Counter"] = 10 }, -- Bathy Choker +1
    [27533] = { ["HP"] = 45, ["Shield Block Rate"] = 3 }, -- Zwazo Earring +1
    [27543] = { ["Accuracy"] = 10, ["DEX"] = 6 }, -- Domin. Earring +1
    [27549] = { ["DEF"] = 30, ["Damage Taken"] = -3 }, -- Odnowa Earring +1
    [27559] = { ["Conserve MP"] = 10, ["INT"] = 5 }, -- Mephitas's Ring +1
    [27561] = { ["DEF"] = 20, ["Magic Def. Bonus"] = 5 }, -- Apeile Ring +1
    [27563] = { ["Magic Accuracy"] = 10, ["INT/MND/CHR"] = 10 }, -- Metamor. Ring +1
    [27599] = {}, -- Dew Silk Cape +1
    [27602] = { ["Accuracy"] = 15, ["DEX"] = 10 }, -- Ground. Mantle +1
    [27610] = { ["Fast Cast"] = 10, ["Spell Interruption Rate"] = -5 }, -- Fi Follet Cape +1
    [27620] = { ["Accuracy"] = 25, ["Magic Accuracy"] = 25, ["INT/MND"] = 25 }, -- Aurist's Cape +1
    [27634] = {}, -- Thorfinn Shield +1
    [27637] = { ["HP"] = 150, ["Shield Skill"] = 10, ["Accuracy"] = 20, ["Magic Accuracy"] = 20 }, -- Evalach +1
    [27639] = { ["Shield Block Rate"] = 10, ["Enhancing Magic Received Duration"] = 10 }, -- Ajax +1
    [27641] = { ["Accuracy"] = 30, ["Magic Accuracy"] = 30, ["Shield Skill"] = 10 }, -- Deliverance +1
    [27851] = {}, -- Perle Hauberk +1
    [27852] = {}, -- Aurore Doublet +1
    [27853] = {}, -- Teal Saio +1
    [27996] = { ["Evasion"] = 90, ["Magic Evasion"] = 80, ["All Base Stats"] = 10 }, -- Shigure Tekko +1
    [27997] = {}, -- Perle Moufles +1
    [27998] = {}, -- Aurore Gloves +1
    [27999] = {}, -- Teal Cuffs +1
    [28135] = { ["Avatar: Accuracy"] = 35, ["Avatar: Magic Accuracy"] = 35, ["Avatar: All Base Stats"] = 20, ["MP"] = 20 }, -- Assid. Pants +1
    [28137] = { ["Attack"] = 60, ["Magic Atk. Bonus"] = 30, ["All Base Stats"] = 10 }, -- Augury Cuisses +1
    [28138] = {}, -- Perle Brayettes +1
    [28139] = {}, -- Aurore Brais +1
    [28140] = {}, -- Teal Slops +1
    [28272] = {}, -- Adsilio Boots +1
    [28274] = { ["Healing Magic Skill"] = 10, ["Enhancing Magic Skill"] = 10, ["All Base Stats"] = 10 }, -- Regal Pumps +1
    [28276] = { ["DEX/AGI"] = 15, ["Magic Evasion"] = 30, ["All Base Stats"] = 10 }, -- Jute Boots +1
    [28277] = {}, -- Perle Sollerets +1
    [28278] = {}, -- Aurore Gaiters +1
    [28279] = {}, -- Teal Pigaches +1
    [28351] = {}, -- Cloud Hairpin +1
    [28353] = { ["Magic Accuracy"] = 15, ["CHR"] = 10 }, -- Canto Necklace +1
    [28413] = { ["STR"] = 10, ["DEX"] = 10 }, -- Kentarch Belt +1
    [28424] = { ["Conserve MP"] = 15, ["Fast Cast"] = 5 }, -- Shinjutsu-no-Obi +1
    [28428] = { ["STR"] = 15, ["Double Attack"] = 5 }, -- Sailfi Belt +1
    [28430] = { ["Magic Accuracy"] = 15, ["INT"] = 10 }, -- Acuity Belt +1
    [28482] = { ["DEF"] = 20, ["STR/DEX/VIT/INT"] = 8 }, -- Lugra Earring +1
    [28485] = { ["Resist Silence"] = 15, ["Spell Interruption Rate"] = -5 }, -- Nourish. Earring +1
    [28487] = { ["Resist Sleep"] = 15, ["Resist Charm"] = 15 }, -- Arete del Luna +1
    [28491] = { ["Pet: Accuracy"] = 15, ["Pet: Magic Accuracy"] = 15, ["Accuracy"] = 10 }, -- Handler's Earring +1

    -- Augments list (string overrides, parsed in Gear_Processing)
    [10769] = {Aug1="L118: VIT+15",Aug2="HP+100",Aug3=""}, -- Gelatinous Ring +1
    [10771] = {Aug1="DEX+10",Aug2="AGI+10",Aug3=""}, -- Cacoethic Ring +1
    [20508] = {Aug1="DEX+20",Aug2="Accuracy & Magic Accuracy+40",Aug3="Store TP+10 / Pet: Acc. & Magic Accuracy+40"}, -- Comeuppances +1
    [20522] = {Aug1="DMG:+30",Aug2="Accuracy & Magic Accuracy+30",Aug3="L76: Critical Hit Rate+10%"}, -- Emeici +1
    [20528] = {Aug1="DMG:+14",Aug2="Accuracy & Magic Accuracy+40",Aug3="Regen+5"}, -- Fists of Fury +1
    [20581] = {Aug1="Ranged Attack+20",Aug2="Ranged Accuracy & Magic Accuracy+40",Aug3="Enmity-5"}, -- Kustawi +1
    [20604] = {Aug1="DMG:+17",Aug2="Accuracy & Magic Accuracy+40",Aug3="Weapon Skill Damage+5%"}, -- Ternion Dagger +1
    [20607] = {Aug1="DMG:+20",Aug2="Accuracy & Magic Accuracy+40",Aug3="Critical Hit Rate+10%"}, -- Anathema Harpe +1
    [20609] = {Aug1="DMG:+13",Aug2="Accuracy & Magic Accuracy+40",Aug3="Evasion+20"}, -- Jugo Kukri +1
    [20612] = {Aug1="DMG:+35",Aug2="Accuracy & Magic Accuracy+30",Aug3="Quadruple Attack+3%"}, -- Sangarius +1
    [20680] = {Aug1="DMG:+11",Aug2="Accuracy & Magic Accuracy+40",Aug3="Attack+40"}, -- Tanmogayi +1
    [20682] = {Aug1="DMG:+10",Aug2="Accuracy & Magic Accuracy+40",Aug3="Damage Taken-5%"}, -- Flyssa +1
    [20697] = {Aug1="DMG:+19",Aug2="Accuracy & Magic Accuracy+40",Aug3="Store TP+10"}, -- Combuster +1
    [20709] = {Aug1="Accuracy & Magic Accuracy+45",Aug2="DEX+10",Aug3="Sword Enhancement Spell Damage+50%"}, -- Demers. Degen +1
    [20800] = {Aug1="DMG:+24",Aug2="Accuracy & Magic Accuracy+40",Aug3="Pet: Acc. & Magic Accuracy+50"}, -- Mdomo Axe +1
    [20805] = {Aug1="Ranged Attack+45",Aug2="Accuracy & Magic Accuracy+40",Aug3="Pet: Acc. & Magic Accuracy+50"}, -- Perun +1
    [20807] = {Aug1="DMG:+30",Aug2="Pet: Acc. & Magic Accuracy+30",Aug3="L69: Accuracy & Magic Accuracy+35"}, -- Buramgh +1
    [20852] = {Aug1="Accuracy & Magic Accuracy+45",Aug2="Triple Attack+3%",Aug3="Quadruple Attack+3%"}, -- Aizkora +1
    [20854] = {Aug1="DMG:+53",Aug2="Accuracy & Magic Accuracy+40",Aug3="Haste+10%"}, -- Beheader +1
    [20899] = {Aug1="DMG:+56",Aug2="Accuracy & Magic Accuracy+40",Aug3="Critical Hit Rate+10%"}, -- Triska Scythe +1
    [20943] = {Aug1="DMG:+62",Aug2="Accuracy & Magic Accuracy+40",Aug3="Store TP+10"}, -- Gae Derg +1
    [20981] = {Aug1="DMG:+20",Aug2="Accuracy & Magic Accuracy+40",Aug3="Magic Defense Bonus+5"}, -- Raicho +1
    [20988] = {Aug1="L71: DMG:+25",Aug2="Acc.",Aug3="R.Acc. & M.Acc.+20 / L73: Magic Atk. Bonus+20"}, -- Tancho +1
    [21030] = {Aug1="DMG:+10",Aug2="Accuracy & Magic Accuracy+40",Aug3="Skillchain Damage+20%"}, -- Norifusa +1
    [21035] = {Aug1="L78: TP Bonus+500",Aug2="Accuracy & Magic Accuracy+30",Aug3="STR+10"}, -- Kunimune +1
    [21076] = {Aug1="DMG:+10",Aug2="Accuracy & Magic Accuracy+40",Aug3="Magic Atk. Bonus+30"}, -- Septoptic +1
    [21091] = {Aug1="DMG:+33",Aug2="Accuracy & Magic Accuracy+40",Aug3="Weapon Skill Damage+10%"}, -- Loxotic Mace +1
    [21100] = {Aug1="DMG:+45",Aug2="Accuracy & Magic Accuracy+30",Aug3="Weapon Skill Damage+15%"}, -- Magesmasher +1
    [21160] = {Aug1="Magic Atk. Bonus+40",Aug2="Accuracy & Magic Accuracy+40",Aug3="INT/MND+10"}, -- Marin Staff +1
    [21163] = {Aug1="DMG:+45",Aug2="Accuracy & Magic Accuracy+30",Aug3="Store TP+10"}, -- Pouwhenua +1
    [21220] = {Aug1="DMG:+9",Aug2="Ranged Accuracy+40",Aug3="Rapid Shot+15%"}, -- Paloma Bow +1
    [21223] = {Aug1="L86: Snapshot+15",Aug2="DMG:+10",Aug3="Ranged Accuracy+20"}, -- Mengado +1
    [21344] = {Aug1="Magic Damage+10",Aug2="INT+5",Aug3=""}, -- Ghastly Tathlum +1
    [21350] = {Aug1="L83: Accuracy+10",Aug2="Evasion+10",Aug3=""}, -- Wingcutter +1
    [21403] = {}, -- Damani Horn +1
    [21417] = {Aug1="L91: DEF+20",Aug2="Parrying Skill+10",Aug3=""}, -- Refined Grip +1
    [21419] = {Aug1="Attack+30",Aug2="STR+15",Aug3=""}, -- Rigorous Grip +1
    [21484] = {Aug1="Ranged Attack+45",Aug2="R.Acc. & M.Acc.+40",Aug3="DMG:+5"}, -- Malison +1
    [21689] = {Aug1="DMG:+20",Aug2="Accuracy & Magic Accuracy+40",Aug3="HP+100"}, -- Montante +1
    [21691] = {Aug1="DMG:+28",Aug2="Accuracy & Magic Accuracy+40",Aug3="Cure Potency Recieved+10%"}, -- Ushenzi +1
    [21696] = {Aug1="DMG:+33",Aug2="Accuracy & Magic Accuracy+40",Aug3="Dark Magic Skill+10"}, -- Nullis +1
    [21703] = {Aug1="DMG:+50",Aug2="Accuracy & Magic Accuracy+40",Aug3="Fast Cast+10%"}, -- Kladenets +1
    [21749] = {Aug1="DMG:+21",Aug2="Accuracy & Magic Accuracy+40",Aug3="STR/DEX/CHR+10 / Pet: Acc. & Magic Accuracy+40"}, -- Habilitator +1
    [21806] = {Aug1="DMG:+36",Aug2="Accuracy & Magic Accuracy+40",Aug3="Magic Atk. Bonus+50"}, -- Pixquizpan +1
    [22058] = {Aug1="Magic Accuracy+70",Aug2="Enfeebling Magic Skill+20",Aug3="MND+10"}, -- Contemplator +1
    [22121] = {Aug1="DMG:+17",Aug2="Ranged Accuracy+40",Aug3="Snapshot+10%"}, -- Imati +1
    [22255] = {Aug1="STR+10",Aug2="Haste+5%",Aug3=""}, -- Seeth. Bomblet +1
    [22267] = {Aug1="Magic Evasion+15",Aug2="Double Attack+3%",Aug3=""}, -- Antitail +1
    [25602] = {Aug1="Accuracy & Magic Accuracy+45",Aug2="Critical Hit Rate+10%",Aug3="STR/DEX+25"}, -- Blistering Sallet +1
    [25636] = {Aug1="Enmity+10",Aug2="Damage Taken-10%",Aug3="All Attr.+10"}, -- Loess Barbuta +1
    [25681] = {Aug1="Magic Accuracy +100",Aug2="Magic Attack Bonus +100",Aug3="All Base Stats +20"}, -- Cohort Cloak +1
    [25710] = {Aug1="Magic Evasion+60",Aug2="Enmity+5",Aug3="All Attr.+10"}, -- Obviat. Cuirass +1
    [25733] = {Aug1="Accuracy+30",Aug2="All Attr.+10",Aug3="Triple Attack+5%"}, -- Tatena. Harama. +1
    [25856] = {Aug1="Accuracy+75",Aug2="All Attr.+10",Aug3="Triple Attack+3%"}, -- Tatena. Haidate +1
    [25924] = {Aug1="Accuracy+60",Aug2="All Attr.+10",Aug3="Triple Attack+3%"}, -- Tatena. Sune. +1
    [26002] = {Aug1="DEF+45",Aug2="Spell Interruption Rate-5%",Aug3=""}, -- Loricate Torque +1
    [26022] = {Aug1="Accuracy+15",Aug2="Store TP+10",Aug3=""}, -- Vim Torque +1
    [26402] = {Aug1="Accuracy+15",Aug2="Magic Accuracy+15",Aug3="Enhancing Magic Skill+10"}, -- Forfend +1
    [26710] = {Aug1="L126: Accuracy+35",Aug2="Magic Evasion+100",Aug3="Critical Hit Rate+10%"}, -- Imp. Wing Hair. +1
    [26711] = {}, -- Perle Salade +1
    [26712] = {}, -- Aurore Beret +1
    [26713] = {}, -- Teal Chapeau +1
    [26715] = {Aug1="Accuracy & Magic Accuracy+45",Aug2="Attack+50",Aug3="All Base Stats+10"}, -- Adorned Helm +1
    [26732] = {Aug1="Accuracy & Magic Accuracy+30",Aug2="Physical Damage Limit+5%",Aug3="All Base Stats+10"}, -- Stinger Helm +1
    [26785] = {Aug1="Physical Damage Taken-10%",Aug2="Pet: Damage Taken-5%",Aug3="All Base Stats+10"}, -- Hike Khat +1
    [26787] = {Aug1="All Base Stats+30",Aug2="Evasion+50",Aug3="Acc. / R.Acc. / & M.Acc.+25"}, -- Alhazen Hat +1
    [26869] = {Aug1="Magic Accuracy+45",Aug2="Damage Taken-5%",Aug3="All Base Stats+10"}, -- Ros. Jaseran +1
    [26871] = {Aug1="Evasion+30",Aug2="Accuracy+40",Aug3="All Base Stats+10"}, -- Emet Harness +1
    [26873] = {Aug1="Accuracy+45",Aug2="Double Attack+5%",Aug3="All Base Stats+10"}, -- Hime Domaru +1
    [26888] = {Aug1="Avatar: TP Bonus+300",Aug2="Avatar: Accuracy & Magic Accuracy+30",Aug3="Avatar: All Base Stats+10"}, -- Shomonjijoe +1
    [26897] = {Aug1="L131: Magic Accuracy+60",Aug2="Spell Interruption Rate-20%",Aug3="L133: All Base Stats+20"}, -- Lugra Cloak +1
    [26943] = {Aug1="Attack+60",Aug2="Store TP+10",Aug3="All Base Stats+10"}, -- Agony Jerkin +1
    [27051] = {Aug1="Attack+45",Aug2="Accuracy & Magic Accuracy+30",Aug3="All Base Stats+10"}, -- Kachi. Kote +1
    [27107] = {Aug1="MP+45",Aug2="Avatar: Accuracy & Magic Accuracy+40",Aug3="Avatar: Magic Burst Bonus+10%"}, -- Asteria Mitts +1
    [27109] = {Aug1="Avatar: All Base Stats+30",Aug2="Avatar: Accuracy & Magic Accuracy+40",Aug3="Avatar Perpetuation Cost-5"}, -- Lamassu Mitts +1
    [27149] = {Aug1="Accuracy+40",Aug2="All Attr.+10",Aug3="Triple Attack+4%"}, -- Tatena. Gote +1
    [27151] = {Aug1="Accuracy+50",Aug2="Haste+10%",Aug3="All Base Stats+10"}, -- Gazu Bracelets +1
    [27231] = {Aug1="L149: Accuracy+30",Aug2="Critical Hit Rate+5%",Aug3="All Base Stats+10"}, -- Zoar Subligar +1
    [27408] = {Aug1="Cure Potency+15%",Aug2="Healing Magic Skill+10",Aug3="All Base Stats+10"}, -- Hygieia Clogs +1
    [27410] = {Aug1="Resist Bind+45",Aug2="Evasion+20",Aug3="All Base Stats+10"}, -- Hippo. Socks +1
    [27505] = {Aug1="Skillchain Damage+15%",Aug2="Magic Burst Bonus+10%",Aug3=""}, -- Warder's Charm +1
    [27509] = {Aug1="L110: DEF+30",Aug2="HP+200",Aug3=""}, -- Unmoving Collar +1
    [27518] = {Aug1="Evasion+15",Aug2="Counter+10",Aug3=""}, -- Bathy Choker +1
    [27533] = {Aug1="HP+45",Aug2="Shield Block Rate+3%",Aug3=""}, -- Zwazo Earring +1
    [27543] = {Aug1="Accuracy+10",Aug2="DEX+6",Aug3=""}, -- Domin. Earring +1
    [27549] = {Aug1="DEF+30",Aug2="Damage Taken-3%",Aug3=""}, -- Odnowa Earring +1
    [27559] = {Aug1="Conserve MP+10",Aug2="INT+5",Aug3=""}, -- Mephitas's Ring +1
    [27561] = {Aug1="DEF+20",Aug2="Magic Def. Bonus+5",Aug3=""}, -- Apeile Ring +1
    [27563] = {Aug1="L102: Magic Accuracy+10",Aug2="INT/MND/CHR+10",Aug3=""}, -- Metamor. Ring +1
    [27599] = {}, -- Dew Silk Cape +1
    [27602] = {Aug1="Accuracy+15",Aug2="DEX+10",Aug3=""}, -- Ground. Mantle +1
    [27610] = {Aug1="Fast Cast+10%",Aug2="Spell Interruption Rate-5%",Aug3=""}, -- Fi Follet Cape +1
    [27620] = {Aug1="Accuracy & Magic Accuracy+25",Aug2="INT/MND+25",Aug3=""}, -- Aurist's Cape +1
    [27634] = {}, -- Thorfinn Shield +1
    [27637] = {Aug1="HP+150",Aug2="Shield Skill+10",Aug3="Accuracy & Magic Accuracy+20"}, -- Evalach +1
    [27639] = {Aug1="Shield Block Rate+10%",Aug2="Enhancing Magic Received Duration+10%",Aug3=""}, -- Ajax +1
    [27641] = {Aug1="Accuracy & Magic Accuracy+30",Aug2="Shield Skill+10",Aug3=""}, -- Deliverance +1
    [27851] = {}, -- Perle Hauberk +1
    [27852] = {}, -- Aurore Doublet +1
    [27853] = {}, -- Teal Saio +1
    [27996] = {Aug1="Evasion+90",Aug2="Magic Evasion+80",Aug3="All Base Stats+10"}, -- Shigure Tekko +1
    [27997] = {}, -- Perle Moufles +1
    [27998] = {}, -- Aurore Gloves +1
    [27999] = {}, -- Teal Cuffs +1
    [28135] = {Aug1="L143: Avatar: Accuracy & Magic Accuracy+35",Aug2="L145: Avatar: All Base Stats+20",Aug3="MP+20"}, -- Assid. Pants +1
    [28137] = {Aug1="Attack+60",Aug2="Magic Atk. Bonus+30",Aug3="All Base Stats+10"}, -- Augury Cuisses +1
    [28138] = {}, -- Perle Brayettes +1
    [28139] = {}, -- Aurore Brais +1
    [28140] = {}, -- Teal Slops +1
    [28272] = {}, -- Adsilio Boots +1
    [28274] = {Aug1="L154: Healing Magic Skill+10",Aug2="Enhancing Magic Skill+10",Aug3="L156: All Base Stats+10"}, -- Regal Pumps +1
    [28276] = {Aug1="DEX/AGI+15",Aug2="Magic Evasion+30",Aug3="All Base Stats+10"}, -- Jute Boots +1
    [28277] = {}, -- Perle Sollerets +1
    [28278] = {}, -- Aurore Gaiters +1
    [28279] = {}, -- Teal Pigaches +1
    [28351] = {}, -- Cloud Hairpin +1
    [28353] = {Aug1="L115: Magic Accuracy+15",Aug2="CHR+10",Aug3=""}, -- Canto Necklace +1
    [28413] = {Aug1="STR+10",Aug2="DEX+10",Aug3=""}, -- Kentarch Belt +1
    [28424] = {Aug1="L107: Conserve MP+15",Aug2="Fast Cast+5%",Aug3=""}, -- Shinjutsu-no-Obi +1
    [28428] = {Aug1="L94: STR+15",Aug2="Double Attack+5%",Aug3=""}, -- Sailfi Belt +1
    [28430] = {Aug1="Magic Accuracy+15",Aug2="INT+10",Aug3=""}, -- Acuity Belt +1
    [28482] = {Aug1="L123: DEF+20",Aug2="STR/DEX/VIT/INT+8",Aug3=""}, -- Lugra Earring +1
    [28485] = {Aug1="Resist Silence+15",Aug2="Spell Interruption Rate-5%",Aug3=""}, -- Nourish. Earring +1
    [28487] = {Aug1="L99: Resist Sleep+15",Aug2="Resist Charm+15",Aug3=""}, -- Arete del Luna +1
    [28491] = {Aug1="Pet: Acc. & Magic Accuracy+15",Aug2="Accuracy+10",Aug3=""}, -- Handler's Earring +1
}
