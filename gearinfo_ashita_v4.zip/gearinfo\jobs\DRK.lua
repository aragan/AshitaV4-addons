return {
    code = 'DRK',
    extra2 = false,
    dd_melee = true,
    extra5 = false,
}
