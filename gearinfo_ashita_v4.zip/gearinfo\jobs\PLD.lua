return {
    code = 'PLD',
    extra2 = false,
    dd_melee = false,
    extra5 = true,
    extra_preset = {
        'show_br',
        'show_echr',
        'show_fc',
        'show_cp',
        'show_hms',
        'show_conserve_mp',
        'show_phalanx',
        'show_qc',
        'show_cst',
        'show_hmct',
        'show_emed',
    },
}
