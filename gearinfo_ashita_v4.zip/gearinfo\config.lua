local json = require('json');
local config = {};

local function copy(value, seen)
    if (type(value) ~= 'table') then return value; end
    seen = seen or {};
    if (seen[value] ~= nil) then return seen[value]; end
    local result = {};
    seen[value] = result;
    for key, item in pairs(value) do
        if (type(item) ~= 'function') then result[copy(key, seen)] = copy(item, seen); end
    end
    return result;
end

local function merge(target, source)
    if (type(source) ~= 'table') then return target; end
    for key, value in pairs(source) do
        if (type(value) == 'table' and type(target[key]) == 'table') then
            merge(target[key], value);
        else
            target[key] = copy(value);
        end
    end
    return target;
end

local function scalar(value)
    value = tostring(value or ''):gsub('^%s+', ''):gsub('%s+$', '');
    value = value:gsub('&lt;', '<'):gsub('&gt;', '>'):gsub('&amp;', '&');
    if (value == 'true') then return true; end
    if (value == 'false') then return false; end
    local number = tonumber(value);
    if (number ~= nil) then return number; end
    return value;
end

local function parse_xml(text)
    if (type(text) ~= 'string') then return nil; end
    text = text:gsub('<%?xml.-%?>', ''):gsub('<!%-%-.-%-%->', '');
    local root = {};
    local stack = { root };
    local names = {};
    local position = 1;
    while (true) do
        local first, last, closing, name, self_close = text:find('<%s*(/?)%s*([%w_%-]+).-(/?)%s*>', position);
        if (first == nil) then break; end
        local content = text:sub(position, first - 1);
        if (content:match('%S') and #stack > 1) then
            local parent = stack[#stack - 1];
            parent[names[#names]] = scalar(content);
            stack[#stack] = parent[names[#names]];
        end
        if (closing == '/') then
            if (#stack > 1) then table.remove(stack); table.remove(names); end
        elseif (self_close == '/') then
            stack[#stack][name] = '';
        else
            local node = {};
            stack[#stack][name] = node;
            table.insert(stack, node);
            table.insert(names, name);
        end
        position = last + 1;
    end
    return root.settings and (root.settings.global or root.settings) or root;
end

local function full_path(path)
    path = tostring(path or 'data\\settings.xml'):gsub('/', '\\');
    if (path:match('^%a:[\\/]')) then return path; end
    return addon.path .. path;
end

local function read_all(path)
    local handle = io.open(path, 'rb');
    if (handle == nil) then return nil; end
    local value = handle:read('*a');
    handle:close();
    return value;
end

local function write_all(path, value)
    local parent = path:match('^(.*)[\\/][^\\/]+$');
    if (parent ~= nil) then
        os.execute(('if not exist "%s" mkdir "%s" >nul 2>nul'):format(parent, parent));
    end
    local handle = io.open(path, 'wb');
    if (handle == nil) then return false; end
    handle:write(value);
    handle:close();
    return true;
end

function config.load(path, defaults)
    if (type(path) == 'table' and defaults == nil) then defaults, path = path, 'data\\settings.xml'; end
    local xml_path = full_path(path);
    local json_path = xml_path:gsub('%.xml$', '.json');
    local loaded = nil;
    local json_text = read_all(json_path);
    if (json_text ~= nil) then
        local ok, value = pcall(json.decode, json_text);
        if (ok and type(value) == 'table') then loaded = value; end
    end
    if (loaded == nil) then loaded = parse_xml(read_all(xml_path)); end

    local settings = merge(copy(defaults or {}), loaded or {});
    local methods = {};
    function methods:save(_)
        local plain = copy(self);
        return write_all(json_path, json.encode(plain));
    end
    return setmetatable(settings, { __index = methods });
end

function config.save(settings)
    if (type(settings) == 'table' and type(settings.save) == 'function') then
        return settings:save('all');
    end
end

return config;
