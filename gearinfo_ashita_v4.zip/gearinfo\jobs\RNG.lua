return {
    code = 'RNG',
    extra2 = false,
    dd_melee = false,
    extra5 = false,
}
