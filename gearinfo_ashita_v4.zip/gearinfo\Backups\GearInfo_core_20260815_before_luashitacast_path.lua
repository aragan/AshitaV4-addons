_addon.name = 'GearInfo'
_addon.author = 'Sebyg666; Converted by Aragan'
_addon.version = '3.4.0.0'
_addon.commands = {'gi','gearinfo'}

-- Ensure addon root and aug_gears are on the Lua path.
package.path = package.path .. ';' .. windower.addon_path .. '?.lua;' .. windower.addon_path .. '?\\init.lua;' .. windower.addon_path .. 'aug_gears\\?.lua'


require('tables')
require('lists')
require('sets')
require('strings')
require('logger')
require('pack')
files = require('files')

-- Ensure data folder exists so missing cache files don't break addon load.
pcall(function() files.create_path('data') end)

DW_Gear = require('res/DW_Gear')
Unity_rank = require('res/Unity_Gear')
Martial_Arts_Gear = require('res/Martial_Arts_Gear')
Set_bonus_by_Set_ID= require('res/Set_bonus_by_Set_ID')
Set_bonus_by_item_id = require('res/Set_bonus_by_item_id')
Blu_spells = require('res/Blue_Mage_Spells')
Gifts = require('res/Gifts')
Cor_Rolls = require('res/Cor_Rolls')
Bard_Songs = require('res/Bard_Songs')
Geo_Spells = require('res/Geo_Spells')

res = require('resources')
skills_from_resources = res.skills
ExtdataLib = require("extdata")
Extdata = {}
do
    local ok, mod = pcall(require, "data/Aragan_data")
    if ok and type(mod) == 'table' then
        Extdata = mod
    else
        Extdata = {}
    end
end
config = require('config')
blu_spells = res.spells:type('BlueMagic')
timer = require('timeit')
packets = require('packets')
bit = require('bit')
chat = require('chat')
chars = require('chat.chars')

require 'Statics'
require 'Gear_Processing'
require 'Calculator'
require 'Action_Processing'
require 'Buff_Processing'

Aug_SR = require('aug_gears/Aug_SR')

local function apply_aug_sr_to_item(item)
	if not item or not Aug_SR or not item.id then
		return item
	end
	if type(item.augments) == 'table' and table.length(item.augments) > 0 then
		return item
	end
	if item['Aug_SR_Source'] then
		return item
	end
	local aug = Aug_SR[item.id]
	if not aug then
		return item
	end
	for stat, val in pairs(aug) do
		if type(val) == 'number' then
			if item[stat] then
				item[stat] = item[stat] + val
			else
				item[stat] = val
			end
			item._aug_only = item._aug_only or T{}
			if item._aug_only[stat] then
				item._aug_only[stat] = item._aug_only[stat] + val
			else
				item._aug_only[stat] = val
			end
		end
	end
	item['Aug_SR_Source'] = true
	if debug_mode then
		windower.add_to_chat(207, '[GI DEBUG] Aug_SR applied to '..tostring(item.en)..' id='..tostring(item.id))
		for stat, val in pairs(aug) do
			windower.add_to_chat(207, '[GI DEBUG]   '..tostring(stat)..'='..tostring(val))
		end
	end
	return item
end
require 'Packet_parsing'
require 'Image_processing'

local function apply_display_style()
	if not settings or not settings.display then
		return
	end
	local style = tostring(settings.display.style or 'box'):lower()
	local flat = (style == 'flat' or style == 'text' or style == 'plain')
	local theme_id = tonumber(settings.display.flat_theme) or 1
	if theme_id < 1 then theme_id = 1 end
	if theme_id > 40 then theme_id = 40 end
	local function hsl_to_rgb(h, s, l)
		h = h / 360
		local function hue2rgb(p, q, t)
			if t < 0 then t = t + 1 end
			if t > 1 then t = t - 1 end
			if t < 1/6 then return p + (q - p) * 6 * t end
			if t < 1/2 then return q end
			if t < 2/3 then return p + (q - p) * (2/3 - t) * 6 end
			return p
		end
		local r, g, b
		if s == 0 then
			r, g, b = l, l, l
		else
			local q = l < 0.5 and l * (1 + s) or (l + s - l * s)
			local p = 2 * l - q
			r = hue2rgb(p, q, h + 1/3)
			g = hue2rgb(p, q, h)
			b = hue2rgb(p, q, h - 1/3)
		end
		return math.floor(r * 255 + 0.5), math.floor(g * 255 + 0.5), math.floor(b * 255 + 0.5)
	end
	local themes = {
		[1] = {bg = {0, 0, 0, 140}, text = {255, 255, 255}},
		[2] = {bg = {20, 20, 20, 160}, text = {255, 255, 255}},
		[3] = {bg = {10, 30, 60, 160}, text = {255, 255, 255}},
		[4] = {bg = {60, 15, 15, 160}, text = {255, 255, 255}},
		[5] = {bg = {10, 60, 10, 160}, text = {255, 255, 255}},
		[6] = {bg = {70, 50, 0, 170}, text = {255, 255, 255}},
		[7] = {bg = {200, 200, 200, 120}, text = {0, 0, 0}},
		[8] = {bg = {80, 80, 80, 180}, text = {255, 255, 255}},
		[9] = {bg = {0, 0, 0, 200}, text = {120, 255, 255}},
	}
	local theme = themes[theme_id]
	if not theme then
		local idx = theme_id - 10
		local hue = (idx * 360 / 31) % 360
		local light = 0.14 + ((idx % 3) * 0.03)
		local r, g, b = hsl_to_rgb(hue, 0.55, light)
		theme = {bg = {r, g, b, 165}, text = {255, 255, 255}}
	end
	local bg_alpha = tonumber(settings.display.bg_alpha) or 5
	if bg_alpha < 0 then bg_alpha = 0 end
	if bg_alpha > 9 then bg_alpha = 9 end
	local flat_alpha = math.floor((bg_alpha / 9) * 200 + 0.5)
	if sections and sections.background and sections.background.image_alpha then
		if flat then
			if settings.display.bg_image and settings.display.bg_image ~= '' then
				-- Keep the texture colors visible
				sections.background:image_color(255, 255, 255)
			else
				sections.background:image_color(theme.bg[1], theme.bg[2], theme.bg[3])
			end
			sections.background:image_alpha(flat_alpha)
		else
			sections.background:image_color(0, 0, 0)
			sections.background:image_alpha(0)
		end
	end
	if sections and sections.background and sections.background.name then
		if settings.display.bg_image and settings.display.bg_image ~= '' then
			local path = windower.addon_path..'images/'..settings.display.bg_image
			sections.background.image_path = path
			windower.prim.set_texture(sections.background.name, path)
			windower.prim.set_fit_to_texture(sections.background.name, false)
			if sections.background.width and sections.background.height then
				windower.prim.set_size(sections.background.name, sections.background.width, sections.background.height)
			end
		else
			sections.background.image_path = ''
			windower.prim.set_texture(sections.background.name, '')
		end
	end
	if sections and sections.block then
		for _, block in pairs(sections.block) do
			if block and block.image_alpha then
				block:image_alpha(flat and 0 or 255)
			end
			if block and block.text and block.text[1] and block.text[2] then
				if flat then
					windower.text.set_color(block.text[1].name, 255, theme.text[1], theme.text[2], theme.text[3])
					windower.text.set_color(block.text[2].name, 255, theme.text[1], theme.text[2], theme.text[3])
				else
					windower.text.set_color(block.text[1].name, 255, 255, 255, 255)
					windower.text.set_color(block.text[2].name, 255, 255, 255, 255)
				end
			end
		end
	end
end

local function apply_display_fonts()
	if not settings or not settings.display then
		return
	end
	local label_font = settings.display.label_font or "Tahoma"
	local value_font = settings.display.value_font or "Tahoma"
	if sections and sections.block then
		for _, block in pairs(sections.block) do
			if block and block.text and block.text[1] then
				windower.text.set_font(block.text[1].name, label_font)
			end
			if block and block.text and block.text[2] then
				windower.text.set_font(block.text[2].name, value_font)
			end
		end
	end
end

-- Re-center text for a few frames after content changes to avoid one-frame
-- stale width measurements in flat/text style.
local _text_layout_dirty_frames = 3
local _gs_last_payload = nil
local _gs_last_send_at = 0
local _gs_min_interval = 2.00

local function safe_set_text(block, idx, text)
	if block and block.text and block.text[idx] then
		local new_text = text
		if new_text == nil then
			new_text = ''
		elseif type(new_text) ~= 'string' then
			new_text = tostring(new_text)
		end
		local current_text = block.text[idx].text
		if current_text == nil then
			current_text = ''
		elseif type(current_text) ~= 'string' then
			current_text = tostring(current_text)
		end
		if current_text ~= new_text then
			block.text[idx].text = new_text
			_text_layout_dirty_frames = math.max(_text_layout_dirty_frames or 0, 3)
			windower.text.set_text(block.text[idx].name, new_text)
		end
	end
end

local function safe_set_color(block, idx, alpha, r, g, b)
	if block and block.text and block.text[idx] then
		local t = block.text[idx]
		local color_key = tostring(alpha) .. ':' .. tostring(r) .. ':' .. tostring(g) .. ':' .. tostring(b)
		if t._last_color_key ~= color_key then
			t._last_color_key = color_key
			windower.text.set_color(t.name, alpha, r, g, b)
		end
	end
end

-- Ensure an existing block also picks up a new texture color immediately.
local gi_check_slot_order = {
	'main', 'sub', 'range', 'ammo',
	'head', 'body', 'hands', 'legs', 'feet',
	'neck', 'waist', 'left_ear', 'right_ear',
	'left_ring', 'right_ring', 'back'
}

local gi_check_meta_keys = {
	id = true,
	en = true,
	enl = true,
	ja = true,
	jal = true,
	category = true,
	slots = true,
	skill = true,
	type = true,
	["Set Bonus"] = true
}

local function gi_check_collect_non_zero_stats(item)
	local out = {}
	if type(item) ~= 'table' then
		return out
	end
	for key, val in pairs(item) do
		if type(key) == 'string' and not gi_check_meta_keys[key] and key:sub(1, 1) ~= '_' then
			if type(val) == 'number' and val ~= 0 then
				out[#out + 1] = { key, tostring(val) }
			elseif type(val) == 'boolean' and val then
				out[#out + 1] = { key, 'true' }
			end
		end
	end
	table.sort(out, function(a, b)
		return a[1]:lower() < b[1]:lower()
	end)
	return out
end

local function gi_check_print_stats_lines(prefix, pairs_list)
	if not pairs_list or #pairs_list == 0 then
		log(prefix .. '(no non-zero stats)')
		return
	end
	local line = ''
	local per_line = 4
	local count = 0
	for i = 1, #pairs_list do
		local part = pairs_list[i][1] .. '=' .. pairs_list[i][2]
		if line == '' then
			line = part
		else
			line = line .. ', ' .. part
		end
		count = count + 1
		if count >= per_line then
			log(prefix .. line)
			line = ''
			count = 0
		end
	end
	if line ~= '' then
		log(prefix .. line)
	end
end

local function gi_check_dump_equipped_items()
	local equip = check_equipped()
	log('--- GI CHECK: equipped computed item stats ---')
	local shown = 0
	for _, slot in ipairs(gi_check_slot_order) do
		local item = equip and equip[slot]
		if item and item.id and item.id ~= 0 then
			shown = shown + 1
			log(slot .. ': ' .. tostring(item.en or '?') .. ' (id=' .. tostring(item.id) .. ')')
			gi_check_print_stats_lines('  ', gi_check_collect_non_zero_stats(item))
			if type(item._aug_only) == 'table' then
				local aug_only_stats = gi_check_collect_non_zero_stats(item._aug_only)
				if #aug_only_stats > 0 then
					gi_check_print_stats_lines('  aug_only: ', aug_only_stats)
				end
			end
		end
	end
	if shown == 0 then
		log('No equipped items found.')
	end
end

local font_presets = {
	a = "Tahoma",
	b = "Verdana",
	c = "Arial",
	d = "Calibri",
	e = "Segoe UI",
	f = "Consolas",
	g = "Courier New",
	h = "Trebuchet MS",
	i = "Georgia",
	j = "Times New Roman",
	k = "Comic Sans MS",
}

local function print_extra_help(chat_l_blue, chat_white, chat_d_blue)
	chat_l_blue = chat_l_blue or ''
	chat_white = chat_white or ''
	chat_d_blue = chat_d_blue or ''

	windower.add_to_chat(6, ' ')
	windower.add_to_chat(6, chat_d_blue .. 'EXTRA Help (GearInfo)')
	windower.add_to_chat(6, chat_l_blue .. '\'//gi extra help\'' .. chat_white .. '  --  Show EXTRA commands only.')
	windower.add_to_chat(6, chat_l_blue .. '\'//gi show extra\'' .. chat_white .. '  --  EXTRA 1 (main extra group).')
	windower.add_to_chat(6, chat_l_blue .. '\'//gi show extra2..extra34\'' .. chat_white .. '  --  Toggle specific EXTRA group.')
	windower.add_to_chat(6, chat_l_blue .. '\'//gi show extra all|extraall\'' .. chat_white .. '  --  Toggle all extra groups.')
	windower.add_to_chat(6, chat_l_blue .. 'EXTRA 1-34: 1=extra, 2..34=extra2..extra34.' .. chat_white)
	windower.add_to_chat(6, chat_l_blue .. '7:stats 8:TH 9:FC 10:CP/CP2 11:ECHR 12:Waltz 13:BR 14:Zanshin 15:TPB 16:Killer 17:Samba' .. chat_white)
	windower.add_to_chat(6, chat_l_blue .. '18:HMS 19:Phalanx 20:QC/CST/HMCT 21:Snapshot/RS 22:EMCT 23:INQ 24:EMED 25:Steal/SA/TA 26:Songs' .. chat_white)
	windower.add_to_chat(6, chat_l_blue .. '27:Pet+Indicolure 28:BP/Pet 29:PetPDT/MDT 30:PetHaste 31:Cursna 32:MAB-only 33:PDL+SC 34:Crit/SB only' .. chat_white)
	windower.add_to_chat(6, ' ')
end

local function refresh_display()
	-- Ensure Dual Wield block is never hidden by filters/slots/modes
	if settings and settings.player then
		settings.player.show_DW_Stuff = true
	end
	if sections and sections.logo then
		sections.logo:delete()
		sections.logo = nil
	end
	-- Keep DW forced on, but preserve user's AugOnly toggle state.
	if settings and settings.player then
		settings.player.show_DW_Stuff = true
	end
	if sections and sections.block then
		for _, block in pairs(sections.block) do
			block:delete()
		end
		sections.block = {}
	end
	if type(check_positions) == 'function' then
		check_positions()
	end
	_text_layout_dirty_frames = math.max(_text_layout_dirty_frames or 0, 5)
end

local function reset_display_boxes()
	if not defaults or not defaults.player or not settings or not settings.player then
		return
	end
	for key, val in pairs(defaults.player) do
		if type(key) == 'string' and key:match('^show_') then
			if key ~= 'show_COR_messages' then
				settings.player[key] = val
			end
		end
	end
	settings.player.extra_all_override = false
	settings:save('all')
	log('Display boxes reset to defaults.')
end

local function snapshot_show_flags()
	local snap = {}
	if settings and settings.player then
		for key, val in pairs(settings.player) do
			if type(key) == 'string' and key:match('^show_') then
				snap[key] = val
			end
		end
	end
	return snap
end

local function apply_show_flags(snap)
	if not snap or not settings or not settings.player then
		return
	end
	for key, val in pairs(snap) do
		settings.player[key] = val
	end
end

local function set_all_show_flags(state)
	if not settings or not settings.player then
		return
	end
	local sources = {}
	if defaults and defaults.player then
		table.insert(sources, defaults.player)
	end
	table.insert(sources, settings.player)
	for _, src in ipairs(sources) do
		for key, _ in pairs(src) do
			if type(key) == 'string' and key:match('^show_') then
				if key ~= 'show_COR_messages' and key ~= 'show_logo' and key ~= 'show_aug_only' then
					settings.player[key] = state
				end
			end
		end
	end
	-- Keep Augments-only off unless the user explicitly toggles it.
	settings.player.show_aug_only = false
end

local calc_mode_active = false
local calc_mode_backup = nil
local calc_mode_visible_cache = {}
local calc_mode_limit = nil
local calc_mode_next_refresh_at = 0

local function text_has_positive_number(txt)
	if not txt then
		return false
	end
	local s = tostring(txt)
	for n in s:gmatch('[-+]?%d+%.?%d*') do
		local v = tonumber(n)
		if v and v > 0 then
			return true
		end
	end
	return false
end

local function set_block_and_text_visibility(block, state)
	if not block then
		return
	end
	if state then
		block:show()
	else
		block:hide()
	end
	if block.text and block.text[1] then
		windower.text.set_visibility(block.text[1].name, state)
	end
	if block.text and block.text[2] then
		windower.text.set_visibility(block.text[2].name, state)
	end
end

local function apply_calc_mode_visibility(force)
	if not calc_mode_active or not sections or not sections.block then
		return
	end
	if not force then
		local now = os.clock()
		if now < calc_mode_next_refresh_at then
			return
		end
		calc_mode_next_refresh_at = now + 0.25
	end
	local ordered = {}
	for idx, block in pairs(sections.block) do
		if block and block.order then
			ordered[#ordered + 1] = {idx = idx, block = block, order = block.order}
		end
	end
	table.sort(ordered, function(a, b)
		return a.order < b.order
	end)

	local shown = 0
	local layout_changed = false
	for _, entry in ipairs(ordered) do
		local idx = entry.idx
		local block = entry.block
		if block and block.text and block.text[2] then
			local value_text = block.text[2].text
			local should_show = text_has_positive_number(value_text)
			if should_show and calc_mode_limit and shown >= calc_mode_limit then
				should_show = false
			end
			if should_show then
				shown = shown + 1
			end
			if calc_mode_visible_cache[idx] == nil or calc_mode_visible_cache[idx] ~= should_show then
				set_block_and_text_visibility(block, should_show)
				calc_mode_visible_cache[idx] = should_show
				layout_changed = true
			end
		end
	end
	if layout_changed and type(check_positions) == 'function' then
		check_positions()
	end
end

local function enable_calc_mode(limit)
	local num_limit = tonumber(limit)
	if num_limit ~= nil then
		num_limit = math.floor(num_limit)
		if num_limit < 1 then num_limit = 1 end
		if num_limit > 8 then num_limit = 8 end
	else
		num_limit = nil
	end
	if not calc_mode_active then
		calc_mode_backup = snapshot_show_flags()
	end
	set_all_show_flags(true)
	calc_mode_visible_cache = {}
	calc_mode_limit = num_limit
	calc_mode_active = true
	calc_mode_next_refresh_at = 0
	settings.player.show_aug_only = false
	settings:save('all')
	if calc_mode_limit then
		log('Calc mode = ON (show only values > 0, limit=' .. tostring(calc_mode_limit) .. ')')
	else
		log('Calc mode = ON (show only values > 0)')
	end
	refresh_display()
	mode_refresh_pending = true
end

local function disable_calc_mode()
	if not calc_mode_active then
		return
	end
	if calc_mode_backup then
		apply_show_flags(calc_mode_backup)
	end
	calc_mode_visible_cache = {}
	calc_mode_backup = nil
	calc_mode_limit = nil
	calc_mode_active = false
	settings.player.show_aug_only = false
	settings:save('all')
	log('Calc mode = OFF')
	refresh_display()
	mode_refresh_pending = true
end

local function calc_block_dimensions()
	local size = 5
	if settings and settings.display and settings.display.size then
		size = tonumber(settings.display.size) or 5
	end
	if size < 1 then size = 1 end
	if size > 9 then size = 9 end
	local scale = size / 5
	local width = math.floor((57 * scale) + 0.5)
	local height = math.floor((42 * scale) + 0.5)
	if width < 24 then width = 24 end
	if height < 18 then height = 18 end
	return width, height
end

local parse_gearswap_back
local parse_gearswap_escha
-- Forward declarations for PDT sanity helpers used by command handlers.
local text_mentions_pdt
local augments_mentions_pdt
local base_desc_mentions_pdt
local purge_pdt_fields
local maybe_purge_suspicious_pdt
local auto_parse_gearswap_done = false
local parse_gearswap_escha
local test_mode_active = false
local test_mode_backup = nil
local test_job_active = false
local test_job_backup = nil
local test_mode_pending = false
local mode_refresh_pending = false
GI_test_mode_active = false
GI_test_haste_g = nil
GI_test_haste_m = nil
GI_test_haste_j = nil
-- Cache equipped result to avoid expensive full scan/re-parse on every update tick.
local equipped_cache_signature = nil
local equipped_cache_table = nil
local full_gear_index_by_id = nil
local gear_info_cache_signature = nil
local gear_info_cache_aug_only = nil
local gear_info_cache_value = nil
local gear_info_pending_signature = nil
local gear_info_pending_since = 0
local GEAR_INFO_STABLE_DELAY = 0.30
local GI_ULTRA_LIGHT_MODE = true

local function build_quick_item(item)
	local id = (type(item) == 'table' and item.id) or 0
	local base = nil
	if id and id ~= 0 and res and res.items then
		base = res.items:with('id', id)
	end
	return {
		id = id or 0,
		en = (base and base.en) or '',
		category = (base and base.category) or '',
		delay = (base and base.delay) or 0,
		damage = (base and base.damage) or 0,
		skill = (base and base.skill) or '',
		slots = (base and base.slots) or nil,
		augments = '',
	}
end

local function invalidate_equipped_cache()
	equipped_cache_signature = nil
	equipped_cache_table = nil
	gear_info_cache_signature = nil
	gear_info_cache_aug_only = nil
	gear_info_cache_value = nil
	gear_info_pending_signature = nil
	gear_info_pending_since = 0
end

local function invalidate_full_gear_index()
	full_gear_index_by_id = nil
end

local function build_full_gear_index()
	if full_gear_index_by_id then
		return
	end
	full_gear_index_by_id = {}
	if type(full_gear_table_from_file) ~= 'table' then
		return
	end
	for _, entry in ipairs(full_gear_table_from_file) do
		local id = entry and entry.id
		if id and id ~= 0 then
			if not full_gear_index_by_id[id] then
				full_gear_index_by_id[id] = {}
			end
			full_gear_index_by_id[id][#full_gear_index_by_id[id] + 1] = entry
		end
	end
end

local function get_cached_candidates(item_id)
	if not item_id or item_id == 0 then
		return nil
	end
	build_full_gear_index()
	return full_gear_index_by_id and full_gear_index_by_id[item_id]
end

local function get_equipped_signature()
	local items = windower.ffxi.get_items()
	local eq = items and items.equipment
	if not eq then
		return nil
	end
	local slots = {
		'main','sub','range','ammo','head','body','hands','legs','feet',
		'neck','waist','left_ear','right_ear','left_ring','right_ring','back'
	}
	local parts = {}
	for _, slot in ipairs(slots) do
		local bag = eq[slot .. '_bag'] or 0
		local pos = eq[slot] or 0
		parts[#parts + 1] = tostring(bag) .. ':' .. tostring(pos)
	end
	return table.concat(parts, '|')
end

local function get_current_equip_cached()
	local sig = get_equipped_signature()
	if sig and equipped_cache_signature == sig and type(equipped_cache_table) == 'table' then
		return equipped_cache_table
	end
	local fresh = check_equipped()
	equipped_cache_signature = sig
	equipped_cache_table = fresh
	return fresh
end

-- Shared accessor for other modules (e.g. packet parsing) to avoid heavy re-parse.
_G.get_current_equip_cached = get_current_equip_cached

local only_mode_active = false
local only_mode_backup = nil
local only_mode_key = nil
local job_extra_toggle_active = false
local job_extra_toggle_key = nil
local job_extra_toggle_backup = nil
local job_slot_toggle_active = false
local job_slot_toggle_key = nil
local job_slot_toggle_backup = nil
local job_mode_toggle_active = false
local job_mode_toggle_key = nil
local job_mode_toggle_backup = nil

local function clear_job_toggle_state(which, main_job_key)
	if which == 'mode' then
		if job_mode_toggle_active and job_mode_toggle_backup then
			apply_show_flags(job_mode_toggle_backup.show)
			if job_mode_toggle_backup.extra_all_override ~= nil then
				settings.player.extra_all_override = job_mode_toggle_backup.extra_all_override
			end
			if job_mode_toggle_backup.mode then
				settings.display.mode = job_mode_toggle_backup.mode
			end
		end
		job_mode_toggle_active = false
		job_mode_toggle_key = nil
		job_mode_toggle_backup = nil
		if settings.player.job_visibility_active_mode then
			settings.player.job_visibility_active_mode[main_job_key] = nil
		end
		if settings.player.job_visibility_active_mode_slot then
			settings.player.job_visibility_active_mode_slot[main_job_key] = nil
		end
	elseif which == 'slot' then
		if job_slot_toggle_active and job_slot_toggle_backup then
			apply_show_flags(job_slot_toggle_backup.show)
			if job_slot_toggle_backup.extra_all_override ~= nil then
				settings.player.extra_all_override = job_slot_toggle_backup.extra_all_override
			end
			if job_slot_toggle_backup.mode then
				settings.display.mode = job_slot_toggle_backup.mode
			end
		end
		job_slot_toggle_active = false
		job_slot_toggle_key = nil
		job_slot_toggle_backup = nil
		if settings.player.job_visibility_active_slot then
			settings.player.job_visibility_active_slot[main_job_key] = nil
		end
	elseif which == 'extra' then
		if job_extra_toggle_active and job_extra_toggle_backup then
			apply_show_flags(job_extra_toggle_backup.show)
			if job_extra_toggle_backup.extra_all_override ~= nil then
				settings.player.extra_all_override = job_extra_toggle_backup.extra_all_override
			end
		end
		job_extra_toggle_active = false
		job_extra_toggle_key = nil
		job_extra_toggle_backup = nil
		if settings.player.job_visibility_active_extra_slot then
			settings.player.job_visibility_active_extra_slot[main_job_key] = nil
		end
	end
end

local function clear_conflicting_job_toggles(target, main_job_key)
	if target ~= 'mode' then
		clear_job_toggle_state('mode', main_job_key)
	end
	if target ~= 'slot' then
		clear_job_toggle_state('slot', main_job_key)
	end
	if target ~= 'extra' then
		clear_job_toggle_state('extra', main_job_key)
	end
end

-- Nyame Path B pieces: force fresh parsing to avoid stale cached augments
local nyame_ids = {
	[23761]=true,[23768]=true,[23775]=true,[23782]=true,[23789]=true
}
local nyame_cache_refreshed = {}
local cache_refresh_once = {}
local pdt_sanity_refresh_once = {}
local parsed_item_ids = {}
local cache_save_pending = false
local cache_save_last = 0
local CACHE_SAVE_COOLDOWN = 1.0

local function is_accessory_item(id)
	if not id or not res or not res.items then
		return false
	end
	local item = res.items:with('id', id)
	if not item or type(item.slots) ~= 'table' then
		return false
	end
	for _, slot_id in pairs(item.slots) do
		local slot = res.slots:with('id', slot_id)
		local name = slot and slot.en
		if name == 'Left Ear' or name == 'Right Ear'
			or name == 'Left Ring' or name == 'Right Ring'
			or name == 'Neck' or name == 'Waist'
			or name == 'Back' then
			return true
		end
	end
	return false
end

local extra2_jobs = {BLM = true, SCH = true, BLU = true, RDM = true, GEO = true}
local dd_melee_jobs = {WAR = true, MNK = true, THF = true, DRK = true, BST = true, SAM = true, NIN = true, DRG = true, PUP = true, DNC = true}
local extra5_jobs = {RUN = true, PLD = true, WHM = true}
local last_main_job = ''
local job_show_keys = {
	'show_total_haste',
	'show_tp_Stuff',
	'show_acc_Stuff',
	'show_dt_Stuff',
	'show_att_Stuff',
	'show_Evasion',
	'show_Defence',
	'show_STP',
	'show_DW_Stuff',
	'show_MA_Stuff',
	'show_qa_da_ta',
	'show_total_da_ta_qa',
	'show_sc_bonus',
	'show_sc_damage',
	'show_mab',
	'show_mbd',
	'show_mbd2',
	'show_pdl',
	'show_sird',
	'show_int',
	'show_macc',
	'show_regen',
	'show_regain',
	'show_refresh',
	'show_parry',
	'show_enmity',
	'show_crit_rate',
	'show_crit_damage',
	'show_subtle_blow',
	'show_subtle_blow_ii',
	'show_magic_damage',
	'show_magic_def_bonus',
	'show_magic_evasion',
	'show_counter',
	'show_conserve_mp',
	'show_stats',
	'show_th',
	'show_fc',
	'show_cp',
	'show_cp2',
	'show_echr',
	'show_waltz',
	'show_br',
	'show_zanshin',
	'show_tpb',
	'show_killer',
	'show_samba',
	'show_hms',
	'show_phalanx',
	'show_qc',
	'show_cst',
	'show_hmct',
	'show_snapshot',
	'show_rapid_shot',
	'show_emct',
	'show_inq',
	'show_emed',
	'show_steal',
	'show_sa',
	'show_ta',
	'show_allsongs',
	'show_sed',
	'show_sst',
	'show_pr',
	'show_petdt',
	'show_ied',
	'show_petpdt',
	'show_petmdt',
	'show_pethaste',
	'show_bpd',
	'show_bpd2',
	'show_bpdmg',
	'show_apc',
	'show_pmab',
	'show_patt',
	'show_pda',
	'show_pacc',
	'show_pmacc',
	'show_sms',
	'show_pbpd',
	'show_pmdmg',
	'show_cursna',
}

local core_show_keys = {
	show_total_haste = true,
	show_tp_Stuff = true,
	show_acc_Stuff = true,
	show_dt_Stuff = true,
	show_att_Stuff = true,
	show_Evasion = true,
	show_Defence = true,
	show_STP = true,
	show_DW_Stuff = true,
	show_MA_Stuff = true,
	show_qa_da_ta = true,
	show_total_da_ta_qa = true,
}

local main_show_keys = {
	'show_total_haste',
	'show_dt_Stuff',
	'show_tp_Stuff',
	'show_acc_Stuff',
	'show_att_Stuff',
	'show_Evasion',
	'show_Defence',
	'show_STP',
}

local job_extra_presets = {
	DNC = {'show_waltz','show_samba'},
	PLD = {'show_br','show_echr','show_fc','show_cp','show_hms','show_conserve_mp','show_phalanx','show_qc','show_cst','show_hmct','show_emed'},
	SAM = {'show_zanshin','show_tpb','show_mab','show_macc'},
	SMN = {'show_pethaste','show_apc','show_bpdmg','show_bpd','show_bpd2','show_petdt','show_petpdt','show_petmdt','show_pr','show_fc','show_sms','show_pmacc','show_pacc','show_pda','show_patt','show_pmab'},
	PUP = {'show_pethaste','show_petdt','show_petpdt','show_petmdt','show_pr','show_pmacc','show_pacc','show_pda','show_patt','show_pmab'},
	BST = {'show_pethaste','show_petdt','show_petpdt','show_petmdt','show_pr','show_pmacc','show_pacc','show_pda','show_patt','show_pmab'},
	RUN = {'show_echr','show_phalanx','show_inq','show_emed','show_fc'},
	BRD = {'show_allsongs','show_sed','show_sst'},
	WHM = {'show_cursna','show_emed','show_hmct','show_cst','show_qc','show_hms','show_cp','show_cp2','show_stats','show_sird'},
	SCH = {'show_cursna','show_emed','show_hmct','show_cst','show_qc','show_hms','show_cp','show_cp2','show_phalanx','show_stats','show_sird'},
	COR = {'show_snapshot','show_rapid_shot','show_tpb','show_crit_rate','show_subtle_blow','show_mab','show_magic_damage','show_int','show_macc','show_acc_Stuff'},
	GEO = {'show_ied','show_pr','show_petdt','show_fc','show_conserve_mp','show_sird','show_magic_damage','show_mab','show_mbd'},
	RDM = {'show_phalanx','show_macc','show_emed','show_fc','show_qc','show_conserve_mp'},
	THF = {'show_sa','show_ta','show_steal','show_th'},
	WAR = {'show_tpb','show_br'},
	DRG = {'show_petdt'},
}

local function clear_extra_flags()
	for _, key in ipairs(job_show_keys) do
		if not core_show_keys[key] and key ~= 'show_COR_messages' and key ~= 'show_logo' and key ~= 'show_aug_only' then
			settings.player[key] = false
		end
	end
end

local function apply_job_extra_preset(main_job)
	local preset = job_extra_presets[main_job]
	if type(preset) ~= 'table' then
		return false
	end
	clear_extra_flags()
	for _, key in ipairs(preset) do
		settings.player[key] = true
	end
	return true
end

local function toggle_group(keys)
	local any_off = false
	for _, key in ipairs(keys) do
		if settings.player[key] == false then
			any_off = true
			break
		end
	end
	for _, key in ipairs(keys) do
		settings.player[key] = any_off
	end
end

local function capture_job_show_state()
	local state = {}
	for _, key in ipairs(job_show_keys) do
		state[key] = settings.player[key] == true
	end
	return state
end

local function apply_job_show_state(state)
	if type(state) ~= 'table' then
		return
	end
	for _, key in ipairs(job_show_keys) do
		if state[key] ~= nil then
			settings.player[key] = state[key] == true
		end
	end
	-- Force DW display to behave like the original addon (always on, regardless of saved/loaded state)
	-- This bypasses job/slot/mode visibility filters so the DW/Need block is always shown.
	settings.player.show_DW_Stuff = true
	-- Keep Augments-only state independent from job visibility presets.
end

local function normalize_job_slot(slot)
	local n = tonumber(slot)
	if not n then
		return nil
	end
	if n < 1 then n = 1 end
	if n > 9 then n = 9 end
	return math.floor(n)
end

local job_mode_aliases = {
	healer = 'healer',
	heal = 'healer',
	h = 'healer',
	he = 'healer',
	whm = 'healer',
	magic = 'magic_attack',
	magicattack = 'magic_attack',
	magic_attack = 'magic_attack',
	mattack = 'magic_attack',
	ma = 'magic_attack',
	mb = 'magic_attack',
	tank = 'tank',
	t = 'tank',
	ta = 'tank',
	pet = 'pet',
	p = 'pet',
	pe = 'pet',
	dd = 'dd',
	d = 'dd',
	melee = 'dd',
	test = 'test',
	te = 'test',
}

local function normalize_job_mode(args, start_idx)
	local parts = {}
	for i = (start_idx or 1), #args do
		local a = tostring(args[i] or ''):lower()
		-- ignore numeric slot tokens (e.g. "2" in: //gi job mode healer 2)
		if a ~= '' and a ~= 'only' and not a:match('^%d+$') then
			parts[#parts+1] = a
		end
	end
	local raw = table.concat(parts, ' ')
	raw = (raw or ''):lower():gsub('[%s_-]+', '')
	if raw == '' then
		return nil
	end
	return job_mode_aliases[raw]
end

local function has_only(args)
	for _, a in ipairs(args or {}) do
		if tostring(a):lower() == 'only' then
			return true
		end
	end
	return false
end

local function normalize_command_aliases(command, args)
	if type(command) ~= 'string' then
		return command, args
	end
	args = args or {}
	for i = 1, #args do
		if type(args[i]) == 'string' then
			args[i] = args[i]:lower()
		end
	end

	if command == 'so' or command == 'sh' then
		command = 'show'
	elseif command == 'sa' then
		command = 'save'
	elseif command == 'a' then
		command = 'add'
	elseif command == 'rm' then
		command = 'remove'
	elseif command == 'hi' or command == 'hd' then
		command = 'hide'
	elseif command == 'j' then
		command = 'job'
	elseif command == 'm' then
		command = 'mode'
	elseif command == 'p' then
		command = 'parse'
	elseif command == 're' then
		command = 'reload'
	elseif command == 'he' then
		command = 'help'
	elseif command == 'ul' or command == 'lite' then
		command = 'ultralight'
	elseif command == 'tb' then
		command = 'turbo'
	elseif command == 's' then
		-- Keep legacy //gi s wstp|job for save, otherwise treat //gi s ... as show.
		local a1 = tostring(args[1] or ''):lower()
		if a1 == '' or a1 == 'wstp' or a1 == 'job' then
			command = 'save'
		else
			command = 'show'
		end
	elseif command == 'augonly' then
		-- Allow direct usage: //gi augonly on|off|status
		table.insert(args, 1, 'augonly')
		command = 'show'
	end

	local function norm_sub_token(v)
		v = tostring(v or ''):lower()
		if v == 'e' or v == 'ex' then
			return 'extra'
		end
		if v == 'm' or v == 'mo' then
			return 'mode'
		end
		return v
	end

	if command == 'show' or command == 'save' or command == 'job'
		or command == 'add' or command == 'remove' or command == 'hide' then
		if args[1] then args[1] = norm_sub_token(args[1]) end
		if args[2] then args[2] = norm_sub_token(args[2]) end
	end

	return command, args
end
local function parse_job_slots_from_args(args, start_idx)
	local slots = {}
	local seen = {}
	for i = (start_idx or 1), #args do
		local a = tostring(args[i] or ''):lower()
		if a ~= '' and a ~= 'only' then
			-- Support compact form: "23456"
			if a:match('^%d%d+$') then
				for d in a:gmatch('%d') do
					local n = normalize_job_slot(d)
					if n and not seen[n] then
						seen[n] = true
						slots[#slots+1] = n
					end
				end
			else
				local n = normalize_job_slot(a)
				if n and not seen[n] then
					seen[n] = true
					slots[#slots+1] = n
				end
			end
		end
	end
	table.sort(slots)
	return slots
end

local function ensure_job_visibility_tables()
	settings.player.job_visibility = settings.player.job_visibility or {}
	settings.player.job_visibility_slots = settings.player.job_visibility_slots or {}
	settings.player.job_visibility_extras = settings.player.job_visibility_extras or {}
	settings.player.job_visibility_modes = settings.player.job_visibility_modes or {}
	settings.player.job_visibility_active_slot = settings.player.job_visibility_active_slot or {}
	settings.player.job_visibility_active_extra_slot = settings.player.job_visibility_active_extra_slot or {}
	settings.player.job_visibility_active_mode = settings.player.job_visibility_active_mode or {}
	settings.player.job_visibility_active_mode_slot = settings.player.job_visibility_active_mode_slot or {}
end

local function normalize_job_visibility_keys()
	local key_tables = {
		'job_visibility',
		'job_visibility_slots',
		'job_visibility_extras',
		'job_visibility_modes',
		'job_visibility_active_slot',
		'job_visibility_active_extra_slot',
		'job_visibility_active_mode',
		'job_visibility_active_mode_slot',
	}
	local function normalize_slot_map_keys(slot_map)
		if type(slot_map) ~= 'table' then
			return
		end
		local moves = {}
		for k, v in pairs(slot_map) do
			local nk = normalize_job_slot(k)
			if nk and nk ~= k then
				moves[#moves + 1] = {from = k, to = nk, value = v}
			end
		end
		for _, m in ipairs(moves) do
			if slot_map[m.to] == nil then
				slot_map[m.to] = m.value
			end
			slot_map[m.from] = nil
		end
	end

	for _, name in ipairs(key_tables) do
		local t = settings.player[name]
		if type(t) == 'table' then
			local moves = {}
			for k, v in pairs(t) do
				if type(k) == 'string' then
					local lk = k:lower()
					if lk ~= k then
						moves[#moves+1] = {from = k, to = lk, value = v}
					end
				end
			end
			for _, m in ipairs(moves) do
				if t[m.to] == nil then
					t[m.to] = m.value
				end
				t[m.from] = nil
			end
		end
	end

	-- Normalize slot map keys that may come from XML as strings ("2") to numbers (2).
	if type(settings.player.job_visibility_slots) == 'table' then
		for _, slot_map in pairs(settings.player.job_visibility_slots) do
			normalize_slot_map_keys(slot_map)
		end
	end
	if type(settings.player.job_visibility_extras) == 'table' then
		for _, slot_map in pairs(settings.player.job_visibility_extras) do
			normalize_slot_map_keys(slot_map)
		end
	end
	if type(settings.player.job_visibility_modes) == 'table' then
		for _, modes in pairs(settings.player.job_visibility_modes) do
			if type(modes) == 'table' then
				for _, slot_map in pairs(modes) do
					normalize_slot_map_keys(slot_map)
				end
			end
		end
	end

	-- Normalize active slot values that may come from XML as strings.
	local active_slot_tables = {
		'job_visibility_active_slot',
		'job_visibility_active_extra_slot',
		'job_visibility_active_mode_slot',
	}
	for _, name in ipairs(active_slot_tables) do
		local t = settings.player[name]
		if type(t) == 'table' then
			for job, slot in pairs(t) do
				local n = normalize_job_slot(slot)
				if n then
					t[job] = n
				else
					t[job] = nil
				end
			end
		end
	end
end

local function apply_only_mode(key, apply_fn)
	if only_mode_active and only_mode_key == key then
		if only_mode_backup then
			apply_show_flags(only_mode_backup.show)
			if only_mode_backup.mode then
				settings.display.mode = only_mode_backup.mode
			end
			refresh_display()
			mode_refresh_pending = true
		end
		only_mode_active = false
		only_mode_backup = nil
		only_mode_key = nil
		log('Only mode: OFF')
		return true
	end
	if only_mode_active and only_mode_backup then
		apply_show_flags(only_mode_backup.show)
		if only_mode_backup.mode then
			settings.display.mode = only_mode_backup.mode
		end
	end
	only_mode_backup = {show = snapshot_show_flags(), mode = settings.display.mode}
	only_mode_key = key
	apply_fn()
	refresh_display()
	mode_refresh_pending = true
	only_mode_active = true
	log('Only mode: ON (' .. tostring(key) .. ')')
	return true
end

local function parse_haste_value(val)
	if not val or val == '' then
		return nil
	end
	local s = tostring(val):lower()
	local is_percent = s:find('%%') ~= nil
	s = s:gsub('%%', '')
	local num = tonumber(s)
	if not num then
		return nil
	end
	if is_percent then
		return math.floor((num / 100) * 1024 + 0.5)
	end
	return math.floor(num)
end

local function set_test_haste(target, value)
	if target == 'g' then
		GI_test_haste_g = value
	elseif target == 'm' then
		GI_test_haste_m = value
	elseif target == 'j' then
		GI_test_haste_j = value
	elseif target == 'all' then
		GI_test_haste_g = value
		GI_test_haste_m = value
		GI_test_haste_j = value
	end
end

local function haste_cap(target)
	if target == 'm' then
		return 448
	end
	if target == 'g' or target == 'j' then
		return 256
	end
	return 0
end

local function apply_job_defaults(main_job)
	-- core display blocks should always return on job reset/defaults
	settings.player.show_total_haste = true
	settings.player.show_tp_Stuff = true
	settings.player.show_acc_Stuff = true
	settings.player.show_att_Stuff = true
	settings.player.show_Evasion = true
	settings.player.show_Defence = true
	settings.player.show_dt_Stuff = true
	settings.player.show_STP = true
	local extra2_job_ok = (extra2_jobs[main_job] == true) or (settings.player.extra32_override == true)
	local dd_melee_job_ok = dd_melee_jobs[main_job] == true
	local extra5_job_ok = extra5_jobs[main_job] == true
	settings.player.show_mab = extra2_job_ok
	settings.player.show_mbd = extra2_job_ok
	settings.player.show_mbd2 = extra2_job_ok
	settings.player.show_int = extra2_job_ok
	settings.player.show_macc = extra2_job_ok
	settings.player.show_magic_damage = extra2_job_ok
	settings.player.show_sc_bonus = dd_melee_job_ok
	settings.player.show_sc_damage = dd_melee_job_ok
	settings.player.show_pdl = dd_melee_job_ok
	settings.player.show_crit_rate = dd_melee_job_ok
	settings.player.show_crit_damage = dd_melee_job_ok
	settings.player.show_subtle_blow = dd_melee_job_ok
	settings.player.show_subtle_blow_ii = dd_melee_job_ok
	if main_job == 'PUP' then
		settings.player.show_sc_bonus = false
		settings.player.show_sc_damage = false
		settings.player.show_pdl = false
	end
	if main_job == 'WHM' then
		settings.player.show_regen = false
		settings.player.show_refresh = true
		settings.player.show_parry = false
		settings.player.show_enmity = false
		settings.player.show_magic_def_bonus = true
		settings.player.show_magic_evasion = true
		settings.player.show_sird = false
		settings.player.show_conserve_mp = true
	else
		settings.player.show_regen = extra5_job_ok
		settings.player.show_refresh = extra5_job_ok
		settings.player.show_parry = extra5_job_ok
		settings.player.show_enmity = extra5_job_ok
		settings.player.show_magic_def_bonus = extra5_job_ok
		settings.player.show_magic_evasion = extra5_job_ok
		settings.player.show_sird = extra5_job_ok
		settings.player.show_conserve_mp = false
	end
end

local all_jobs = {
	'WAR','MNK','WHM','BLM','RDM','THF','PLD','DRK','BST','BRD','RNG',
	'SAM','NIN','DRG','SMN','BLU','COR','PUP','DNC','SCH','GEO','RUN'
}

local mode_flag_groups = {
	healer = {
		'show_fc','show_cp','show_cp2','show_hms','show_qc','show_cst','show_hmct',
		'show_emed','show_cursna','show_sird','show_magic_def_bonus','show_magic_evasion','show_macc'
	},
	magic_attack = {
		'show_mab','show_mbd','show_mbd2','show_int','show_macc','show_magic_damage',
		'show_sc_bonus','show_sc_damage'
	},
	tank = {
		'show_dt_Stuff','show_enmity','show_parry','show_sird','show_magic_def_bonus',
		'show_magic_evasion','show_br','show_echr','show_phalanx','show_inq','show_pdl'
	},
	pet = {
		'show_pethaste','show_petdt','show_petpdt','show_petmdt','show_pr','show_ied',
		'show_bpd','show_bpd2','show_bpdmg','show_apc','show_pmab','show_patt',
		'show_pda','show_pacc','show_pmacc','show_sms','show_pbpd','show_pmdmg'
	},
	dd = {
		'show_qa_da_ta','show_sc_bonus','show_sc_damage','show_pdl','show_crit_rate',
		'show_crit_damage','show_subtle_blow','show_subtle_blow_ii','show_tpb',
		'show_zanshin','show_killer','show_th','show_sa','show_ta','show_steal'
	},
	test = job_show_keys,
}

local slot_variant_flags = {
	[1] = {},
	[2] = mode_flag_groups.dd,
	[3] = mode_flag_groups.magic_attack,
	[4] = mode_flag_groups.tank,
	[5] = mode_flag_groups.pet,
	[6] = mode_flag_groups.healer,
	[7] = {'show_allsongs','show_sed','show_sst','show_refresh','show_regen','show_conserve_mp'},
	[8] = {'show_fc','show_qc','show_cst','show_hmct','show_snapshot','show_rapid_shot','show_emct','show_emed'},
	[9] = job_show_keys,
}

local function new_show_state(default_value)
	local state = {}
	local v = default_value == true
	for _, key in ipairs(job_show_keys) do
		state[key] = v
	end
	return state
end

local function clone_show_state(state)
	local copy = {}
	for _, key in ipairs(job_show_keys) do
		copy[key] = state[key] == true
	end
	return copy
end

local function set_flags(state, keys, value)
	if type(state) ~= 'table' or type(keys) ~= 'table' then
		return
	end
	local v = value ~= false
	for _, key in ipairs(keys) do
		state[key] = v
	end
end

local function build_default_job_state(main_job)
	local state = new_show_state(false)
	state.show_total_haste = true
	state.show_tp_Stuff = true
	state.show_acc_Stuff = true
	state.show_att_Stuff = true
	state.show_Evasion = true
	state.show_Defence = true
	state.show_dt_Stuff = true
	state.show_STP = true
	state.show_DW_Stuff = true

	local extra2_job_ok = (extra2_jobs[main_job] == true) or (settings.player.extra32_override == true)
	local dd_melee_job_ok = dd_melee_jobs[main_job] == true
	local extra5_job_ok = extra5_jobs[main_job] == true

	state.show_mab = extra2_job_ok
	state.show_mbd = extra2_job_ok
	state.show_mbd2 = extra2_job_ok
	state.show_int = extra2_job_ok
	state.show_macc = extra2_job_ok
	state.show_magic_damage = extra2_job_ok
	state.show_sc_bonus = dd_melee_job_ok
	state.show_sc_damage = dd_melee_job_ok
	state.show_pdl = dd_melee_job_ok
	state.show_crit_rate = dd_melee_job_ok
	state.show_crit_damage = dd_melee_job_ok
	state.show_subtle_blow = dd_melee_job_ok
	state.show_subtle_blow_ii = dd_melee_job_ok
	state.show_qa_da_ta = dd_melee_job_ok
	state.show_tpb = dd_melee_job_ok

	if main_job == 'PUP' then
		state.show_sc_bonus = false
		state.show_sc_damage = false
		state.show_pdl = false
	end
	if main_job == 'WHM' then
		state.show_refresh = true
		state.show_magic_def_bonus = true
		state.show_magic_evasion = true
		state.show_conserve_mp = true
	else
		state.show_regen = extra5_job_ok
		state.show_refresh = extra5_job_ok
		state.show_parry = extra5_job_ok
		state.show_enmity = extra5_job_ok
		state.show_magic_def_bonus = extra5_job_ok
		state.show_magic_evasion = extra5_job_ok
		state.show_sird = extra5_job_ok
	end

	local preset = job_extra_presets[main_job]
	if type(preset) == 'table' then
		set_flags(state, preset, true)
	end
	return state
end

local function build_mode_state(main_job, mode_name, slot_num)
	local state = build_default_job_state(main_job)
	local group = mode_flag_groups[mode_name]
	if type(group) == 'table' then
		set_flags(state, group, true)
	end
	local slot_group = slot_variant_flags[slot_num]
	if type(slot_group) == 'table' then
		set_flags(state, slot_group, true)
	end
	return state
end

local function build_extra_state(main_job, slot_num)
	local state = new_show_state(false)
	set_flags(state, main_show_keys, true)
	local preset = job_extra_presets[main_job]
	if type(preset) == 'table' then
		set_flags(state, preset, true)
	end
	local slot_group = slot_variant_flags[slot_num]
	if type(slot_group) == 'table' then
		set_flags(state, slot_group, true)
	end
	state.show_DW_Stuff = true
	return state
end

local function ensure_default_job_presets()
	if not settings or not settings.player then
		return
	end
	local changed = false
	ensure_job_visibility_tables()
	for _, main_job in ipairs(all_jobs) do
		local key = main_job:lower()
		settings.player.job_visibility_slots[key] = settings.player.job_visibility_slots[key] or {}
		settings.player.job_visibility_extras[key] = settings.player.job_visibility_extras[key] or {}
		settings.player.job_visibility_modes[key] = settings.player.job_visibility_modes[key] or {}

		for slot = 1, 9 do
			if type(settings.player.job_visibility_slots[key][slot]) ~= 'table' then
				local base = build_default_job_state(main_job)
				local slot_group = slot_variant_flags[slot]
				if type(slot_group) == 'table' then
					set_flags(base, slot_group, true)
				end
				settings.player.job_visibility_slots[key][slot] = clone_show_state(base)
				changed = true
			end
			if type(settings.player.job_visibility_extras[key][slot]) ~= 'table' then
				settings.player.job_visibility_extras[key][slot] = build_extra_state(main_job, slot)
				changed = true
			end
		end

		local modes = {'healer','magic_attack','tank','pet','dd','test'}
		for _, mode_name in ipairs(modes) do
			settings.player.job_visibility_modes[key][mode_name] = settings.player.job_visibility_modes[key][mode_name] or {}
			for slot = 1, 9 do
				if type(settings.player.job_visibility_modes[key][mode_name][slot]) ~= 'table' then
					settings.player.job_visibility_modes[key][mode_name][slot] = build_mode_state(main_job, mode_name, slot)
					changed = true
				end
			end
		end

		if type(settings.player.job_visibility[key]) ~= 'table' then
			settings.player.job_visibility[key] = clone_show_state(settings.player.job_visibility_slots[key][1])
			changed = true
		end
		if settings.player.job_visibility_active_slot[key] == nil then
			settings.player.job_visibility_active_slot[key] = 1
			changed = true
		end
		if settings.player.job_visibility_active_extra_slot[key] == nil then
			settings.player.job_visibility_active_extra_slot[key] = 1
			changed = true
		end
	end
	return changed
end

windower.register_event('load', function()
	if windower.ffxi.get_player() then
		options_load()
		--text_box:show()
		
		if files.exists('data\\'..player.name..'_temp_party.lua') then
			local f = io.open(windower.addon_path..'data/'..player.name..'_temp_party.lua','r')
			local t = f:read("*all")
			t = assert(loadstring(t))()
			f:close()
			member_table = t
			local f = io.open(windower.addon_path..'data/'..player.name..'_temp_party.lua','w')
			f:write('return {}')
			f:close()
		end
		if files.exists('data\\'..player.name..'_temp_buffs.lua') then
			local f = io.open(windower.addon_path..'data/'..player.name..'_temp_buffs.lua','r')
			local t = f:read("*all")
			t = assert(loadstring(t))()
			f:close()
			_ExtraData.player.buff_details = t
			local f = io.open(windower.addon_path..'data/'..player.name..'_temp_buffs.lua','w')
			f:write('return {}')
			f:close()
		end
		
	end
end)

windower.register_event('logout', function()
	
	player = {}
	player.equipment = T{}
	buff = 0
	full_gear_table_from_file = T{}
	
	manual_stp = 0
	manual_dw = 0
	manual_ghaste = 0
	WSTP = 0
	
end)

windower.register_event('login',function ()
	windower.send_command('lua r gearinfo;')
end)

function options_load()
	
	if windower.ffxi.get_player() then
	
		notice('please note since version \'3.4.0.0\' onwards the settings file structure changed in a manner user intervention is required.')
		notice('please either delete your GearInfo Data folder or the \"player name\"_settings.xml files within it and reload the addon.')
		notice('I apologize for the inconvenience.')
		
		settings = config.load('data\\'..windower.ffxi.get_player().name..'_settings.xml',defaults)
		ensure_job_visibility_tables()
		normalize_job_visibility_keys()
		if settings.player.show_aug_only == nil then
			settings.player.show_aug_only = defaults.player.show_aug_only or false
		end
		if settings.player.extra_all_override == nil then
			settings.player.extra_all_override = defaults.player.extra_all_override or false
		end
		if settings.display.style == nil then
			settings.display.style = defaults.display.style or "box"
		end
		if settings.display.size == nil then
			settings.display.size = defaults.display.size or 5
		end
		if settings.display.flat_theme == nil then
			settings.display.flat_theme = defaults.display.flat_theme or 1
		end
		if settings.display.label_size == nil then
			settings.display.label_size = defaults.display.label_size or 5
		end
		if settings.display.value_size == nil then
			settings.display.value_size = defaults.display.value_size or 5
		end
		if settings.display.bg_alpha == nil then
			settings.display.bg_alpha = defaults.display.bg_alpha or 5
		end
		if settings.display.label_font == nil then
			settings.display.label_font = defaults.display.label_font or "Tahoma"
		end
		if settings.display.value_font == nil then
			settings.display.value_font = defaults.display.value_font or "Tahoma"
		end
		if settings.display.bg_image == nil then
			settings.display.bg_image = defaults.display.bg_image or ""
		end
		if settings.display.mode == nil then
			settings.display.mode = defaults.display.mode or 1
		end
		if type(settings.display.pos) ~= 'table' then
			settings.display.pos = {
				x = (defaults.display.pos and defaults.display.pos.x) or 500,
				y = (defaults.display.pos and defaults.display.pos.y) or 300
			}
		end
		settings.display.pos.x = tonumber(settings.display.pos.x) or ((defaults.display.pos and defaults.display.pos.x) or 500)
		settings.display.pos.y = tonumber(settings.display.pos.y) or ((defaults.display.pos and defaults.display.pos.y) or 300)
		settings.display.mode = tonumber(settings.display.mode) or (defaults.display.mode or 1)
		settings.display.size = tonumber(settings.display.size) or (defaults.display.size or 5)
		settings.display.label_size = tonumber(settings.display.label_size) or (defaults.display.label_size or 5)
		settings.display.value_size = tonumber(settings.display.value_size) or (defaults.display.value_size or 5)
		settings.display.flat_theme = tonumber(settings.display.flat_theme) or (defaults.display.flat_theme or 1)
		settings.display.bg_alpha = tonumber(settings.display.bg_alpha) or (defaults.display.bg_alpha or 5)
		if settings.player.auto_parse_gearswap == nil then
			settings.player.auto_parse_gearswap = defaults.player.auto_parse_gearswap or false
		else
			-- Disable auto-parse by default to avoid slow first load.
			settings.player.auto_parse_gearswap = false
		end
		if settings.player.safe_mode == nil then
			settings.player.safe_mode = defaults.player.safe_mode or false
		end
		if settings.player.ultra_light_mode == nil then
			settings.player.ultra_light_mode = true
		end
		GI_ULTRA_LIGHT_MODE = settings.player.ultra_light_mode and true or false
		if settings.player.use_real_att_def == nil then
			settings.player.use_real_att_def = defaults.player.use_real_att_def or false
		end
		if settings.player.gearswap_path == nil then
			local addon_path = windower.addon_path:gsub("[/\\]+$", "")
			local root = addon_path:gsub("addons[/\\][^/\\]+$", "")
			local gs_default = root .. "addons\\GearSwap\\data\\"
			local gs_player = gs_default .. windower.ffxi.get_player().name
			if windower.dir_exists(gs_player) then
				settings.player.gearswap_path = gs_player
			else
				settings.player.gearswap_path = gs_default
			end
		end
		-- DT contribution switches:
		-- pdt_include_dt : DT added into PDT display
		-- dt_include_dt  : DT added into MDT/BDT display
		-- Keep them independent: PDT should not inherit MDT/BDT behavior by default.
		if settings.player.pdt_include_dt == nil then
			settings.player.pdt_include_dt = defaults.player.pdt_include_dt
		end
		if settings.player.dt_include_dt == nil then
			settings.player.dt_include_dt = defaults.player.dt_include_dt
		end
		settings:save('all')
		notice('For GearSwap augments: use //gi back (back augments) or //gi escha apply (escha/reisen apply).')
		notice('GearSwap path: ' .. tostring(settings.player.gearswap_path))
		sections.background = ImageBlock.New(0,'background','')
		apply_display_style()
		apply_display_fonts()
		--sections.logo = ImageBlock.New(1,'logo','')
		player = windower.ffxi.get_player()
		update_party()
		local this_file = files.new('data\\'..player.name..'_data.lua',true)
		
		if not files.exists('data\\'..player.name..'_data.lua') then
			this_file:create()
			local f = io.open(windower.addon_path..'data/'..player.name..'_data.lua','w')
			f:write('return {\n}')
			f:close()
			print(player.name..'_data.lua created by GearInfo')
			parse_inventory()
		else
			full_gear_table_from_file = get_equipment_from_file()
		end
		
		manual_stp = 0
		manual_dw = 0
		manual_ghaste = 0
		initialize_packet_parsing()

		if settings.player.auto_parse_gearswap and not settings.player.safe_mode and not auto_parse_gearswap_done then
			auto_parse_gearswap_done = true
			log('Auto parsing GearSwap augments (back + escha) ...')
			parse_gearswap_back('all', true)
		end
	end
	
end

windower.register_event('addon command', function(command, ...)
	local args = {...}
    command = command and command:lower()
	command, args = normalize_command_aliases(command, args)
	if command then
        if command:lower() == 'parse' then
			local mode = args[1] and args[1]:lower() or nil
			local apply_now = args[2] and args[2]:lower() == 'apply'
			if settings.player.safe_mode and (mode == 'back' or mode == 'escha' or mode == 'all') then
				log('Safe mode is ON: GearSwap augment parsing is blocked. Use //gi safe off to allow it.')
				return
			end
			if mode == 'back' then
				log('Parsing GearSwap back augments (Aragan)')
				parse_gearswap_back('back', apply_now)
			elseif mode == 'escha' then
				log('Parsing GearSwap Escha/Reisenjima augments (Aragan)')
				parse_gearswap_back('escha', apply_now)
			elseif mode == 'all' then
				log('Parsing GearSwap back + Escha/Reisenjima augments (Aragan)')
				parse_gearswap_back('all', apply_now)
			else
				log('Parsing all inventories to file')
				parse_inventory()
			end
		elseif command:lower() == 'rank' then
			--table.vprint(args)
			if type(tonumber(args[1])) == 'number'  then
				settings.player.rank = tonumber(args[1])
				log('Changed \'Unity Rank\' to '..tonumber(args[1])..'. Don\'t forget to \"//gi parse\" to apply new values to your gear.')
				settings:save('all')
			else
				log('Your current \'Unity Rank\' setting is: '..settings.player.rank..'.')
			end
			settings:save('all')
		elseif command:lower() == 'nyame' then
			-- One-time Nyame debug without continuous spam.
			local equip = check_equipped()
			local total = 0
			for slot, item in pairs(equip) do
				if item and nyame_ids[item.id] then
					local da = nil
					if settings.player.show_aug_only and item._aug_only then
						da = item._aug_only["Double Attack"]
					end
					if da == nil then
						da = item["Double Attack"]
					end
					da = da or 0
					total = total + da
					log('Nyame '..tostring(item.en)..' ('..tostring(slot)..') DA='..tostring(da))
				end
			end
			log('Nyame DA total='..tostring(total)..' | GearInfo DA total='..tostring(Gear_info["Double Attack"] or 0))
		elseif command:lower() == 'stp' and type(tonumber(args[1])) == 'number' then
			manual_stp = tonumber(args[1])
			log('Set maunal Store TP to ' .. tostring(manual_stp))
		elseif command:lower() == 'dw' and type(tonumber(args[1])) == 'number' then
			manual_dw = tonumber(args[1])
			log('Set maunal Dual Wield to ' .. tostring(manual_dw))
		elseif command:lower() == 'ghaste' and type(tonumber(args[1])) == 'number' then
			manual_ghaste = tonumber(args[1])
			log('Set maunal Gear Haste to ' .. tostring(manual_ghaste))
		elseif command:lower() == 'mhaste' and type(tonumber(args[1])) == 'number' then
			manual_mhaste = tonumber(args[1])
			log('Set maunal Magic Haste to ' .. tostring(manual_mhaste))
		elseif command:lower() == 'jahaste' and type(tonumber(args[1])) == 'number' then
			manual_jahaste = tonumber(args[1])
			log('Set maunal Job Ability Haste to ' .. tostring(manual_jahaste))
		elseif command:lower() == 'dwn' and type(tonumber(args[1])) == 'number' then	
			manual_dw_needed = tonumber(args[1])
			log('Set maunal DW needed to ' .. tostring(manual_dw_needed))
		elseif command:lower() == 'pdtmode' then
			settings.player.pdt_include_dt = not settings.player.pdt_include_dt
			settings:save('all')
			log('DT included in PDT only = ' .. tostring(settings.player.pdt_include_dt))
		elseif command:lower() == 'real' or command:lower() == 'attreal' or command:lower() == 'defreal' then
			local arg = args[1] and tostring(args[1]):lower() or ''
			if arg == 'on' or arg == 'true' or arg == '1' then
				settings.player.use_real_att_def = true
			elseif arg == 'off' or arg == 'false' or arg == '0' then
				settings.player.use_real_att_def = false
			elseif arg == 'status' then
				log('Use real Attack/Defence values (if available) = '..tostring(settings.player.use_real_att_def))
				return
			else
				settings.player.use_real_att_def = not settings.player.use_real_att_def
			end
			settings:save('all')
			refresh_display()
			log('Use real Attack/Defence values (if available) = '..tostring(settings.player.use_real_att_def))
		elseif command:lower() == 'style' or command:lower() == 'syle' then
			local style = args[1] and args[1]:lower() or nil
			if style == 'reset' then
				settings.display.style = defaults.display.style or "box"
				settings.display.flat_theme = defaults.display.flat_theme or 1
				settings:save('all')
				log('Display style reset to ' .. tostring(settings.display.style) .. ' (theme ' .. tostring(settings.display.flat_theme or 1) .. ')')
				apply_display_style()
				return
			end
			local theme_arg = args[2] and tonumber(args[2]) or nil
			local style_num = tonumber(style)
			if not style then
				if tostring(settings.display.style or 'box'):lower() == 'box' then
					settings.display.style = 'flat'
				else
					settings.display.style = 'box'
				end
			elseif style == 'flat' or style == 'text' or style == 'plain' then
				settings.display.style = 'flat'
				if theme_arg then
					settings.display.flat_theme = math.min(40, math.max(1, math.floor(theme_arg)))
				end
			elseif style == 'box' or style == 'default' or style == 'color' then
				settings.display.style = 'box'
			elseif style_num then
				settings.display.style = 'flat'
				settings.display.flat_theme = math.min(40, math.max(1, math.floor(style_num)))
			else
				log('Invalid style. Use: //gi style box  or  //gi style flat [1-40]')
				return
			end
			settings:save('all')
			log('Display style set to ' .. tostring(settings.display.style) .. ' (theme ' .. tostring(settings.display.flat_theme or 1) .. ')')
			apply_display_style()
		elseif command:lower() == 'size' then
			if not args[1] then
				log('Current display size: ' .. tostring(settings.display.size or 5))
				log('Use: //gi size 1..9 (5 = default)')
			elseif args[1] and args[1]:lower() == 'reset' then
				settings.display.size = defaults.display.size or 5
				settings:save('all')
				log('Display size reset to ' .. tostring(settings.display.size))
				refresh_display()
			else
				local new_size = tonumber(args[1])
				if not new_size or new_size < 1 or new_size > 9 then
					log('Invalid size. Use: //gi size 1..9 (5 = default)')
				else
					settings.display.size = math.floor(new_size)
					settings:save('all')
					log('Display size set to ' .. tostring(settings.display.size))
					refresh_display()
				end
			end
		elseif command:lower() == 'label' then
			if not args[1] then
				log('Current label size: ' .. tostring(settings.display.label_size or 5))
				log('Use: //gi label 1..9 (5 = default)')
			elseif args[1] and args[1]:lower() == 'reset' then
				settings.display.label_size = defaults.display.label_size or 5
				settings:save('all')
				log('Label size reset to ' .. tostring(settings.display.label_size))
				refresh_display()
			else
				local new_size = tonumber(args[1])
				if not new_size or new_size < 1 or new_size > 9 then
					log('Invalid label size. Use: //gi label 1..9 (5 = default)')
				else
					settings.display.label_size = math.floor(new_size)
					settings:save('all')
					log('Label size set to ' .. tostring(settings.display.label_size))
					refresh_display()
				end
			end
		elseif command:lower() == 'value' then
			if not args[1] then
				log('Current value size: ' .. tostring(settings.display.value_size or 5))
				log('Use: //gi value 1..9 (5 = default)')
			elseif args[1] and args[1]:lower() == 'reset' then
				settings.display.value_size = defaults.display.value_size or 5
				settings:save('all')
				log('Value size reset to ' .. tostring(settings.display.value_size))
				refresh_display()
			else
				local new_size = tonumber(args[1])
				if not new_size or new_size < 1 or new_size > 9 then
					log('Invalid value size. Use: //gi value 1..9 (5 = default)')
				else
					settings.display.value_size = math.floor(new_size)
					settings:save('all')
					log('Value size set to ' .. tostring(settings.display.value_size))
					refresh_display()
				end
			end
		elseif command:lower() == 'bg' or command:lower() == 'bgalpha' then
			if not args[1] then
				log('Current background alpha: ' .. tostring(settings.display.bg_alpha or 5))
				log('Current background image: ' .. tostring(settings.display.bg_image or 'none'))
				log('Use: //gi bg 0..9 (0 = transparent, 9 = strongest)')
				log('Use: //gi bg a..h (set background image images/<letter>.png)')
			elseif args[1] and args[1]:lower() == 'reset' then
				settings.display.bg_alpha = defaults.display.bg_alpha or 5
				settings.display.bg_image = defaults.display.bg_image or ""
				settings:save('all')
				log('Background alpha reset to ' .. tostring(settings.display.bg_alpha))
				log('Background image reset to ' .. tostring(settings.display.bg_image or 'none'))
				apply_display_style()
			else
				local arg = args[1]:lower()
				if arg:match('^[a-h]$') then
					settings.display.bg_image = arg .. '.png'
					settings:save('all')
					log('Background image set to ' .. tostring(settings.display.bg_image))
					apply_display_style()
				else
					local new_alpha = tonumber(args[1])
					if new_alpha == nil or new_alpha < 0 or new_alpha > 9 then
						log('Invalid background alpha. Use: //gi bg 0..9 (0 = transparent, 9 = strongest)')
						log('Or: //gi bg a..h (set background image images/<letter>.png)')
					else
						settings.display.bg_alpha = math.floor(new_alpha)
						settings:save('all')
						log('Background alpha set to ' .. tostring(settings.display.bg_alpha))
						apply_display_style()
					end
				end
			end
		elseif command:lower() == 'font' then
			if args[1] and args[1]:lower() == 'reset' then
				settings.display.label_font = defaults.display.label_font or "Tahoma"
				settings:save('all')
				log('Label font reset to ' .. tostring(settings.display.label_font))
				apply_display_fonts()
				return
			end
			local font = ''
			if args[1] and #args == 1 and font_presets[args[1]:lower()] then
				font = font_presets[args[1]:lower()]
			else
				font = table.concat(args, ' ')
				font = (font or ''):gsub('^%s+', ''):gsub('%s+$', '')
			end
			if font == '' then
				log('Current label font: ' .. tostring(settings.display.label_font or 'Tahoma'))
				log('Use: //gi font <font name>  or  //gi font a..k')
			else
				settings.display.label_font = font
				settings:save('all')
				log('Label font set to ' .. tostring(settings.display.label_font))
				apply_display_fonts()
			end
		elseif command:lower() == 'numfont' then
			if args[1] and args[1]:lower() == 'reset' then
				settings.display.value_font = defaults.display.value_font or "Tahoma"
				settings:save('all')
				log('Value font reset to ' .. tostring(settings.display.value_font))
				apply_display_fonts()
				return
			end
			local font = ''
			if args[1] and #args == 1 and font_presets[args[1]:lower()] then
				font = font_presets[args[1]:lower()]
			else
				font = table.concat(args, ' ')
				font = (font or ''):gsub('^%s+', ''):gsub('%s+$', '')
			end
			if font == '' then
				log('Current value font: ' .. tostring(settings.display.value_font or 'Tahoma'))
				log('Use: //gi numfont <font name>  or  //gi numfont a..k')
			else
				settings.display.value_font = font
				settings:save('all')
				log('Value font set to ' .. tostring(settings.display.value_font))
				apply_display_fonts()
			end
		elseif command:lower() == 'mode' then
			if args[1] and args[1]:lower() == 'reset' then
				if calc_mode_active then
					disable_calc_mode()
				end
				settings.display.mode = defaults.display.mode or 1
				settings:save('all')
				log('Display mode reset to ' .. tostring(settings.display.mode))
				if type(check_positions) == 'function' then
					check_positions()
				end
			elseif not args[1] then
				log('Current display mode: ' .. tostring(settings.display.mode or 1))
				log('Use: //gi mode 1..8 | calc | <1..8> calc  (1=4,2=8,3=12,4=6,5=3,6=2,7=1,8=16)')
			else
				local has_calc = false
				local new_mode = nil
				for _, a in ipairs(args) do
					local low = tostring(a):lower()
					if low == 'calc' then
						has_calc = true
					else
						local n = tonumber(low)
						if n ~= nil then
							new_mode = n
						end
					end
				end

				if has_calc then
					if new_mode ~= nil then
						if new_mode < 1 or new_mode > 8 then
							log('Invalid mode number with calc. Use: //gi mode <1..8> calc  (1=4,2=8,3=12,4=6,5=3,6=2,7=1,8=16)')
							return
						end
						settings.display.mode = new_mode
						settings:save('all')
						-- Number before calc sets layout mode only (same mapping as normal mode).
						enable_calc_mode(nil)
					else
						-- Toggle behavior for plain: //gi mode calc
						if calc_mode_active and calc_mode_limit == nil then
							disable_calc_mode()
						else
							enable_calc_mode(nil)
						end
					end
					return
				end

				if new_mode ~= 1 and new_mode ~= 2 and new_mode ~= 3 and new_mode ~= 4
					and new_mode ~= 5 and new_mode ~= 6 and new_mode ~= 7 and new_mode ~= 8 then
					log('Invalid mode. Use: //gi mode 1..8 | calc | <1..8> calc  (1=4,2=8,3=12,4=6,5=3,6=2,7=1,8=16)')
				else
					if calc_mode_active then
						disable_calc_mode()
					end
					local only = has_only(args)
					if only then
						apply_only_mode('mode-' .. tostring(new_mode), function()
							settings.display.mode = new_mode
						end)
					else
						settings.display.mode = new_mode
						settings:save('all')
						log('Display mode set to ' .. tostring(new_mode))
						if type(check_positions) == 'function' then
							check_positions()
						end
					end
				end
			end
		elseif command:lower() == 'limit' then
			local arg1 = args[1] and args[1]:lower() or ''
			local arg2 = args[2] and args[2]:lower() or ''
			if arg1 == 'reset' or arg2 == 'reset' then
				settings.display.block_limit = 0
				settings:save('all')
				log('Block limit reset (no limit).')
				refresh_display()
				mode_refresh_pending = true
			elseif arg1 == 'block' then
				local n = tonumber(args[2])
				if not n then
					log('Use: //gi limit block 1..9 or //gi limit reset')
				else
					if n < 1 then n = 1 end
					if n > 9 then n = 9 end
					settings.display.block_limit = math.floor(n)
					settings:save('all')
					log('Block limit set to ' .. tostring(settings.display.block_limit))
					refresh_display()
					mode_refresh_pending = true
				end
			else
				log('Use: //gi limit block 1..9 or //gi limit reset')
			end
		elseif command:lower() == 'extra' then
			local chat_white = string.char(0x1F, 001)
			local chat_d_blue = string.char(0x1F, 207)
			local chat_l_blue = string.char(0x1E, 6)
			local arg1 = args[1] and args[1]:lower() or ''
			if arg1 == 'help' or arg1 == '' then
				print_extra_help(chat_l_blue, chat_white, chat_d_blue)
			else
				log('Use: //gi extra help')
			end
		elseif command:lower() == 'test' then
			if args[1] and args[1]:lower() == 'haste' then
				if not test_mode_active then
					log('Test haste commands only work in test mode. Use: //gi test')
					return
				end
				local target_map = {
					g = 'g', gear = 'g',
					m = 'm', magic = 'm',
					j = 'j', ja = 'j',
					a = 'all', all = 'all',
				}
				local target = 'all'
				local idx = 2
				local t = args[2] and args[2]:lower() or ''
				if t == 'cap' then
					target = 'all'
					idx = 3
				elseif target_map[t] then
					target = target_map[t]
					idx = 3
				end
				local v = args[idx] and args[idx]:lower() or ''
				if t == 'cap' and (v == '' or v == 'all') then
					set_test_haste('g', haste_cap('g'))
					set_test_haste('m', haste_cap('m'))
					set_test_haste('j', haste_cap('j'))
					log('Test haste set to cap (all)')
					return
				end
				if v == 'cap' then
					if target == 'all' then
						set_test_haste('g', haste_cap('g'))
						set_test_haste('m', haste_cap('m'))
						set_test_haste('j', haste_cap('j'))
					else
						set_test_haste(target, haste_cap(target))
					end
					log('Test haste set to cap (' .. tostring(target) .. ')')
					return
				end
				if v == 'capall' or (v == 'cap' and (args[idx+1] and args[idx+1]:lower() == 'all')) then
					set_test_haste('g', haste_cap('g'))
					set_test_haste('m', haste_cap('m'))
					set_test_haste('j', haste_cap('j'))
					log('Test haste set to cap (all)')
					return
				end
				if v == '' then
					log('Test haste overrides: G=' .. tostring(GI_test_haste_g) .. ' M=' .. tostring(GI_test_haste_m) .. ' J=' .. tostring(GI_test_haste_j))
					log('Use: //gi test haste [g|m|j|a] <value%|value|cap>')
					return
				end
				local val = parse_haste_value(v)
				if val == nil then
					log('Invalid haste value. Use: number or % (e.g. 10% or 102).')
					return
				end
				set_test_haste(target, val)
				log('Test haste set (' .. tostring(target) .. '): ' .. tostring(val))
				return
			end
			if args[1] and args[1]:lower() == 'job' then
				local main_job = player.main_job and player.main_job:upper() or ''
				local main_job_key = main_job:lower()
				if main_job == '' then
					log('No main job detected.')
					return
				end
				if not test_job_active then
					if test_mode_active then
						log('Test mode is active. Toggle it off before test job.')
						return
					end
					local slot = 1
					if settings.player.job_visibility_active_slot and settings.player.job_visibility_active_slot[main_job_key] then
						slot = settings.player.job_visibility_active_slot[main_job_key]
					end
					local state = nil
					if settings.player.job_visibility_slots and settings.player.job_visibility_slots[main_job_key] then
						state = settings.player.job_visibility_slots[main_job_key][slot]
					end
					if type(state) ~= 'table' then
						state = settings.player.job_visibility and settings.player.job_visibility[main_job_key] or nil
					end
					if type(state) ~= 'table' then
						log('No saved job display for: ' .. main_job .. ' (save with //gi save job)')
						return
					end
					test_job_backup = {
						mode = settings.display.mode,
						pos = {x = settings.display.pos.x, y = settings.display.pos.y},
						show = snapshot_show_flags(),
						extra_all_override = settings.player.extra_all_override,
						block_limit = settings.display.block_limit,
					}
					apply_job_show_state(state)
					settings.player.extra_all_override = false
					settings.display.block_limit = 0
					settings.display.mode = 8
					refresh_display()
					test_job_active = true
					test_mode_pending = true
					log('Test job mode: ON (mode 8, job boxes only, centered)')
				else
					if test_job_backup then
						settings.display.mode = test_job_backup.mode or settings.display.mode
						if test_job_backup.pos then
							settings.display.pos.x = test_job_backup.pos.x or settings.display.pos.x
							settings.display.pos.y = test_job_backup.pos.y or settings.display.pos.y
						end
						if test_job_backup.block_limit ~= nil then
							settings.display.block_limit = test_job_backup.block_limit
						end
						if test_job_backup.extra_all_override ~= nil then
							settings.player.extra_all_override = test_job_backup.extra_all_override
						end
						apply_show_flags(test_job_backup.show)
						settings:save('all')
						if sections and sections.background and test_job_backup.pos then
							sections.background:position(settings.display.pos.x, settings.display.pos.y)
						end
						refresh_display()
					end
					test_job_active = false
					log('Test job mode: OFF (restored)')
				end
				return
			end
			if not test_mode_active then
				test_mode_backup = {
					mode = settings.display.mode,
					pos = {x = settings.display.pos.x, y = settings.display.pos.y},
					show = snapshot_show_flags(),
					extra_all_override = settings.player.extra_all_override,
					block_limit = settings.display.block_limit,
				}
				set_all_show_flags(true)
				settings.player.extra_all_override = true
				settings.display.block_limit = 0
				settings.display.mode = 8
				refresh_display()
				test_mode_active = true
				GI_test_mode_active = true
				test_mode_pending = true
				log('Test mode: ON (mode 8, all boxes visible, centered)')
			else
				if test_mode_backup then
					settings.display.mode = test_mode_backup.mode or settings.display.mode
					if test_mode_backup.pos then
						settings.display.pos.x = test_mode_backup.pos.x or settings.display.pos.x
						settings.display.pos.y = test_mode_backup.pos.y or settings.display.pos.y
					end
					if test_mode_backup.block_limit ~= nil then
						settings.display.block_limit = test_mode_backup.block_limit
					end
					if test_mode_backup.extra_all_override ~= nil then
						settings.player.extra_all_override = test_mode_backup.extra_all_override
					end
					apply_show_flags(test_mode_backup.show)
					settings:save('all')
					if sections and sections.background and test_mode_backup.pos then
						sections.background:position(settings.display.pos.x, settings.display.pos.y)
					end
					refresh_display()
				end
				test_mode_active = false
				GI_test_mode_active = false
				GI_test_haste_g = nil
				GI_test_haste_m = nil
				GI_test_haste_j = nil
				test_mode_pending = false
				log('Test mode: OFF (restored)')
			end
		elseif command:lower() == 'safe' then
			local mode = args[1] and args[1]:lower() or nil
			if mode == 'on' then
				settings.player.safe_mode = true
			elseif mode == 'off' then
				settings.player.safe_mode = false
			else
				settings.player.safe_mode = not settings.player.safe_mode
			end
			if settings.player.safe_mode then
				settings.player.auto_parse_gearswap = false
			end
			settings:save('all')
			log('Safe mode = ' .. tostring(settings.player.safe_mode) .. ' (GearSwap augment parsing blocked when ON).')
		elseif command:lower() == 'autoparse' then
			local mode = args[1] and args[1]:lower() or nil
			if mode == 'on' then
				settings.player.auto_parse_gearswap = true
			elseif mode == 'off' then
				settings.player.auto_parse_gearswap = false
			else
				settings.player.auto_parse_gearswap = not settings.player.auto_parse_gearswap
			end
			if settings.player.safe_mode then
				settings.player.auto_parse_gearswap = false
				log('Safe mode is ON: auto parse remains OFF.')
			end
			settings:save('all')
			log('Auto parse GearSwap (back+escha) = ' .. tostring(settings.player.auto_parse_gearswap))
		elseif command:lower() == 'ultralight' or command:lower() == 'light' then
			local mode = args[1] and args[1]:lower() or nil
			if mode == 'status' then
				log('Ultra light mode = ' .. tostring(GI_ULTRA_LIGHT_MODE))
				return
			elseif mode == 'on' or mode == 'true' or mode == '1' then
				settings.player.ultra_light_mode = true
			elseif mode == 'off' or mode == 'false' or mode == '0' then
				settings.player.ultra_light_mode = false
			else
				settings.player.ultra_light_mode = not (settings.player.ultra_light_mode and true or false)
			end
			GI_ULTRA_LIGHT_MODE = settings.player.ultra_light_mode and true or false
			invalidate_equipped_cache()
			settings:save('all')
			log('Ultra light mode = ' .. tostring(GI_ULTRA_LIGHT_MODE) .. ' (very low CPU mode).')
		elseif command:lower() == 'turbo' then
			settings.player.ultra_light_mode = not (settings.player.ultra_light_mode and true or false)
			GI_ULTRA_LIGHT_MODE = settings.player.ultra_light_mode and true or false
			invalidate_equipped_cache()
			settings:save('all')
			log('Turbo toggle: Ultra light mode = ' .. tostring(GI_ULTRA_LIGHT_MODE))
		elseif command:lower() == 'gsdir' then
			local path = table.concat(args, ' ')
			path = (path or ''):gsub('^%s+', ''):gsub('%s+$', '')
			if path == '' then
				log('Current GearSwap path: ' .. tostring(settings.player.gearswap_path))
			else
				settings.player.gearswap_path = path
				settings:save('all')
				log('GearSwap path set to: ' .. tostring(settings.player.gearswap_path))
			end
		elseif command:lower() == 'back' then
			if settings.player.safe_mode then
				log('Safe mode is ON: //gi back is blocked. Use //gi safe off to allow it.')
				return
			end
			log('Parsing GearSwap back augments...')
			parse_gearswap_back('back', true)
		elseif command:lower() == 'escha' then
			if settings.player.safe_mode then
				log('Safe mode is ON: //gi escha is blocked. Use //gi safe off to allow it.')
				return
			end
			-- Swapped behavior: default saves, "apply" applies.
			local apply_now = (args[1] and args[1]:lower() == 'apply')
			log('Parsing GearSwap Escha/Reisenjima augments...')
			parse_gearswap_back('escha', apply_now)
		elseif command:lower() == 'pdtsource' then
			local equip = check_equipped()
			local include_dt = settings.player.pdt_include_dt and true or false
			local total_dt = 0
			local total_pdt = 0
			local total_pdt2 = 0
			log('--- PDT sources (equipped gear) ---')
			for slot, item in pairs(equip) do
				local dt = tonumber(item and item.DT) or 0
				local pdt = tonumber(item and item.PDT) or 0
				local pdt2 = tonumber(item and item.PDT2) or 0
				local aug_pdt = (type(item and item._aug_only) == 'table' and tonumber(item._aug_only.PDT)) or 0
				if dt ~= 0 or pdt ~= 0 or pdt2 ~= 0 then
					local msg = tostring(slot)..': '..tostring(item.en)..' (id='..tostring(item.id)..') DT='..tostring(dt)..' PDT='..tostring(pdt)..' PDT2='..tostring(pdt2)
					if aug_pdt ~= 0 then
						msg = msg .. ' augPDT=' .. tostring(aug_pdt)
					end
					log(msg)
					total_dt = total_dt + dt
					total_pdt = total_pdt + pdt
					total_pdt2 = total_pdt2 + pdt2
				end
			end
			log('--- PDT sources (set bonus) ---')
			local set_bonus = {}
			for _, item in pairs(equip) do
				if item and item["Set Bonus"] and item["Set Bonus"]["set id"] then
					local sbid = item["Set Bonus"]["set id"]
					if type(sbid) == 'table' then
						for _, sid in pairs(sbid) do
							set_bonus[sid] = (set_bonus[sid] or 0) + 1
						end
					else
						set_bonus[sbid] = (set_bonus[sbid] or 0) + 1
					end
				end
			end
			for sid, count in pairs(set_bonus) do
				if count >= 2 and Set_bonus_by_Set_ID and Set_bonus_by_Set_ID[sid] then
					local sb = Set_bonus_by_Set_ID[sid]
					local bonus = sb["bonus"] and sb["bonus"][count] or nil
					if type(bonus) == 'table' then
						local dt = tonumber(bonus.DT) or 0
						local pdt = tonumber(bonus.PDT) or 0
						local pdt2 = tonumber(bonus.PDT2) or 0
						if dt ~= 0 or pdt ~= 0 or pdt2 ~= 0 then
							log('SetBonus '..tostring(sb["Set Bonus"])..' (id='..tostring(sid)..', pieces='..tostring(count)..') DT='..tostring(dt)..' PDT='..tostring(pdt)..' PDT2='..tostring(pdt2))
							total_dt = total_dt + dt
							total_pdt = total_pdt + pdt
							total_pdt2 = total_pdt2 + pdt2
						end
					end
				end
			end
			local raw_display = (total_pdt * -1)
			local effective_display = ((total_pdt + (include_dt and total_dt or 0)) * -1)
			log('PDT total: raw='..tostring(raw_display)..' effective='..tostring(effective_display)..' (DT-in-PDT='..tostring(include_dt)..', PDT2='..tostring(total_pdt2)..')')
		elseif command:lower() == 'pdtdebug' then
			local equip = check_equipped()
			log('--- PDT/DT/MDT/BDT sources (gear) ---')
			for slot, item in pairs(equip) do
				local dt = item and item.DT or 0
				local pdt = item and item.PDT or 0
				local pdt2 = item and item.PDT2 or 0
				local mdt = item and item.MDT or 0
				local mdt2 = item and item.MDT2 or 0
				local bdt = item and item.BDT or 0
				if dt ~= 0 or pdt ~= 0 or pdt2 ~= 0 or mdt ~= 0 or mdt2 ~= 0 or bdt ~= 0 then
					log(tostring(slot)..': '..tostring(item.en)..' (id='..tostring(item.id)..') DT='..tostring(dt)
						..' PDT='..tostring(pdt)..' PDT2='..tostring(pdt2)
						..' MDT='..tostring(mdt)..' MDT2='..tostring(mdt2)
						..' BDT='..tostring(bdt))
				end
			end

			log('--- PDT/DT/MDT/BDT sources (set bonus) ---')
			local set_bonus = {}
			for _, item in pairs(equip) do
				if item and item["Set Bonus"] and item["Set Bonus"]["set id"] then
					local sbid = item["Set Bonus"]["set id"]
					if type(sbid) == 'table' then
						for _, sid in pairs(sbid) do
							set_bonus[sid] = (set_bonus[sid] or 0) + 1
						end
					else
						set_bonus[sbid] = (set_bonus[sbid] or 0) + 1
					end
				end
			end
			for sid, count in pairs(set_bonus) do
				if count >= 2 and Set_bonus_by_Set_ID and Set_bonus_by_Set_ID[sid] then
					local sb = Set_bonus_by_Set_ID[sid]
					local bonus = sb["bonus"] and sb["bonus"][count] or nil
					if type(bonus) == 'table' then
						local dt = bonus.DT or 0
						local pdt = bonus.PDT or 0
						local mdt = bonus.MDT or 0
						local bdt = bonus.BDT or 0
						if dt ~= 0 or pdt ~= 0 or mdt ~= 0 or bdt ~= 0 then
							log('SetBonus '..tostring(sb["Set Bonus"])..' (id='..tostring(sid)
								..', pieces='..tostring(count)..'): DT='..tostring(dt)
								..' PDT='..tostring(pdt)..' MDT='..tostring(mdt)..' BDT='..tostring(bdt))
						end
					end
				end
			end
		elseif command:lower() == 'pdtcheck' then
			if type(base_desc_mentions_pdt) ~= 'function' or type(maybe_purge_suspicious_pdt) ~= 'function' then
				log('PDT check is not ready yet. Reload addon and try again.')
				return
			end
			-- Quick sanity scan: list items that have PDT in cache/equipped but whose base description
			-- does not mention Physical damage taken (usually indicates wrong augments applied).
			local scope = args[1] and args[1]:lower() or 'equipped'
			local function base_has_pdt(item_id)
				local d = res.item_descriptions and res.item_descriptions:with('id', item_id)
				if not d or not d.en then
					return false
				end
				local s = d.en:lower()
				return s:find('physical damage taken', 1, true)
					or s:find('phys. dmg. taken', 1, true)
					or s:find('phys dmg taken', 1, true)
			end
			local function report_if_suspicious(it)
				if type(it) ~= 'table' or not it.id or it.id == 0 then
					return false
				end
				local pdt = it.PDT
				if pdt == nil or pdt == 0 then
					return false
				end
				-- Base may not mention PDT even if augments add it; treat those as expected.
				if base_desc_mentions_pdt(it.id) or augments_mentions_pdt(it.augments) then
					return false
				end
				local aug_pdt = (type(it._aug_only) == 'table' and it._aug_only.PDT) or 0
				log('PDT suspicious: '..tostring(it.en)..' (id='..tostring(it.id)..') PDT='..tostring(pdt)..' augPDT='..tostring(aug_pdt))
				return true
			end
			local suspicious = 0
			local shown = 0
			local max_show = 50
			if scope == 'all' or scope == 'cache' then
				for _, it in ipairs(full_gear_table_from_file or {}) do
					if report_if_suspicious(it) then
						suspicious = suspicious + 1
						shown = shown + 1
						if shown >= max_show then
							break
						end
					end
				end
				log('PDT check (cache): suspicious='..tostring(suspicious)..' (showing up to '..tostring(max_show)..')')
				log('Tip: equip the item once (or run //gi parse) to refresh its cached stats.')
			else
				local equip = check_equipped()
				for _, it in pairs(equip) do
					if report_if_suspicious(it) then
						suspicious = suspicious + 1
					end
				end
				log('PDT check (equipped): suspicious='..tostring(suspicious))
			end
		elseif command:lower() == 'pdtfix' then
			if type(base_desc_mentions_pdt) ~= 'function' or type(maybe_purge_suspicious_pdt) ~= 'function' then
				log('PDT fix is not ready yet. Reload addon and try again.')
				return
			end
			-- One-shot cache cleanup: remove PDT values that have no PDT source.
			local fixed = 0
			for _, it in ipairs(full_gear_table_from_file or {}) do
				if maybe_purge_suspicious_pdt(it, nil, true) then
					fixed = fixed + 1
				end
			end
			if type(full_gear_table_from_file) == 'table' and fixed > 0 then
				save_table_to_file(full_gear_table_from_file, false)
				invalidate_equipped_cache()
			end
			log('PDT fix (cache): removed PDT from '..tostring(fixed)..' item(s).')
		elseif command:lower() == 'check' then
			gi_check_dump_equipped_items()
		elseif command:lower() == 'r' or command:lower() == 'reload' then
			
			local new_item = member_table
			local f = io.open(windower.addon_path..'data/'..player.name..'_temp_party.lua','w')
			f:write('return ' .. T(new_item):tovstring())
			f:close()
			
			local new_item = _ExtraData.player.buff_details
			local f = io.open(windower.addon_path..'data/'..player.name..'_temp_buffs.lua','w')
			f:write('return ' .. T(new_item):tovstring())
			f:close()
			notice('Buffs and party saved to temp file. Reloading GI.')

			windower.send_command('lua r gearinfo;')
		elseif command:lower() == 'save' or command:lower() == 's' then
			if not args[1] then
				log('Misstype: use //gi save wstp or //gi save job')
			elseif args[1]:lower() == 'wstp' then
				WSTP = get_tp_per_hit(player.equipment).tp_per_hit_melee
			elseif args[1]:lower():match('^job') then
				local main_job = player.main_job and player.main_job:upper() or ''
				local main_job_key = main_job:lower()
				if main_job == '' then
					log('No main job detected.')
				else
					local only = has_only(args)
					local mode = nil
					ensure_job_visibility_tables()
					if args[2] and args[2]:lower() == 'extra' then
						local slots = parse_job_slots_from_args(args, 3)
						if #slots == 0 then slots = {1} end
						settings.player.job_visibility_extras[main_job_key] = settings.player.job_visibility_extras[main_job_key] or {}
						local state = capture_job_show_state()
						for _, slot in ipairs(slots) do
							settings.player.job_visibility_extras[main_job_key][slot] = state
						end
						settings.player.job_visibility_active_extra_slot[main_job_key] = slots[1]
						settings:save('all')
						log('Saved display settings for job: ' .. main_job .. ' (extra slot(s) ' .. table.concat(slots, ',') .. ')')
						return
					end

					if args[2] and args[2]:lower() == 'mode' then
						mode = normalize_job_mode(args, 3)
					else
						mode = normalize_job_mode(args, 2)
					end
					if mode then
						-- slots are optional and may be: "2 3 4" or "234"
						local slots = parse_job_slots_from_args(args, 3)
						if #slots == 0 then slots = {1} end
						settings.player.job_visibility_modes[main_job_key] = settings.player.job_visibility_modes[main_job_key] or {}
						settings.player.job_visibility_modes[main_job_key][mode] = settings.player.job_visibility_modes[main_job_key][mode] or {}
						local state = capture_job_show_state()
						for _, mode_slot in ipairs(slots) do
							settings.player.job_visibility_modes[main_job_key][mode][mode_slot] = state
						end
						settings.player.job_visibility_active_mode[main_job_key] = mode
						settings.player.job_visibility_active_mode_slot[main_job_key] = slots[1]
						settings:save('all')
						log('Saved display settings for job: ' .. main_job .. ' (mode ' .. tostring(mode) .. ', slot(s) ' .. table.concat(slots, ',') .. ')')
					else
						local slots = parse_job_slots_from_args(args, 2)
						if #slots == 0 then slots = {1} end
						settings.player.job_visibility_slots[main_job_key] = settings.player.job_visibility_slots[main_job_key] or {}
						local state = capture_job_show_state()
						for _, slot in ipairs(slots) do
							settings.player.job_visibility_slots[main_job_key][slot] = state
							-- keep slot 1 backward-compatible with existing job_visibility
							if slot == 1 then
								settings.player.job_visibility[main_job_key] = state
							end
						end
						settings.player.job_visibility_active_slot[main_job_key] = slots[1]
						settings:save('all')
						log('Saved display settings for job: ' .. main_job .. ' (slot(s) ' .. table.concat(slots, ',') .. ')')
					end
				end
			else
				log('Misstype: use //gi save wstp or //gi save job')
			end
		elseif (command:lower() == 'job')
			or (command:lower() == 'show'
				and args[1] and args[1]:lower() == 'job'
				and not (args[2] and args[2]:lower() == 'extra')) then
			if command:lower() == 'show' then
				table.remove(args,1)
			end
			local main_job = player.main_job and player.main_job:upper() or ''
			local main_job_key = main_job:lower()
			if main_job == '' then
				log('No main job detected.')
			else
				-- Support: //gi job extra [slot]
				if args[1] and args[1]:lower() == 'extra' then
					local only = has_only(args)
					local slot = normalize_job_slot(args[2])
					local extras = settings.player.job_visibility_extras
					local state = extras and extras[main_job_key] and extras[main_job_key][slot]
					if type(state) == 'table' then
						local toggle_key = 'job-extra-' .. tostring(slot)
						if only then
							apply_only_mode(toggle_key, function()
								apply_job_show_state(state)
							end)
						else
							if job_extra_toggle_active and job_extra_toggle_key == toggle_key then
								if job_extra_toggle_backup then
									apply_show_flags(job_extra_toggle_backup.show)
									if job_extra_toggle_backup.extra_all_override ~= nil then
										settings.player.extra_all_override = job_extra_toggle_backup.extra_all_override
									end
									settings.player.job_visibility = settings.player.job_visibility or {}
									settings.player.job_visibility[main_job_key] = job_extra_toggle_backup.show
								end
								if settings.player.job_visibility_active_extra_slot then
									settings.player.job_visibility_active_extra_slot[main_job_key] = nil
								end
								job_extra_toggle_active = false
								job_extra_toggle_key = nil
								job_extra_toggle_backup = nil
								settings:save('all')
								refresh_display()
								mode_refresh_pending = true
								log('Job extra: OFF')
							else
								clear_conflicting_job_toggles('extra', main_job_key)
								job_extra_toggle_backup = {
									show = snapshot_show_flags(),
									extra_all_override = settings.player.extra_all_override,
								}
								apply_job_show_state(state)
								settings.player.job_visibility_active_extra_slot = settings.player.job_visibility_active_extra_slot or {}
								settings.player.job_visibility_active_extra_slot[main_job_key] = slot
								settings:save('all')
								refresh_display()
								mode_refresh_pending = true
								job_extra_toggle_active = true
								job_extra_toggle_key = toggle_key
								log('Loaded display settings for job: ' .. main_job .. ' (extra slot ' .. tostring(slot) .. ')')
							end
						end
					else
						log('No saved extra slot ' .. tostring(slot or 1) .. ' for job: ' .. main_job)
					end
					return
				end

				local only = has_only(args)
				local mode = nil
				if args[1] and args[1]:lower() == 'mode' then
					mode = normalize_job_mode(args, 2)
				else
					mode = normalize_job_mode(args, 1)
				end
				if mode then
					local mode_slot = normalize_job_slot(args[#args]) or 1
					local modes = settings.player.job_visibility_modes
					local state = modes and modes[main_job_key] and modes[main_job_key][mode] and modes[main_job_key][mode][mode_slot]
					if type(state) == 'table' then
						if only then
							apply_only_mode('job-mode-' .. tostring(mode) .. '-' .. tostring(mode_slot), function()
								apply_job_show_state(state)
							end)
						else
							local toggle_key = 'job-mode-' .. tostring(mode) .. '-' .. tostring(mode_slot)
							if job_mode_toggle_active and job_mode_toggle_key == toggle_key then
								if job_mode_toggle_backup then
									apply_show_flags(job_mode_toggle_backup.show)
									if job_mode_toggle_backup.extra_all_override ~= nil then
										settings.player.extra_all_override = job_mode_toggle_backup.extra_all_override
									end
									if job_mode_toggle_backup.mode then
										settings.display.mode = job_mode_toggle_backup.mode
									end
									-- Persist restored state so reload does not re-apply the previous mode slot.
									settings.player.job_visibility = settings.player.job_visibility or {}
									settings.player.job_visibility[main_job_key] = job_mode_toggle_backup.show
								end
								if settings.player.job_visibility_active_mode then
									settings.player.job_visibility_active_mode[main_job_key] = nil
								end
								if settings.player.job_visibility_active_mode_slot then
									settings.player.job_visibility_active_mode_slot[main_job_key] = nil
								end
								job_mode_toggle_active = false
								job_mode_toggle_key = nil
								job_mode_toggle_backup = nil
								settings:save('all')
								refresh_display()
								mode_refresh_pending = true
								log('Job mode: OFF')
							else
								clear_conflicting_job_toggles('mode', main_job_key)
								if job_mode_toggle_active and job_mode_toggle_backup then
									apply_show_flags(job_mode_toggle_backup.show)
									if job_mode_toggle_backup.extra_all_override ~= nil then
										settings.player.extra_all_override = job_mode_toggle_backup.extra_all_override
									end
									if job_mode_toggle_backup.mode then
										settings.display.mode = job_mode_toggle_backup.mode
									end
								end
								job_mode_toggle_backup = {
									show = snapshot_show_flags(),
									extra_all_override = settings.player.extra_all_override,
									mode = settings.display.mode,
								}
								apply_job_show_state(state)
								settings.player.job_visibility_active_mode = settings.player.job_visibility_active_mode or {}
								settings.player.job_visibility_active_mode[main_job_key] = mode
								settings.player.job_visibility_active_mode_slot = settings.player.job_visibility_active_mode_slot or {}
								settings.player.job_visibility_active_mode_slot[main_job_key] = mode_slot
								settings:save('all')
								refresh_display()
								mode_refresh_pending = true
								job_mode_toggle_active = true
								job_mode_toggle_key = toggle_key
								log('Loaded display settings for job: ' .. main_job .. ' (mode ' .. tostring(mode) .. ', slot ' .. tostring(mode_slot) .. ')')
							end
						end
					else
						log('No saved mode ' .. tostring(mode) .. ' slot ' .. tostring(mode_slot) .. ' for job: ' .. main_job)
					end
				else
					local slot = normalize_job_slot(args[1]) or 1
					local slots = settings.player.job_visibility_slots
					local state = slots and slots[main_job_key] and slots[main_job_key][slot]
					if type(state) == 'table' then
						if only then
							apply_only_mode('job-slot-' .. tostring(slot), function()
								apply_job_show_state(state)
							end)
						else
							local toggle_key = 'job-slot-' .. tostring(slot)
							if job_slot_toggle_active and job_slot_toggle_key == toggle_key then
								if job_slot_toggle_backup then
									apply_show_flags(job_slot_toggle_backup.show)
									if job_slot_toggle_backup.extra_all_override ~= nil then
										settings.player.extra_all_override = job_slot_toggle_backup.extra_all_override
									end
									if job_slot_toggle_backup.mode then
										settings.display.mode = job_slot_toggle_backup.mode
									end
									-- Persist restored state so reload does not re-apply the previous job slot.
									settings.player.job_visibility = settings.player.job_visibility or {}
									settings.player.job_visibility[main_job_key] = job_slot_toggle_backup.show
								end
								if settings.player.job_visibility_active_slot then
									settings.player.job_visibility_active_slot[main_job_key] = nil
								end
								job_slot_toggle_active = false
								job_slot_toggle_key = nil
								job_slot_toggle_backup = nil
								settings:save('all')
								refresh_display()
								mode_refresh_pending = true
								log('Job slot: OFF')
							else
								clear_conflicting_job_toggles('slot', main_job_key)
								if job_slot_toggle_active and job_slot_toggle_backup then
									apply_show_flags(job_slot_toggle_backup.show)
									if job_slot_toggle_backup.extra_all_override ~= nil then
										settings.player.extra_all_override = job_slot_toggle_backup.extra_all_override
									end
									if job_slot_toggle_backup.mode then
										settings.display.mode = job_slot_toggle_backup.mode
									end
								end
								job_slot_toggle_backup = {
									show = snapshot_show_flags(),
									extra_all_override = settings.player.extra_all_override,
									mode = settings.display.mode,
								}
								apply_job_show_state(state)
								settings.player.job_visibility = settings.player.job_visibility or {}
								settings.player.job_visibility[main_job_key] = state
								settings.player.job_visibility_active_slot = settings.player.job_visibility_active_slot or {}
								settings.player.job_visibility_active_slot[main_job_key] = slot
								settings:save('all')
								refresh_display()
								mode_refresh_pending = true
								job_slot_toggle_active = true
								job_slot_toggle_key = toggle_key
								log('Loaded display settings for job: ' .. main_job .. ' (slot ' .. tostring(slot) .. ')')
							end
						end
					else
						log('No saved slot ' .. tostring(slot) .. ' for job: ' .. main_job)
					end
				end
			end
		elseif command:lower() == 'add' or command:lower() == 'remove' or command:lower() == 'hide' then
			-- Bulk toggle flags:
			--   //gi add ...   -> set show_* = true (ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â© slots/modes ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¥ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¥ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Âª ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â© ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹)
			--   //gi hide ...  -> set show_* = false (ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â±ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¶ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â·)
			--   //gi remove ...-> ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â© ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ (job / job extra / job mode) ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¥ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â  ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â£ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â·ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â©ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â·ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¡ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â´ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â±ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â©
			local verb = command:lower()
			local enable = (verb == 'add')
			local i = 1
			if args[1] and args[1]:lower() == 'mode' then
				-- ignore the mode name (just a label, no preset apply here)
				table.remove(args,1) -- 'mode'
				table.remove(args,1) -- mode name
			elseif args[1] and args[1]:lower() == 'job' then
				-- parse optional job context (job [extra] [#] or job [#])
				table.remove(args,1) -- 'job'
				if args[1] and args[1]:lower() == 'extra' then
					table.remove(args,1) -- 'extra'
					job_ctx = {type='extra', slot = normalize_job_slot(args[1]) or 1}
					if args[1] and tonumber(args[1]) then table.remove(args,1) end
				elseif args[1] and tonumber(args[1]) then
					job_ctx = {type='slot', slot = normalize_job_slot(args[1]) or 1}
					table.remove(args,1)
				end
			end
			local function flag_name(tok)
				tok = tostring(tok or ''):lower()
				local map = {
					parry = 'show_parry',
					echr = 'show_echr',
					br = 'show_br',
					echr2 = 'show_echr',
				}
				if map[tok] then return map[tok] end
				return 'show_'..tok
			end
			local touched = {}

			-- helper: apply flags to a state table (show_*) optionally saving/removing
			local function apply_flags_to_state(state_table, set_value)
				for _,t in ipairs(args) do
					if tostring(t):lower() ~= 'only' then
						local f = flag_name(t)
						if f:sub(1,5) == 'show_' then
							state_table[f] = set_value
							touched[#touched+1] = f
						end
					end
				end
			end

			if verb == 'remove' then
				local main_job = player.main_job and player.main_job:upper() or ''
				local main_job_key = main_job:lower()
				if main_job == '' then
					log('No main job detected.')
				else
					-- load target state (slot/mode/extra) or current visibility
					local state = nil
					local save_target = nil
					if job_ctx and job_ctx.type == 'slot' then
						local slots = settings.player.job_visibility_slots
						state = slots and slots[main_job_key] and slots[main_job_key][job_ctx.slot]
						save_target = {kind='slot', slot=job_ctx.slot}
					elseif job_ctx and job_ctx.type == 'extra' then
						local extras = settings.player.job_visibility_extras
						state = extras and extras[main_job_key] and extras[main_job_key][job_ctx.slot]
						save_target = {kind='extra', slot=job_ctx.slot}
					else
						local active_slot = settings.player.job_visibility_active_slot and settings.player.job_visibility_active_slot[main_job_key] or 1
						local slots = settings.player.job_visibility_slots
						state = slots and slots[main_job_key] and slots[main_job_key][active_slot]
						save_target = {kind='slot', slot=active_slot}
					end
					if type(state) ~= 'table' then
						log('No saved state for job remove target.')
					else
						apply_flags_to_state(state, false)
						-- persist
						if save_target.kind == 'slot' then
							settings.player.job_visibility_slots = settings.player.job_visibility_slots or {}
							settings.player.job_visibility_slots[main_job_key] = settings.player.job_visibility_slots[main_job_key] or {}
							settings.player.job_visibility_slots[main_job_key][save_target.slot] = state
							if save_target.slot == 1 then
								settings.player.job_visibility = settings.player.job_visibility or {}
								settings.player.job_visibility[main_job_key] = state
							end
						elseif save_target.kind == 'extra' then
							settings.player.job_visibility_extras = settings.player.job_visibility_extras or {}
							settings.player.job_visibility_extras[main_job_key] = settings.player.job_visibility_extras[main_job_key] or {}
							settings.player.job_visibility_extras[main_job_key][save_target.slot] = state
						end
						-- apply to current display
						apply_job_show_state(state)
						settings:save('all')
						refresh_display()
						mode_refresh_pending = true
						log('Removed flags: ' .. table.concat(touched, ', '))
					end
				end
			else
				-- add / hide affect live settings only (no persistence)
				apply_flags_to_state(settings.player, enable)
				refresh_display()
				mode_refresh_pending = true
				log((verb == 'add' and 'Shown: ' or 'Hidden: ') .. table.concat(touched, ', '))
			end
		elseif command:lower() == 'delete' or command:lower() == 'd' then
			if not args[1] then
				log('Misstype: use //gi delete wstp')
			elseif args[1]:lower() == 'wstp' then
				WSTP = 0
			else
				log('Misstype: use //gi delete wstp')
			end	
		elseif command:lower() == 'reset' then
			if not args[1] then
				log('Misstype: use //gi reset job')
			elseif args[1]:lower() == 'job' then
				local main_job = player.main_job and player.main_job:upper() or ''
				local main_job_key = main_job:lower()
				if main_job == '' then
					log('No main job detected.')
				else
					settings.player.job_visibility = settings.player.job_visibility or {}
					settings.player.job_visibility[main_job_key] = nil
					-- reset all show_* flags to defaults before applying job defaults
					if defaults and defaults.player then
						for key, val in pairs(defaults.player) do
							if type(key) == 'string' and key:match('^show_') then
								settings.player[key] = val
							end
						end
					end
					settings.player.extra_all_override = false
					apply_job_defaults(main_job)
					settings:save('all')
					refresh_display()
					log('Reset display settings for job: ' .. main_job)
				end
			else
				log('Misstype: use //gi reset job')
			end
		elseif command:lower() == 'hide' then
			settings.player.show_logo = false
			settings.player.show_total_haste = false
			settings.player.show_tp_Stuff = false
			settings.player.show_acc_Stuff = false
			settings.player.show_dt_Stuff = false
			settings.player.show_att_Stuff = false
			settings.player.show_Evasion = false
			settings.player.show_Defence = false
			settings.player.show_STP = false
			settings.player.show_DW_Stuff = false
			settings.player.show_MA_Stuff = false
			settings.player.show_qa_da_ta = false
			settings.player.show_total_da_ta_qa = false
			settings.player.show_sc_bonus = false
			settings.player.show_sc_damage = false
			settings.player.show_mab = false
			settings.player.show_mbd = false
			settings.player.show_mbd2 = false
			settings.player.show_pdl = false
			settings.player.show_sird = false
			settings.player.show_int = false
			settings.player.show_macc = false
			settings.player.show_regen = false
			settings.player.show_regain = false
			settings.player.show_refresh = false
			settings.player.show_parry = false
			settings.player.show_enmity = false
			settings.player.show_crit_rate = false
			settings.player.show_crit_damage = false
			settings.player.show_subtle_blow = false
			settings.player.show_subtle_blow_ii = false
			settings.player.show_magic_damage = false
			settings.player.show_magic_def_bonus = false
			settings.player.show_magic_evasion = false
			settings.player.show_counter = false
			settings.player.show_conserve_mp = false
			settings.player.show_stats = false
			settings.player.show_th = false
			settings.player.show_fc = false
			settings.player.show_cp = false
			settings.player.show_cp2 = false
			settings.player.show_echr = false
			settings.player.show_waltz = false
			settings.player.show_br = false
			settings.player.show_zanshin = false
			settings.player.show_tpb = false
			settings.player.show_killer = false
			settings.player.show_samba = false
			settings.player.show_hms = false
			settings.player.show_phalanx = false
			settings.player.show_qc = false
			settings.player.show_cst = false
			settings.player.show_hmct = false
			settings.player.show_snapshot = false
			settings.player.show_rapid_shot = false
			settings.player.show_emct = false
			settings.player.show_inq = false
			settings.player.show_emed = false
			settings.player.show_steal = false
			settings.player.show_sa = false
			settings.player.show_ta = false
			settings.player.show_allsongs = false
			settings.player.show_sed = false
			settings.player.show_sst = false
			settings.player.show_pr = false
			settings.player.show_petdt = false
			settings.player.show_ied = false
			settings.player.show_petpdt = false
			settings.player.show_petmdt = false
			settings.player.show_pethaste = false
			settings.player.show_bpd = false
			settings.player.show_bpd2 = false
			settings.player.show_bpdmg = false
			settings.player.show_apc = false
			settings.player.show_pmab = false
			settings.player.show_patt = false
			settings.player.show_pda = false
			settings.player.show_pacc = false
			settings.player.show_pmacc = false
			settings.player.show_sms = false
			settings.player.show_pbpd = false
			settings.player.show_pmdmg = false
			settings.player.show_cursna = false
			log('All display settings set to false to hide display.')
			settings:save('all')
		elseif command:lower() == 'update' then
			update_gs(DW, (DW_needed + manual_dw_needed), get_total_haste(), nil, nil, true)
		elseif command:lower() == 'updategs' or command:lower() == 'ugs' then
			if args[1] == nil then
				if settings.player.update_gs == false then
					settings.player.update_gs = true
				elseif settings.player.update_gs then
					settings.player.update_gs = false
				end
			elseif args[1]:lower() == 'true' then
				settings.player.update_gs = true
			elseif args[1]:lower() == 'false' then
				settings.player.update_gs = false
			end
			log('Auto update Gearswap = '..tostring(settings.player.update_gs))
			settings:save('all')
		elseif command:lower() == 'brd' then
			if not args[1] then
				log('Use: //gi brd <bonus> | add <name> <all_songs_bonus> | delete <name>')
			elseif type(tonumber(args[1])) == 'number' then
				manual_bard_duration_bonus = tonumber(args[1])
				log('Set Brd song+ bonus to ' .. tostring(manual_bard_duration_bonus) .. '.')
			elseif args[1]:lower() == 'add' and type(tostring(args[2])) == 'string' and type(tonumber(args[3])) == 'number' then
				settings.Bards[args[2]:lower()] = default_bard_settings
				settings.Bards[args[2]:lower()]['song_bonus']['all_songs'] = tonumber(args[3])
				settings:save('all')
				log('Added ' .. tostring(args[2]:lower()) .. ' as a known bard with +'.. tonumber(args[3]) .. ' to all songs.')
				notice('For advanced users: You may go into the settings file for your character and edit the bards in a more detailed manner.')
			elseif args[1]:lower() == 'delete' and type(tostring(args[2])) == 'string' then
				settings.Bards[tostring(args[2]):lower()] = nil
				settings:save('all')
				log('Removed ' .. tostring(args[2]:lower()) .. ' as a known bard!')
			end
		elseif command:lower() == 'cor' then
			if not args[1] then
				log('Use: //gi cor <bonus> | add <name> <bonus> | delete <name>')
			elseif type(tonumber(args[1])) == 'number' then
				manual_COR_bonus = tonumber(args[1])
				log('Set Phantom Roll bonus to ' .. tostring(manual_COR_bonus) .. '.')
			elseif args[1]:lower() == 'add' and type(tostring(args[2])) == 'string' and type(tonumber(args[3])) == 'number' then
				settings.Cors[args[2]:lower()] = tonumber(args[3])
				settings:save('all')
				log('Added ' .. tostring(args[2]:lower()) .. ' as a known COR with +' .. tonumber(args[3]) .. ' Phantom Roll !')
			elseif args[1]:lower() == 'delete' and type(tostring(args[2])) == 'string' then
				settings.Cors[tostring(args[2]):lower()] = nil
				settings:save('all')
				log('Removed ' .. tostring(args[2]:lower()) .. ' as a known COR!')
			end
		elseif command:lower() == 'geo' then
			if not args[1] then
				log('Use: //gi geo <bonus> | add <name> <bonus> | delete <name>')
			elseif type(tonumber(args[1])) == 'number' then
				manual_GEO_bonus = tonumber(args[1])
				log('Set Geomancy bonus to ' .. tostring(manual_GEO_bonus) .. '.')
			elseif args[1]:lower() == 'add' and type(tostring(args[2])) == 'string' and type(tonumber(args[3])) == 'number' then
				settings.Geos[args[2]:lower()] = args[3]
				settings:save('all')
				log('Added ' .. tostring(args[2]:lower()) .. ' as a known GEO with +' .. tonumber(args[3]) .. ' Geomancy!')
			elseif args[1]:lower() == 'delete' and type(tostring(args[2])) == 'string' then
				settings.Geos[tostring(args[2]):lower()] = nil
				settings:save('all')
				log('Removed ' .. tostring(args[2]:lower()) .. ' as a known GEO!')
			end
		elseif command:lower() == 'dnc' then
			if dancer_main then
				dancer_main = false
			else
				dancer_main = true
			end
			log('toggled DNC buff from main job to -> ' .. tostring(dancer_main) .. '.')
		elseif command:lower() == 'show' then
			local arg1 = args[1] and args[1]:lower() or ''
			local arg2 = args[2] and args[2]:lower() or ''
			local arg3 = args[3] and args[3]:lower() or ''
			local arg4 = args[4] and args[4]:lower() or ''
			local arg5 = args[5] and args[5]:lower() or ''
			local arg12 = (arg1 ~= '' and arg2 ~= '') and (arg1 .. ' ' .. arg2) or ''
			local arg123 = (arg1 ~= '' and arg2 ~= '' and arg3 ~= '') and (arg1 .. ' ' .. arg2 .. ' ' .. arg3) or ''
			local arg1234 = (arg1 ~= '' and arg2 ~= '' and arg3 ~= '' and arg4 ~= '') and (arg1 .. ' ' .. arg2 .. ' ' .. arg3 .. ' ' .. arg4) or ''
						if arg1 == '' then
				log('Use: //gi show <option> (or //gi help)')
				return
			end
if arg1 == 'reset' then
				reset_display_boxes()
			elseif arg1 == 'main' then
				toggle_group(main_show_keys)
				settings:save('all')
				refresh_display()
				mode_refresh_pending = true
				log('Show Main boxes = ' .. tostring(settings.player.show_total_haste))
			elseif arg1 == 'block' then
				local idx = tonumber(arg2)
				if not idx then
					log('Use: //gi show block 1..13')
				else
					local map = {
						[1]='show_total_haste',
						[2]='show_total_haste',
						[3]='show_total_haste',
						[4]='show_total_haste',
						[5]='show_dt_Stuff',
						[6]='show_dt_Stuff',
						[7]='show_tp_Stuff',
						[8]='show_tp_Stuff',
						[9]='show_acc_Stuff',
						[10]='show_att_Stuff',
						[11]='show_Evasion',
						[12]='show_Defence',
						[13]='show_STP',
					}
					local key = map[idx]
					if key then
						settings.player[key] = not settings.player[key]
						settings:save('all')
						refresh_display()
						mode_refresh_pending = true
						log('Show block ' .. tostring(idx) .. ' = ' .. tostring(settings.player[key]))
					else
						log('Block not mapped. Use: //gi show block 1..13')
					end
				end
			elseif arg1 == 'job' and arg2 == 'extra' then
				local main_job = player.main_job and player.main_job:upper() or ''
				local main_job_key = main_job:lower()
				if main_job == '' then
					log('No main job detected.')
				else
					local only = has_only(args)
					local slot = normalize_job_slot(arg3)
					if slot then
						local extras = settings.player.job_visibility_extras
						local state = extras and extras[main_job_key] and extras[main_job_key][slot]
						if type(state) == 'table' then
							local toggle_key = 'job-extra-' .. tostring(slot)
							if only then
								apply_only_mode('job-extra-' .. tostring(slot), function()
									apply_job_show_state(state)
								end)
							else
								if job_extra_toggle_active and job_extra_toggle_key == toggle_key then
									if job_extra_toggle_backup then
										apply_show_flags(job_extra_toggle_backup.show)
										if job_extra_toggle_backup.extra_all_override ~= nil then
											settings.player.extra_all_override = job_extra_toggle_backup.extra_all_override
										end
										-- Persist restored state so reload keeps OFF behavior.
										settings.player.job_visibility = settings.player.job_visibility or {}
										settings.player.job_visibility[main_job_key] = job_extra_toggle_backup.show
									end
									if settings.player.job_visibility_active_extra_slot then
										settings.player.job_visibility_active_extra_slot[main_job_key] = nil
									end
									job_extra_toggle_active = false
									job_extra_toggle_key = nil
									job_extra_toggle_backup = nil
									settings:save('all')
									refresh_display()
									mode_refresh_pending = true
									log('Job extra: OFF')
								else
									clear_conflicting_job_toggles('extra', main_job_key)
									if job_extra_toggle_active and job_extra_toggle_backup then
										apply_show_flags(job_extra_toggle_backup.show)
										if job_extra_toggle_backup.extra_all_override ~= nil then
											settings.player.extra_all_override = job_extra_toggle_backup.extra_all_override
										end
									end
									job_extra_toggle_backup = {
										show = snapshot_show_flags(),
										extra_all_override = settings.player.extra_all_override,
									}
									apply_job_show_state(state)
									settings.player.job_visibility_active_extra_slot = settings.player.job_visibility_active_extra_slot or {}
									settings.player.job_visibility_active_extra_slot[main_job_key] = slot
									settings:save('all')
									refresh_display()
									mode_refresh_pending = true
									job_extra_toggle_active = true
									job_extra_toggle_key = toggle_key
									log('Loaded display settings for job: ' .. main_job .. ' (extra slot ' .. tostring(slot) .. ')')
								end
							end
						else
							log('No saved extra slot ' .. tostring(slot) .. ' for job: ' .. main_job)
						end
					else
						if apply_job_extra_preset(main_job) then
							if only then
								apply_only_mode('job-extra-preset-' .. tostring(main_job), function()
									apply_job_extra_preset(main_job)
								end)
							else
								local toggle_key = 'job-extra-preset-' .. tostring(main_job)
								if job_extra_toggle_active and job_extra_toggle_key == toggle_key then
									if job_extra_toggle_backup then
										apply_show_flags(job_extra_toggle_backup.show)
										if job_extra_toggle_backup.extra_all_override ~= nil then
											settings.player.extra_all_override = job_extra_toggle_backup.extra_all_override
										end
										-- Persist restored state so reload keeps OFF behavior.
										settings.player.job_visibility = settings.player.job_visibility or {}
										settings.player.job_visibility[main_job_key] = job_extra_toggle_backup.show
									end
									if settings.player.job_visibility_active_extra_slot then
										settings.player.job_visibility_active_extra_slot[main_job_key] = nil
									end
									job_extra_toggle_active = false
									job_extra_toggle_key = nil
									job_extra_toggle_backup = nil
									settings:save('all')
									refresh_display()
									mode_refresh_pending = true
									log('Job extra: OFF')
								else
									clear_conflicting_job_toggles('extra', main_job_key)
									if job_extra_toggle_active and job_extra_toggle_backup then
										apply_show_flags(job_extra_toggle_backup.show)
										if job_extra_toggle_backup.extra_all_override ~= nil then
											settings.player.extra_all_override = job_extra_toggle_backup.extra_all_override
										end
									end
									job_extra_toggle_backup = {
										show = snapshot_show_flags(),
										extra_all_override = settings.player.extra_all_override,
									}
									apply_job_extra_preset(main_job)
									settings:save('all')
									refresh_display()
									mode_refresh_pending = true
									job_extra_toggle_active = true
									job_extra_toggle_key = toggle_key
									log('Loaded job extra preset for: ' .. main_job)
								end
							end
						else
							log('No job extra preset for: ' .. main_job)
						end
					end
				end
			elseif arg1 == 'haste' then
				if settings.player.show_total_haste == false then
					settings.player.show_total_haste = true
				elseif settings.player.show_total_haste then
					settings.player.show_total_haste = false
				end
				log('Show Haste = '..tostring(settings.player.show_total_haste))
			elseif args[1]:lower() == 'logo' then
				if settings.player.show_logo == false then
					settings.player.show_logo = true
				elseif settings.player.show_logo then
					settings.player.show_logo = false
				end
				log('Show Logo = '..tostring(settings.player.show_logo))
			elseif args[1]:lower() == 'eva' then
				if settings.player.show_Evasion == false then
					settings.player.show_Evasion = true
				elseif settings.player.show_Evasion then
					settings.player.show_Evasion = false
				end
				log('Show Evasion calculations = '..tostring(settings.player.show_Evasion))	
			elseif args[1]:lower() == 'def' then
				if settings.player.show_Defence == false then
					settings.player.show_Defence = true
				elseif settings.player.show_Defence then
					settings.player.show_Defence = false
				end
				log('Show Defence calculations = '..tostring(settings.player.show_Defence))		
			elseif args[1]:lower() == 'att' then
				if settings.player.show_att_Stuff == false then
					settings.player.show_att_Stuff = true
				elseif settings.player.show_att_Stuff then
					settings.player.show_att_Stuff = false
				end
				log('Show Attack calculations = '..tostring(settings.player.show_att_Stuff))	
			elseif args[1]:lower() == 'real' or args[1]:lower() == 'attreal' or args[1]:lower() == 'defreal' then
				local arg = args[2] and tostring(args[2]):lower() or ''
				if arg == 'on' or arg == 'true' or arg == '1' then
					settings.player.use_real_att_def = true
				elseif arg == 'off' or arg == 'false' or arg == '0' then
					settings.player.use_real_att_def = false
				elseif arg == 'status' then
					log('Use real Attack/Defence values (if available) = '..tostring(settings.player.use_real_att_def))
					return
				else
					settings.player.use_real_att_def = not settings.player.use_real_att_def
				end
				settings:save('all')
				refresh_display()
				log('Use real Attack/Defence values (if available) = '..tostring(settings.player.use_real_att_def))
			elseif args[1]:lower() == 'augonly' then
				local arg = args[2] and tostring(args[2]):lower() or ''
				if arg == 'on' or arg == 'true' or arg == '1' then
					settings.player.show_aug_only = true
				elseif arg == 'off' or arg == 'false' or arg == '0' then
					settings.player.show_aug_only = false
				elseif arg == 'status' then
					log('Show Augments Only = '..tostring(settings.player.show_aug_only))
					return
				else
					settings.player.show_aug_only = not settings.player.show_aug_only
				end
				settings:save('all')
				refresh_display()
				log('Show Augments Only = '..tostring(settings.player.show_aug_only))
			elseif args[1]:lower() == 'da' or args[1]:lower() == 'ta' or args[1]:lower() == 'qa' then
				if settings.player.show_qa_da_ta == false then
					settings.player.show_qa_da_ta = true
				elseif settings.player.show_qa_da_ta then
					settings.player.show_qa_da_ta = false
				end
				log('Show DA/TA/QA = '..tostring(settings.player.show_qa_da_ta))
			elseif args[1]:lower() == 'dta' or args[1]:lower() == 'datotal' then
				if settings.player.show_total_da_ta_qa == false then
					settings.player.show_total_da_ta_qa = true
				elseif settings.player.show_total_da_ta_qa then
					settings.player.show_total_da_ta_qa = false
				end
				log('DA+TA+QA total display disabled in this build.')
			elseif args[1]:lower() == 'scb' then
				if settings.player.show_sc_bonus == false then
					settings.player.show_sc_bonus = true
				elseif settings.player.show_sc_bonus then
					settings.player.show_sc_bonus = false
				end
				log('Show Skillchain Bonus = '..tostring(settings.player.show_sc_bonus))
			elseif args[1]:lower() == 'scd' then
				if settings.player.show_sc_damage == false then
					settings.player.show_sc_damage = true
				elseif settings.player.show_sc_damage then
					settings.player.show_sc_damage = false
				end
				log('Show Skillchain Damage = '..tostring(settings.player.show_sc_damage))
			elseif args[1]:lower() == 'mab' then
				if settings.player.show_mab == false then
					settings.player.show_mab = true
				elseif settings.player.show_mab then
					settings.player.show_mab = false
				end
				log('Show Magic Atk. Bonus = '..tostring(settings.player.show_mab))
			elseif args[1]:lower() == 'mbd' then
				if settings.player.show_mbd == false then
					settings.player.show_mbd = true
				elseif settings.player.show_mbd then
					settings.player.show_mbd = false
				end
				log('Show Magic Burst Damage = '..tostring(settings.player.show_mbd))
			elseif args[1]:lower() == 'mbd2' then
				if settings.player.show_mbd2 == false then
					settings.player.show_mbd2 = true
				elseif settings.player.show_mbd2 then
					settings.player.show_mbd2 = false
				end
				log('Show Magic Burst Damage II = '..tostring(settings.player.show_mbd2))
			elseif args[1]:lower() == 'pdl' then
				if settings.player.show_pdl == false then
					settings.player.show_pdl = true
				elseif settings.player.show_pdl then
					settings.player.show_pdl = false
				end
				log('Show PDL = '..tostring(settings.player.show_pdl))
			elseif args[1]:lower() == 'sird' then
				if settings.player.show_sird == false then
					settings.player.show_sird = true
				elseif settings.player.show_sird then
					settings.player.show_sird = false
				end
				log('Show SIRD = '..tostring(settings.player.show_sird))
			elseif args[1]:lower() == 'int' then
				if settings.player.show_int == false then
					settings.player.show_int = true
				elseif settings.player.show_int then
					settings.player.show_int = false
				end
				log('Show INT = '..tostring(settings.player.show_int))
			elseif args[1]:lower() == 'macc' then
				if settings.player.show_macc == false then
					settings.player.show_macc = true
				elseif settings.player.show_macc then
					settings.player.show_macc = false
				end
				log('Show Magic Accuracy = '..tostring(settings.player.show_macc))
			elseif args[1]:lower() == 'regen' then
				if settings.player.show_regen == false then
					settings.player.show_regen = true
				elseif settings.player.show_regen then
					settings.player.show_regen = false
				end
				log('Show Regen = '..tostring(settings.player.show_regen))
			elseif args[1]:lower() == 'regain' then
				if settings.player.show_regain == false then
					settings.player.show_regain = true
				elseif settings.player.show_regain then
					settings.player.show_regain = false
				end
				log('Show Regain = '..tostring(settings.player.show_regain))
			elseif args[1]:lower() == 'refresh' then
				if settings.player.show_refresh == false then
					settings.player.show_refresh = true
				elseif settings.player.show_refresh then
					settings.player.show_refresh = false
				end
				log('Show Refresh = '..tostring(settings.player.show_refresh))
			elseif args[1]:lower() == 'parry' or args[1]:lower() == 'parrying' then
				if settings.player.show_parry == false then
					settings.player.show_parry = true
				elseif settings.player.show_parry then
					settings.player.show_parry = false
				end
				log('Show Parry = '..tostring(settings.player.show_parry))
			elseif args[1]:lower() == 'enmity' or args[1]:lower() == 'enimity' then
				if settings.player.show_enmity == false then
					settings.player.show_enmity = true
				elseif settings.player.show_enmity then
					settings.player.show_enmity = false
				end
				log('Show Enmity = '..tostring(settings.player.show_enmity))
			elseif args[1]:lower() == 'critrate' or args[1]:lower() == 'critr' then
				if settings.player.show_crit_rate == false then
					settings.player.show_crit_rate = true
				elseif settings.player.show_crit_rate then
					settings.player.show_crit_rate = false
				end
				log('Show Critical Hit Rate = '..tostring(settings.player.show_crit_rate))
			elseif args[1]:lower() == 'critdmg' or args[1]:lower() == 'critd' then
				if settings.player.show_crit_damage == false then
					settings.player.show_crit_damage = true
				elseif settings.player.show_crit_damage then
					settings.player.show_crit_damage = false
				end
				log('Show Critical Hit Damage = '..tostring(settings.player.show_crit_damage))
			elseif args[1]:lower() == 'sb' or args[1]:lower() == 'subtleblow' then
				if settings.player.show_subtle_blow == false then
					settings.player.show_subtle_blow = true
				elseif settings.player.show_subtle_blow then
					settings.player.show_subtle_blow = false
				end
				log('Show Subtle Blow = '..tostring(settings.player.show_subtle_blow))
			elseif args[1]:lower() == 'sb2' or args[1]:lower() == 'subtleblow2' then
				if settings.player.show_subtle_blow_ii == false then
					settings.player.show_subtle_blow_ii = true
				elseif settings.player.show_subtle_blow_ii then
					settings.player.show_subtle_blow_ii = false
				end
				log('Show Subtle Blow II = '..tostring(settings.player.show_subtle_blow_ii))
			elseif args[1]:lower() == 'mdmg' then
				if settings.player.show_magic_damage == false then
					settings.player.show_magic_damage = true
				elseif settings.player.show_magic_damage then
					settings.player.show_magic_damage = false
				end
				log('Show Magic Damage = '..tostring(settings.player.show_magic_damage))
			elseif args[1]:lower() == 'mdef' or args[1]:lower() == 'mdefbn' then
				if settings.player.show_magic_def_bonus == false then
					settings.player.show_magic_def_bonus = true
				elseif settings.player.show_magic_def_bonus then
					settings.player.show_magic_def_bonus = false
				end
				log('Show Magic Def. Bonus = '..tostring(settings.player.show_magic_def_bonus))
			elseif args[1]:lower() == 'meva' then
				if settings.player.show_magic_evasion == false then
					settings.player.show_magic_evasion = true
				elseif settings.player.show_magic_evasion then
					settings.player.show_magic_evasion = false
				end
				log('Show Magic Evasion = '..tostring(settings.player.show_magic_evasion))
			elseif args[1]:lower() == 'counter' then
				if settings.player.show_counter == false then
					settings.player.show_counter = true
				elseif settings.player.show_counter then
					settings.player.show_counter = false
				end
				log('Show Counter = '..tostring(settings.player.show_counter))
			elseif args[1]:lower() == 'cmp' or args[1]:lower() == 'conserve' then
				if settings.player.show_conserve_mp == false then
					settings.player.show_conserve_mp = true
				elseif settings.player.show_conserve_mp then
					settings.player.show_conserve_mp = false
				end
				log('Show Conserve MP = '..tostring(settings.player.show_conserve_mp))
			elseif args[1]:lower() == 'extra' and args[2] and args[2]:lower() == 'all' then
				local all_on = settings.player.show_sc_bonus and settings.player.show_sc_damage and settings.player.show_mab
					and settings.player.show_mbd and settings.player.show_mbd2 and settings.player.show_int
					and settings.player.show_macc and settings.player.show_magic_damage and settings.player.show_pdl
					and settings.player.show_qa_da_ta and settings.player.show_crit_rate
					and settings.player.show_crit_damage and settings.player.show_subtle_blow
					and settings.player.show_subtle_blow_ii and settings.player.show_regen
					and settings.player.show_regain and settings.player.show_refresh and settings.player.show_parry
					and settings.player.show_enmity and settings.player.show_magic_def_bonus
					and settings.player.show_magic_evasion and settings.player.show_sird
					and settings.player.show_counter and settings.player.show_conserve_mp
					and settings.player.show_th and settings.player.show_fc and settings.player.show_cp and settings.player.show_cp2
					and settings.player.show_echr and settings.player.show_waltz and settings.player.show_br
					and settings.player.show_zanshin and settings.player.show_tpb and settings.player.show_killer
					and settings.player.show_samba and settings.player.show_hms and settings.player.show_phalanx
					and settings.player.show_qc and settings.player.show_cst and settings.player.show_hmct
					and settings.player.show_snapshot and settings.player.show_rapid_shot
					and settings.player.show_emct and settings.player.show_inq
					and settings.player.show_emed and settings.player.show_steal and settings.player.show_sa and settings.player.show_ta
					and settings.player.show_allsongs and settings.player.show_sed and settings.player.show_sst
					and settings.player.show_pr and settings.player.show_petdt and settings.player.show_ied
					and settings.player.show_petpdt and settings.player.show_petmdt
					and settings.player.show_allsongs and settings.player.show_sed and settings.player.show_sst
					and settings.player.show_pr and settings.player.show_petdt and settings.player.show_ied
					and settings.player.show_emed and settings.player.show_steal and settings.player.show_sa and settings.player.show_ta
					and settings.player.show_emct and settings.player.show_inq
					and settings.player.show_snapshot and settings.player.show_rapid_shot
					and settings.player.show_qc and settings.player.show_cst and settings.player.show_hmct
					and settings.player.show_bpd and settings.player.show_bpd2 and settings.player.show_bpdmg
					and settings.player.show_apc and settings.player.show_pmab and settings.player.show_patt
					and settings.player.show_pda and settings.player.show_pacc and settings.player.show_pmacc
					and settings.player.show_sms and settings.player.show_pbpd and settings.player.show_pmdmg
				local new_state = not all_on
				settings.player.show_sc_bonus = new_state
				settings.player.show_sc_damage = new_state
				settings.player.show_mab = new_state
				settings.player.show_mbd = new_state
				settings.player.show_mbd2 = new_state
				settings.player.show_int = new_state
				settings.player.show_macc = new_state
				settings.player.show_magic_damage = new_state
				settings.player.show_pdl = new_state
				settings.player.show_qa_da_ta = new_state
				settings.player.show_crit_rate = new_state
				settings.player.show_crit_damage = new_state
				settings.player.show_subtle_blow = new_state
				settings.player.show_subtle_blow_ii = new_state
				settings.player.show_regen = new_state
				settings.player.show_regain = new_state
				settings.player.show_refresh = new_state
				settings.player.show_parry = new_state
				settings.player.show_enmity = new_state
				settings.player.show_magic_def_bonus = new_state
				settings.player.show_magic_evasion = new_state
				settings.player.show_sird = new_state
				settings.player.show_counter = new_state
				settings.player.show_conserve_mp = new_state
				settings.player.show_th = new_state
				settings.player.show_fc = new_state
				settings.player.show_cp = new_state
				settings.player.show_cp2 = new_state
				settings.player.show_echr = new_state
				settings.player.show_waltz = new_state
				settings.player.show_br = new_state
				settings.player.show_zanshin = new_state
				settings.player.show_tpb = new_state
				settings.player.show_killer = new_state
				settings.player.show_samba = new_state
				settings.player.show_hms = new_state
				settings.player.show_phalanx = new_state
				settings.player.show_qc = new_state
				settings.player.show_cst = new_state
				settings.player.show_hmct = new_state
				settings.player.show_snapshot = new_state
				settings.player.show_rapid_shot = new_state
				settings.player.show_emct = new_state
				settings.player.show_inq = new_state
				settings.player.show_emed = new_state
				settings.player.show_steal = new_state
				settings.player.show_sa = new_state
				settings.player.show_ta = new_state
				settings.player.show_allsongs = new_state
				settings.player.show_sed = new_state
				settings.player.show_sst = new_state
				settings.player.show_pr = new_state
				settings.player.show_petdt = new_state
				settings.player.show_ied = new_state
				settings.player.show_petpdt = new_state
				settings.player.show_petmdt = new_state
				settings.player.show_bpd = new_state
				settings.player.show_bpd2 = new_state
				settings.player.show_bpdmg = new_state
				settings.player.show_apc = new_state
				settings.player.show_pmab = new_state
				settings.player.show_patt = new_state
				settings.player.show_pda = new_state
				settings.player.show_pacc = new_state
				settings.player.show_pmacc = new_state
				settings.player.show_sms = new_state
				settings.player.show_pbpd = new_state
				settings.player.show_pmdmg = new_state
				log('Show Extra All Stats = '..tostring(new_state))
			elseif args[1]:lower() == 'extra' then
				local all_on = settings.player.show_sc_bonus and settings.player.show_sc_damage and settings.player.show_mab
					and settings.player.show_mbd and settings.player.show_mbd2
				local new_state = not all_on
				settings.player.show_sc_bonus = new_state
				settings.player.show_sc_damage = new_state
				settings.player.show_mab = new_state
				settings.player.show_mbd = new_state
				settings.player.show_mbd2 = new_state
				log('Show Extra Stats = '..tostring(new_state))
				refresh_display()
			elseif args[1]:lower() == 'extra2' then
				local all_on = settings.player.show_mab and settings.player.show_mbd and settings.player.show_mbd2
					and settings.player.show_int and settings.player.show_macc and settings.player.show_magic_damage
					and settings.player.show_th and settings.player.show_fc and settings.player.show_cp and settings.player.show_cp2
					and settings.player.show_echr and settings.player.show_waltz and settings.player.show_br
					and settings.player.show_zanshin and settings.player.show_tpb and settings.player.show_killer
					and settings.player.show_samba and settings.player.show_hms and settings.player.show_cursna
				local new_state = not all_on
				settings.player.show_mab = new_state
				settings.player.show_mbd = new_state
				settings.player.show_mbd2 = new_state
				settings.player.show_int = new_state
				settings.player.show_macc = new_state
				settings.player.show_magic_damage = new_state
				settings.player.show_th = new_state
				settings.player.show_fc = new_state
				settings.player.show_cp = new_state
				settings.player.show_cp2 = new_state
				settings.player.show_echr = new_state
				settings.player.show_waltz = new_state
				settings.player.show_br = new_state
				settings.player.show_zanshin = new_state
				settings.player.show_tpb = new_state
				settings.player.show_killer = new_state
				settings.player.show_samba = new_state
				settings.player.show_hms = new_state
				settings.player.show_cursna = new_state
				log('Show Extra2 Stats = '..tostring(new_state))
				refresh_display()
			elseif args[1]:lower() == 'extra32' then
				-- subset: MAB/MBD/MBD2/INT/MAcc/M.Dmg only
				local all_on = settings.player.show_mab and settings.player.show_mbd and settings.player.show_mbd2
					and settings.player.show_int and settings.player.show_macc and settings.player.show_magic_damage
				local new_state = not all_on
				settings.player.extra32_override = new_state
				settings.player.show_mab = new_state
				settings.player.show_mbd = new_state
				settings.player.show_mbd2 = new_state
				settings.player.show_int = new_state
				settings.player.show_macc = new_state
				settings.player.show_magic_damage = new_state
				log('Show Extra32 Stats = '..tostring(new_state)..' (MAB/MBD/MBD2/INT/MAcc/M.Dmg)')
				settings:save('all')
				refresh_display()
			elseif args[1]:lower() == 'extra3' then
				local all_on = settings.player.show_pdl and settings.player.show_sc_bonus and settings.player.show_sc_damage
					and settings.player.show_phalanx and settings.player.show_qc and settings.player.show_cst
					and settings.player.show_hmct and settings.player.show_snapshot and settings.player.show_rapid_shot
					and settings.player.show_emct and settings.player.show_inq and settings.player.show_emed
					and settings.player.show_steal and settings.player.show_sa and settings.player.show_ta
					and settings.player.show_allsongs and settings.player.show_sed and settings.player.show_sst
				local new_state = not all_on
				settings.player.show_pdl = new_state
				settings.player.show_sc_bonus = new_state
				settings.player.show_sc_damage = new_state
				settings.player.show_total_da_ta_qa = false
				settings.player.show_phalanx = new_state
				settings.player.show_qc = new_state
				settings.player.show_cst = new_state
				settings.player.show_hmct = new_state
				settings.player.show_snapshot = new_state
				settings.player.show_rapid_shot = new_state
				settings.player.show_emct = new_state
				settings.player.show_inq = new_state
				settings.player.show_emed = new_state
				settings.player.show_steal = new_state
				settings.player.show_sa = new_state
				settings.player.show_ta = new_state
				settings.player.show_allsongs = new_state
				settings.player.show_sed = new_state
				settings.player.show_sst = new_state
				log('Show Extra3 Stats = '..tostring(new_state))
				refresh_display()
			elseif args[1]:lower() == 'extra33' then
				local all_on = settings.player.show_pdl and settings.player.show_sc_bonus and settings.player.show_sc_damage
				local new_state = not all_on
				settings.player.show_pdl = new_state
				settings.player.show_sc_bonus = new_state
				settings.player.show_sc_damage = new_state
				settings.player.show_total_da_ta_qa = false
				log('Show Extra33 Stats = '..tostring(new_state))
				refresh_display()
			elseif args[1]:lower() == 'extra4' then
				local all_on = settings.player.show_crit_rate and settings.player.show_crit_damage
					and settings.player.show_subtle_blow and settings.player.show_subtle_blow_ii
					and settings.player.show_pr and settings.player.show_petdt and settings.player.show_ied
					and settings.player.show_petpdt and settings.player.show_petmdt and settings.player.show_pethaste
					and settings.player.show_bpd and settings.player.show_bpd2 and settings.player.show_bpdmg
					and settings.player.show_apc and settings.player.show_pmab and settings.player.show_patt
					and settings.player.show_pda and settings.player.show_pacc and settings.player.show_pmacc
					and settings.player.show_sms and settings.player.show_pbpd and settings.player.show_pmdmg
				local new_state = not all_on
				settings.player.show_crit_rate = new_state
				settings.player.show_crit_damage = new_state
				settings.player.show_subtle_blow = new_state
				settings.player.show_subtle_blow_ii = new_state
				settings.player.show_pr = new_state
				settings.player.show_petdt = new_state
				settings.player.show_ied = new_state
				settings.player.show_petpdt = new_state
				settings.player.show_petmdt = new_state
				settings.player.show_pethaste = new_state
				settings.player.show_bpd = new_state
				settings.player.show_bpd2 = new_state
				settings.player.show_bpdmg = new_state
				settings.player.show_apc = new_state
				settings.player.show_pmab = new_state
				settings.player.show_patt = new_state
				settings.player.show_pda = new_state
				settings.player.show_pacc = new_state
				settings.player.show_pmacc = new_state
				settings.player.show_sms = new_state
				settings.player.show_pbpd = new_state
				settings.player.show_pmdmg = new_state
				log('Show Extra4 Stats = '..tostring(new_state))
				refresh_display()
			elseif args[1]:lower() == 'extra34' then
				local all_on = settings.player.show_crit_rate and settings.player.show_crit_damage
					and settings.player.show_subtle_blow and settings.player.show_subtle_blow_ii
				local new_state = not all_on
				settings.player.show_crit_rate = new_state
				settings.player.show_crit_damage = new_state
				settings.player.show_subtle_blow = new_state
				settings.player.show_subtle_blow_ii = new_state
				log('Show Extra34 Stats = '..tostring(new_state))
				refresh_display()
			elseif args[1]:lower() == 'extra5' then
				local all_on = settings.player.show_regen and settings.player.show_refresh and settings.player.show_parry
					and settings.player.show_enmity and settings.player.show_magic_def_bonus
					and settings.player.show_magic_evasion and settings.player.show_sird
				local new_state = not all_on
				settings.player.show_regen = new_state
				settings.player.show_refresh = new_state
				settings.player.show_parry = new_state
				settings.player.show_enmity = new_state
				settings.player.show_magic_def_bonus = new_state
				settings.player.show_magic_evasion = new_state
				settings.player.show_sird = new_state
				log('Show Extra5 Stats = '..tostring(new_state))
				refresh_display()
			elseif args[1]:lower() == 'extra6' then
				local all_on = settings.player.show_regain and settings.player.show_counter and settings.player.show_conserve_mp
				local new_state = not all_on
				settings.player.show_regain = new_state
				settings.player.show_counter = new_state
				settings.player.show_conserve_mp = new_state
				log('Show Extra6 Stats = '..tostring(new_state))
				refresh_display()
			elseif args[1]:lower() == 'extra7' or args[1]:lower() == 'stats' or args[1]:lower() == 'stat' or args[1]:lower() == 'vitals' then
				local new_state = not settings.player.show_stats
				settings.player.show_stats = new_state
				log('Show Stats (extra7) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra8' or args[1]:lower() == 'th' then
				local new_state = not settings.player.show_th
				settings.player.show_th = new_state
				log('Show Treasure Hunter (extra8) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra9' or args[1]:lower() == 'fc' then
				local new_state = not settings.player.show_fc
				settings.player.show_fc = new_state
				log('Show Fast Cast (extra9) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra10' then
				local all_on = settings.player.show_cp and settings.player.show_cp2
				local new_state = not all_on
				settings.player.show_cp = new_state
				settings.player.show_cp2 = new_state
				log('Show Cure Potency (extra10) = '..tostring(new_state))
			elseif args[1]:lower() == 'cp' then
				local new_state = not settings.player.show_cp
				settings.player.show_cp = new_state
				log('Show Cure Potency = '..tostring(new_state))
			elseif args[1]:lower() == 'cp2' then
				local new_state = not settings.player.show_cp2
				settings.player.show_cp2 = new_state
				log('Show Cure Potency II = '..tostring(new_state))
			elseif args[1]:lower() == 'extra11' or args[1]:lower() == 'echr' then
				local new_state = not settings.player.show_echr
				settings.player.show_echr = new_state
				log('Show Enemy Crit Rate (extra11) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra12' or args[1]:lower() == 'waltz' then
				local new_state = not settings.player.show_waltz
				settings.player.show_waltz = new_state
				log('Show Waltz (extra12) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra13' or args[1]:lower() == 'br' then
				local new_state = not settings.player.show_br
				settings.player.show_br = new_state
				log('Show Block Rate (extra13) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra14' or args[1]:lower() == 'zanshin' then
				local new_state = not settings.player.show_zanshin
				settings.player.show_zanshin = new_state
				log('Show Zanshin (extra14) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra15' or args[1]:lower() == 'tpbonus' or args[1]:lower() == 'tpb' then
				local new_state = not settings.player.show_tpb
				settings.player.show_tpb = new_state
				log('Show TP Bonus (extra15) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra16' or args[1]:lower() == 'killer' then
				local new_state = not settings.player.show_killer
				settings.player.show_killer = new_state
				log('Show Killer (extra16) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra17' or args[1]:lower() == 'samba' then
				local new_state = not settings.player.show_samba
				settings.player.show_samba = new_state
				log('Show Samba (extra17) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra18' or args[1]:lower() == 'hms' then
				local new_state = not settings.player.show_hms
				settings.player.show_hms = new_state
				log('Show Healing Magic Skill (extra18) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra19' or args[1]:lower() == 'phalanx' then
				local new_state = not settings.player.show_phalanx
				settings.player.show_phalanx = new_state
				log('Show Phalanx (extra19) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra20' then
				local all_on = settings.player.show_qc and settings.player.show_cst and settings.player.show_hmct
				local new_state = not all_on
				settings.player.show_qc = new_state
				settings.player.show_cst = new_state
				settings.player.show_hmct = new_state
				log('Show Cast-Time Stats (extra20) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra21' then
				local all_on = settings.player.show_snapshot and settings.player.show_rapid_shot
				local new_state = not all_on
				settings.player.show_snapshot = new_state
				settings.player.show_rapid_shot = new_state
				log('Show Ranged Cast Stats (extra21) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra22' then
				local new_state = not settings.player.show_emct
				settings.player.show_emct = new_state
				log('Show Elemental Magic Casting Time (extra22) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra23' then
				local new_state = not settings.player.show_inq
				settings.player.show_inq = new_state
				log('Show Inquartata (extra23) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra24' then
				local new_state = not settings.player.show_emed
				settings.player.show_emed = new_state
				log('Show Enhancing Magic Effect Duration (extra24) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra25' then
				local all_on = settings.player.show_steal and settings.player.show_sa and settings.player.show_ta
				local new_state = not all_on
				settings.player.show_steal = new_state
				settings.player.show_sa = new_state
				settings.player.show_ta = new_state
				log('Show Steal/SA/TA (extra25) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra26' then
				local all_on = settings.player.show_allsongs and settings.player.show_sed and settings.player.show_sst
				local new_state = not all_on
				settings.player.show_allsongs = new_state
				settings.player.show_sed = new_state
				settings.player.show_sst = new_state
				log('Show Song Stats (extra26) = '..tostring(new_state))
			elseif args[1]:lower() == 'extra27' then
				local all_on = settings.player.show_pr and settings.player.show_petdt and settings.player.show_ied
				local new_state = not all_on
				settings.player.show_pr = new_state
				settings.player.show_petdt = new_state
				settings.player.show_ied = new_state
				log('Show Pet/Indicolure Stats (extra27) = '..tostring(new_state))
			elseif arg1 == 'extra28' then
				local all_on = settings.player.show_bpd and settings.player.show_bpd2 and settings.player.show_bpdmg
					and settings.player.show_apc and settings.player.show_pmab and settings.player.show_patt
					and settings.player.show_pda and settings.player.show_pacc and settings.player.show_pmacc
					and settings.player.show_sms and settings.player.show_pbpd and settings.player.show_pmdmg
				local new_state = not all_on
				settings.player.show_bpd = new_state
				settings.player.show_bpd2 = new_state
				settings.player.show_bpdmg = new_state
				settings.player.show_apc = new_state
				settings.player.show_pmab = new_state
				settings.player.show_patt = new_state
				settings.player.show_pda = new_state
				settings.player.show_pacc = new_state
				settings.player.show_pmacc = new_state
				settings.player.show_sms = new_state
				settings.player.show_pbpd = new_state
				settings.player.show_pmdmg = new_state
				log('Show Blood Pact/Pet Stats (extra28) = '..tostring(new_state))
			elseif arg1 == 'extra29' then
				local all_on = settings.player.show_petpdt and settings.player.show_petmdt
				local new_state = not all_on
				settings.player.show_petpdt = new_state
				settings.player.show_petmdt = new_state
				log('Show Pet PDT/MDT (extra29) = '..tostring(new_state))
			elseif arg1 == 'extra30' then
				local new_state = not settings.player.show_pethaste
				settings.player.show_pethaste = new_state
				log('Show Pet Haste (extra30) = '..tostring(new_state))
			elseif arg1 == 'extra31' then
				local new_state = not settings.player.show_cursna
				settings.player.show_cursna = new_state
				log('Show Cursna (extra31) = '..tostring(new_state))
			elseif args[1]:lower() == 'qc' then
				local new_state = not settings.player.show_qc
				settings.player.show_qc = new_state
				log('Show Quick Cast = '..tostring(new_state))
			elseif args[1]:lower() == 'cst' then
				local new_state = not settings.player.show_cst
				settings.player.show_cst = new_state
				log('Show Cure Spellcasting Time = '..tostring(new_state))
			elseif args[1]:lower() == 'hmct' then
				local new_state = not settings.player.show_hmct
				settings.player.show_hmct = new_state
				log('Show Healing Magic Casting Time = '..tostring(new_state))
			elseif args[1]:lower() == 'snapshot' or args[1]:lower() == 'ss' then
				local new_state = not settings.player.show_snapshot
				settings.player.show_snapshot = new_state
				log('Show Snapshot = '..tostring(new_state))
			elseif arg1 == 'rapidshot' or arg12 == 'rapid shot' or arg1 == 'rs' then
				local new_state = not settings.player.show_rapid_shot
				settings.player.show_rapid_shot = new_state
				log('Show Rapid Shot = '..tostring(new_state))
			elseif args[1]:lower() == 'emct' then
				local new_state = not settings.player.show_emct
				settings.player.show_emct = new_state
				log('Show Elemental Magic Casting Time = '..tostring(new_state))
			elseif args[1]:lower() == 'inquartata' or args[1]:lower() == 'inq' then
				local new_state = not settings.player.show_inq
				settings.player.show_inq = new_state
				log('Show Inquartata = '..tostring(new_state))
			elseif args[1]:lower() == 'enh' or args[1]:lower() == 'emed' then
				local new_state = not settings.player.show_emed
				settings.player.show_emed = new_state
				log('Show Enhancing Magic Effect Duration = '..tostring(new_state))
			elseif args[1]:lower() == 'steal' then
				local new_state = not settings.player.show_steal
				settings.player.show_steal = new_state
				log('Show Steal = '..tostring(new_state))
			elseif arg12 == 'sneak attack' or arg1 == 'sa' then
				local new_state = not settings.player.show_sa
				settings.player.show_sa = new_state
				log('Show Sneak Attack = '..tostring(new_state))
			elseif arg12 == 'trick attack' or arg1 == 'ta' then
				local new_state = not settings.player.show_ta
				settings.player.show_ta = new_state
				log('Show Trick Attack = '..tostring(new_state))
			elseif arg12 == 'all songs' or arg1 == 'songs' or arg1 == 'allsongs' or arg1 == 'allsong' then
				local new_state = not settings.player.show_allsongs
				settings.player.show_allsongs = new_state
				log('Show All Songs = '..tostring(new_state))
			elseif arg123 == 'song effect duration' or arg1 == 'sed' then
				local new_state = not settings.player.show_sed
				settings.player.show_sed = new_state
				log('Show Song Effect Duration = '..tostring(new_state))
			elseif arg123 == 'song spellcasting time' or arg1 == 'sst' then
				local new_state = not settings.player.show_sst
				settings.player.show_sst = new_state
				log('Show Song Spellcasting Time = '..tostring(new_state))
			elseif arg12 == 'pet: regen' or arg12 == 'pet regen' or arg12 == 'pet r' or arg1 == 'pr' then
				local new_state = not settings.player.show_pr
				settings.player.show_pr = new_state
				log('Show Pet Regen = '..tostring(new_state))
			elseif arg123 == 'pet: damage taken' or arg12 == 'pet dt' or arg1 == 'petdt' then
				local new_state = not settings.player.show_petdt
				settings.player.show_petdt = new_state
				log('Show Pet Damage Taken = '..tostring(new_state))
			elseif arg123 == 'indicolure effect duration' or arg1 == 'ied' then
				local new_state = not settings.player.show_ied
				settings.player.show_ied = new_state
				log('Show Indicolure Effect Duration = '..tostring(new_state))
			elseif arg123 == 'blood pact delay' or arg1 == 'bpd' then
				local new_state = not settings.player.show_bpd
				settings.player.show_bpd = new_state
				log('Show Blood Pact Delay = '..tostring(new_state))
			elseif arg1234 == 'blood pact delay ii' or arg1 == 'bpd2' then
				local new_state = not settings.player.show_bpd2
				settings.player.show_bpd2 = new_state
				log('Show Blood Pact Delay II = '..tostring(new_state))
			elseif arg123 == 'blood pact damage' or arg1 == 'bpdmg' then
				local new_state = not settings.player.show_bpdmg
				settings.player.show_bpdmg = new_state
				log('Show Blood Pact Damage = '..tostring(new_state))
			elseif arg123 == 'avatar perpetuation cost' or arg1 == 'apc' then
				local new_state = not settings.player.show_apc
				settings.player.show_apc = new_state
				log('Show Avatar Perpetuation Cost = '..tostring(new_state))
			elseif arg1234 == 'pet: magic attack bonus' or arg1234 == 'pet: magic atk. bonus' or arg1 == 'pmab' then
				local new_state = not settings.player.show_pmab
				settings.player.show_pmab = new_state
				log('Show Pet Magic Atk. Bonus = '..tostring(new_state))
			elseif arg12 == 'pet: attack' or arg1 == 'patt' then
				local new_state = not settings.player.show_patt
				settings.player.show_patt = new_state
				log('Show Pet Attack = '..tostring(new_state))
			elseif arg123 == 'pet: double attack' or arg1 == 'pda' then
				local new_state = not settings.player.show_pda
				settings.player.show_pda = new_state
				log('Show Pet Double Attack = '..tostring(new_state))
			elseif arg12 == 'pet: accuracy' or arg1 == 'pacc' then
				local new_state = not settings.player.show_pacc
				settings.player.show_pacc = new_state
				log('Show Pet Accuracy = '..tostring(new_state))
			elseif arg123 == 'pet: magic accuracy' or arg1 == 'pmacc' then
				local new_state = not settings.player.show_pmacc
				settings.player.show_pmacc = new_state
				log('Show Pet Magic Accuracy = '..tostring(new_state))
			elseif arg1234 == 'pet: blood pact damage' or arg1 == 'pbpd' then
				local new_state = not settings.player.show_pbpd
				settings.player.show_pbpd = new_state
				log('Show Pet Blood Pact Damage = '..tostring(new_state))
			elseif arg123 == 'pet: magic damage' or arg1 == 'pmdmg' then
				local new_state = not settings.player.show_pmdmg
				settings.player.show_pmdmg = new_state
				log('Show Pet Magic Damage = '..tostring(new_state))
			elseif arg123 == 'summoning magic skill' or arg1 == 'sms' then
				local new_state = not settings.player.show_sms
				settings.player.show_sms = new_state
				log('Show Summoning Magic skill = '..tostring(new_state))
			elseif arg1234 == 'pet: physical damage taken' or arg12 == 'pet pdt' then
				local new_state = not settings.player.show_petpdt
				settings.player.show_petpdt = new_state
				log('Show Pet Physical Damage Taken = '..tostring(new_state))
			elseif arg1234 == 'pet: magic damage taken' or arg12 == 'pet mdt' then
				local new_state = not settings.player.show_petmdt
				settings.player.show_petmdt = new_state
				log('Show Pet Magic Damage Taken = '..tostring(new_state))
			elseif arg12 == 'pet: haste' or arg12 == 'pet h' or arg1 == 'pethast' then
				local new_state = not settings.player.show_pethaste
				settings.player.show_pethaste = new_state
				log('Show Pet Haste = '..tostring(new_state))
			elseif arg1 == 'cursna' then
				local new_state = not settings.player.show_cursna
				settings.player.show_cursna = new_state
				log('Show Cursna = '..tostring(new_state))
			elseif args[1]:lower() == 'extraall' or (args[1]:lower() == 'extra' and args[2] and args[2]:lower() == 'all') then
				local all_on = settings.player.show_sc_bonus and settings.player.show_sc_damage and settings.player.show_mab
					and settings.player.show_mbd and settings.player.show_mbd2 and settings.player.show_int
					and settings.player.show_macc and settings.player.show_magic_damage and settings.player.show_pdl
					and settings.player.show_qa_da_ta and settings.player.show_crit_rate
					and settings.player.show_crit_damage and settings.player.show_subtle_blow
					and settings.player.show_subtle_blow_ii and settings.player.show_regen
					and settings.player.show_regain and settings.player.show_refresh and settings.player.show_parry
					and settings.player.show_enmity and settings.player.show_magic_def_bonus
					and settings.player.show_magic_evasion and settings.player.show_sird
					and settings.player.show_counter and settings.player.show_conserve_mp
					and settings.player.show_th and settings.player.show_fc and settings.player.show_cp and settings.player.show_cp2
					and settings.player.show_echr and settings.player.show_waltz and settings.player.show_br
					and settings.player.show_zanshin and settings.player.show_tpb and settings.player.show_killer
					and settings.player.show_samba and settings.player.show_hms and settings.player.show_phalanx
					and settings.player.show_qc and settings.player.show_cst and settings.player.show_hmct
					and settings.player.show_snapshot and settings.player.show_rapid_shot
					and settings.player.show_emct and settings.player.show_inq
					and settings.player.show_emed and settings.player.show_steal and settings.player.show_sa and settings.player.show_ta
					and settings.player.show_allsongs and settings.player.show_sed and settings.player.show_sst
					and settings.player.show_pr and settings.player.show_petdt and settings.player.show_ied
					and settings.player.show_petpdt and settings.player.show_petmdt
					and settings.player.show_pethaste and settings.player.show_cursna
					and settings.player.show_bpd and settings.player.show_bpd2 and settings.player.show_bpdmg
					and settings.player.show_apc and settings.player.show_pmab and settings.player.show_patt
					and settings.player.show_pda and settings.player.show_pacc and settings.player.show_pmacc
					and settings.player.show_sms and settings.player.show_pbpd and settings.player.show_pmdmg
				local new_state = not all_on
				settings.player.extra_all_override = new_state
				settings.player.show_sc_bonus = new_state
				settings.player.show_sc_damage = new_state
				settings.player.show_mab = new_state
				settings.player.show_mbd = new_state
				settings.player.show_mbd2 = new_state
				settings.player.show_int = new_state
				settings.player.show_macc = new_state
				settings.player.show_magic_damage = new_state
				settings.player.show_pdl = new_state
				settings.player.show_qa_da_ta = new_state
				settings.player.show_crit_rate = new_state
				settings.player.show_crit_damage = new_state
				settings.player.show_subtle_blow = new_state
				settings.player.show_subtle_blow_ii = new_state
				settings.player.show_regen = new_state
				settings.player.show_regain = new_state
				settings.player.show_refresh = new_state
				settings.player.show_parry = new_state
				settings.player.show_enmity = new_state
				settings.player.show_magic_def_bonus = new_state
				settings.player.show_magic_evasion = new_state
				settings.player.show_sird = new_state
				settings.player.show_counter = new_state
				settings.player.show_conserve_mp = new_state
				settings.player.show_th = new_state
				settings.player.show_fc = new_state
				settings.player.show_cp = new_state
				settings.player.show_cp2 = new_state
				settings.player.show_echr = new_state
				settings.player.show_waltz = new_state
				settings.player.show_br = new_state
				settings.player.show_zanshin = new_state
				settings.player.show_tpb = new_state
				settings.player.show_killer = new_state
				settings.player.show_samba = new_state
				settings.player.show_hms = new_state
				settings.player.show_phalanx = new_state
				settings.player.show_qc = new_state
				settings.player.show_cst = new_state
				settings.player.show_hmct = new_state
				settings.player.show_snapshot = new_state
				settings.player.show_rapid_shot = new_state
				settings.player.show_emct = new_state
				settings.player.show_inq = new_state
				settings.player.show_emed = new_state
				settings.player.show_steal = new_state
				settings.player.show_sa = new_state
				settings.player.show_ta = new_state
				settings.player.show_allsongs = new_state
				settings.player.show_sed = new_state
				settings.player.show_sst = new_state
				settings.player.show_pr = new_state
				settings.player.show_petdt = new_state
				settings.player.show_ied = new_state
				settings.player.show_petpdt = new_state
				settings.player.show_petmdt = new_state
				settings.player.show_pethaste = new_state
				settings.player.show_cursna = new_state
				settings.player.show_bpd = new_state
				settings.player.show_bpd2 = new_state
				settings.player.show_bpdmg = new_state
				settings.player.show_apc = new_state
				settings.player.show_pmab = new_state
				settings.player.show_patt = new_state
				settings.player.show_pda = new_state
				settings.player.show_pacc = new_state
				settings.player.show_pmacc = new_state
				settings.player.show_sms = new_state
				settings.player.show_pbpd = new_state
				settings.player.show_pmdmg = new_state
				log('Show Extra All Stats = '..tostring(new_state))
			elseif args[1]:lower() == 'tp' then
				if settings.player.show_tp_Stuff == false then
					settings.player.show_tp_Stuff = true
				elseif settings.player.show_tp_Stuff then
					settings.player.show_tp_Stuff = false
				end
				log('Show Tp calculations = '..tostring(settings.player.show_tp_Stuff))
			elseif args[1]:lower() == 'stp' then
				if settings.player.show_STP== false then
					settings.player.show_STP = true
				elseif settings.player.show_STP then
					settings.player.show_STP = false
				end
				log('Show Store TP = '..tostring(settings.player.show_STP))
			elseif args[1]:lower() == 'dw' then
				if settings.player.show_DW_Stuff == false then
					settings.player.show_DW_Stuff = true
				elseif settings.player.show_DW_Stuff then
					settings.player.show_DW_Stuff = false
				end
				log('Show Duel Wield calculations = '..tostring(settings.player.show_DW_Stuff))
			elseif args[1]:lower() == 'ma' then
				if settings.player.show_MA_Stuff == false then
					settings.player.show_MA_Stuff = true
				elseif settings.player.show_MA_Stuff then
					settings.player.show_MA_Stuff = false
				end
				log('Show Martial Arts calculations = '..tostring(settings.player.show_MA_Stuff))
			elseif args[1]:lower() == 'acc' then
				if settings.player.show_acc_Stuff == false then
					settings.player.show_acc_Stuff = true
				elseif settings.player.show_acc_Stuff then
					settings.player.show_acc_Stuff = false
				end
				-- log('Currently dissabled, in testing.')
				log('Show Total Acc = '..tostring(settings.player.show_acc_Stuff))
			elseif args[1]:lower() == 'dt' then
				if settings.player.show_dt_Stuff == false then
					settings.player.show_dt_Stuff = true
				elseif settings.player.show_dt_Stuff then
					settings.player.show_dt_Stuff = false
				end
				-- log('Currently dissabled, in testing.')
				log('Show Defence = '..tostring(settings.player.show_dt_Stuff))
			elseif args[1]:lower() == 'cor' then
				if settings.player.show_COR_messages == false then
					settings.player.show_COR_messages = true
				elseif settings.player.show_COR_messages then
					settings.player.show_COR_messages = false
				end
				log('Cor Chat log messages set to '..tostring(settings.player.show_COR_messages))
			elseif args[1]:lower() == 'all' then
				local main_job = player.main_job and player.main_job:upper() or ''
				local extra2_job_ok = extra2_jobs[main_job] == true
				local dd_melee_job_ok = dd_melee_jobs[main_job] == true
				local extra5_job_ok = extra5_jobs[main_job] == true
				settings.player.show_logo = true
				settings.player.show_total_haste = true
				settings.player.show_tp_Stuff = true
				settings.player.show_acc_Stuff = true
				settings.player.show_dt_Stuff = true
				settings.player.show_att_Stuff = true
				settings.player.show_Evasion = true
				settings.player.show_Defence = true
				settings.player.show_STP = true
				settings.player.show_DW_Stuff = true
				settings.player.show_MA_Stuff = true
				settings.player.show_qa_da_ta = true
				settings.player.show_total_da_ta_qa = false
				settings.player.show_sc_bonus = dd_melee_job_ok
				settings.player.show_sc_damage = dd_melee_job_ok
				settings.player.show_mab = true
				settings.player.show_mbd = true
				settings.player.show_mbd2 = true
				settings.player.show_int = true
				settings.player.show_macc = true
				settings.player.show_magic_damage = true
			settings.player.show_pdl = dd_melee_job_ok
			settings.player.show_sird = extra5_job_ok
			settings.player.show_regen = extra5_job_ok
			settings.player.show_regain = true
			settings.player.show_refresh = extra5_job_ok
			settings.player.show_parry = extra5_job_ok
			settings.player.show_enmity = extra5_job_ok
			settings.player.show_crit_rate = dd_melee_job_ok
			settings.player.show_crit_damage = dd_melee_job_ok
			settings.player.show_subtle_blow = dd_melee_job_ok
			settings.player.show_subtle_blow_ii = dd_melee_job_ok
			settings.player.show_magic_def_bonus = extra5_job_ok
			settings.player.show_magic_evasion = extra5_job_ok
			settings.player.show_counter = true
			settings.player.show_conserve_mp = true
			settings.player.show_stats = true
			settings.player.show_th = true
			settings.player.show_fc = true
			settings.player.show_cp = true
			settings.player.show_cp2 = true
			settings.player.show_echr = true
			settings.player.show_waltz = true
			settings.player.show_br = true
			settings.player.show_zanshin = true
			settings.player.show_tpb = true
			settings.player.show_killer = true
			settings.player.show_samba = true
			settings.player.show_hms = true
			settings.player.show_phalanx = true
			settings.player.show_qc = true
			settings.player.show_cst = true
			settings.player.show_hmct = true
			settings.player.show_snapshot = true
			settings.player.show_rapid_shot = true
			settings.player.show_emct = true
			settings.player.show_inq = true
			settings.player.show_emed = true
			settings.player.show_steal = true
			settings.player.show_sa = true
			settings.player.show_ta = true
			settings.player.show_allsongs = true
			settings.player.show_sed = true
			settings.player.show_sst = true
			settings.player.show_pr = true
			settings.player.show_petdt = true
			settings.player.show_ied = true
			settings.player.show_petpdt = true
			settings.player.show_petmdt = true
			settings.player.show_pethaste = true
			settings.player.show_bpd = true
			settings.player.show_bpd2 = true
			settings.player.show_bpdmg = true
			settings.player.show_apc = true
			settings.player.show_pmab = true
			settings.player.show_patt = true
			settings.player.show_pda = true
			settings.player.show_pacc = true
			settings.player.show_pmacc = true
			settings.player.show_sms = true
			settings.player.show_pbpd = true
			settings.player.show_pmdmg = true
				settings.player.show_cursna = true
			log('All display settings set to true to shall all the display.')
			end
			settings:save('all')
			-- ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â£ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂªÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â·ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¡ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â  ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â±ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â© ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â© ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â£ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â± show (ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂªÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂªÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â«)
			mode_refresh_pending = true
		elseif command:lower() == 'theme' then
			if not args[1] then
				log('Use: //gi theme <folder> or //gi theme reset')
				return
			end
			if args[1]:lower() == 'reset' then
				settings.image_folder_name = defaults.image_folder_name or 'default'
				settings:save('all')
				log('Image folder reset to  --> textures/'..settings.image_folder_name)
				log('Refreshing display.')
				if sections and sections.logo then
					sections.logo:delete()
				end
				if sections and sections.block then
					for k, v in pairs(sections.block) do
						sections.block[k]:delete()
					end
				end
				return
			end
			local arg_theme = args[1]:lower()
			local theme_num = tonumber(arg_theme)
			if theme_num and theme_num >= 1 and theme_num <= 6 then
				arg_theme = 'custom' .. tostring(theme_num)
			end
			if windower.dir_exists(windower.addon_path..'textures/'..arg_theme) then
				if not files.exists('textures\\'..arg_theme ..'\\blue.png') then
					error('textures\\'..arg_theme..' is missing blue.png.')
				elseif not files.exists('textures\\'..arg_theme ..'\\dark-blue.png') then
					error('textures\\'..arg_theme..' is missing dark-blue.png.')
				elseif not files.exists('textures\\'..arg_theme ..'\\green.png') then
					error('textures\\'..arg_theme..' is missing green.png.')
				elseif not files.exists('textures\\'..arg_theme ..'\\dark-green.png') then
					error('textures\\'..arg_theme..' is missing dark-green.png.')
				elseif not files.exists('textures\\'..arg_theme ..'\\red.png') then
					error('textures\\'..arg_theme..' is missing red.png.')
				elseif not files.exists('textures\\'..arg_theme ..'\\grey.png') then
					error('textures\\'..arg_theme..' is missing grey.png.')
				elseif not files.exists('textures\\'..arg_theme ..'\\light-green.png') then
					error('textures\\'..arg_theme..' is missing light-green.png.')
				elseif not files.exists('textures\\'..arg_theme ..'\\orange.png') then
					error('textures\\'..arg_theme..' is missing orange.png.')
				elseif not files.exists('textures\\'..arg_theme ..'\\pink.png') then
					error('textures\\'..arg_theme..' is missing pink.png.')
				elseif not files.exists('textures\\'..arg_theme ..'\\purple.png') then
					error('textures\\'..arg_theme..' is missing purple.png.')
				elseif not files.exists('textures\\'..arg_theme ..'\\yellow.png') then
					error('textures\\'..arg_theme..' is missing yellow.png.')
				elseif not files.exists('textures\\'..arg_theme ..'\\logo.png') then
					error('textures\\'..arg_theme..' is missing logo.png.')
				else
				
					settings.image_folder_name = arg_theme
					settings:save('all')
					log('Image folder path changed to  --> textures/'..arg_theme)
					log('Refreshing display.')
					
					if sections and sections.logo then
						sections.logo:delete()
					end
					if sections and sections.block then
						for k, v in pairs(sections.block) do
							sections.block[k]:delete()
						end
					end
					
				end
			else
				error('the folder '..arg_theme..' does not exist.')
			end
		elseif command:lower() == 'test' then
			
			-- table.vprint(player['merits']['aggressive_aim'])
			-- for skill_name, value in pairs(player_base_skills) do
				-- if skill_name:contains('eva') then
					-- print(skill_name, value)
				-- end
			-- end
			-- if player_base_skills['evasion'] then print(player_base_skills['evasion']) end
			-- local current_equip = check_equipped()
			 
			 
			 -- for k,v in pairs(current_equip) do
			 -- --25613
				-- if v.id == 25613 then
					-- local ext = Extdata.decode(k)
					-- print(ext.type)
				-- end
				-- if v.id == 25449 then
					-- local ext = Extdata.decode(k)
					-- print(ext.type)
				-- end
			 -- end
			 
			 
			-- local Gear_info = get_equip_stats(current_equip)
			-- print(Gear_info['Evasion skill'])
			--settings.Cors['ewellina'] = nil
			-- table.vprint(_ExtraData.player.buff_details)
			--table.vprint(windower.ffxi.get_mob_by_target('t'))
			--table.vprint(member_table)
			--table.vprint(player_base_skills)
			-- local stat_table = get_equip_stats(check_equipped())
			-- local player_Acc = get_player_acc(stat_table)
			-- table.vprint(stat_table.range)
			-- log(player_Acc.agi.. '  '..stat_table["Throwing skill"] .. '  '..stat_table['Ranged Accuracy'])
			-- table.vprint( player_Acc )
			-- log(player_base_skills['hand_to_hand'])
			-- player_base_skills = player.skills
			-- get_player_skill_in_gear(check_equipped())
			--player.stats = get_packet_data_base_stats()
			-- get_packet_data()
			-- Total_acc = get_player_acc(check_equipped())
			-- log(player.stats.DEX .. ' '.. Total_acc.dex .. ' '.. Total_acc.main.. ' '.. Total_acc.sub)
			-- log(player.stats.AGI .. ' '.. Total_acc.agi .. ' '.. Total_acc.range.. ' '.. Total_acc.ammo)
		elseif command:lower() == 'debug' then
			if debug_mode == false then
				debug_mode = true
			else
				debug_mode = false
			end
			log('Toggled Debug Mode to '..tostring(debug_mode))
		elseif command:lower() == 'help' then
			
			local chat_purple = string.char(0x1F, 200)
			local chat_grey = string.char(0x1F, 160)
			local chat_red = string.char(0x1F, 167)
			local chat_white = string.char(0x1F, 001)
			local chat_green = string.char(0x1F, 214)
			local chat_yellow = string.char(0x1F, 036)
			local chat_d_blue = string.char(0x1F, 207)
			local chat_pink = string.char(0x1E, 5)
			local chat_l_blue = string.char(0x1E, 6)
			
			windower.add_to_chat(6, ' ')
			windower.add_to_chat(6, chat_white.. 	'                         --------------------------' )
			windower.add_to_chat(6, chat_d_blue.. 	'                         Welcome to GearInfo help!' )
			windower.add_to_chat(6, chat_white.. 	'                         --------------------------' )
			windower.add_to_chat(6, ' ')
			windower.add_to_chat(6, chat_d_blue.. 	'Commands available:' )
			windower.add_to_chat(6, chat_l_blue.. 	'\'//gi so|s ...\'' .. chat_white .. '  --  Alias for show (\'s\' keeps save for //gi s wstp|job).')
			windower.add_to_chat(6, chat_l_blue.. 	'              \'sa|a|rm|hi|j|m|p|re|he\'' .. chat_white .. '  --  save|add|remove|hide|job|mode|parse|reload|help aliases.')
			windower.add_to_chat(6, chat_l_blue.. 	'              \'e|ex\' and \'m|mo\'' .. chat_white .. '  --  extra/mode shortcuts in show/save/job/add/remove/hide.')
			windower.add_to_chat(6, ' ')
			windower.add_to_chat(6, chat_l_blue.. 	'\'//gi parse\'' .. chat_white .. '  --  Will reload your inventory to file (eg. after changing unity rank).')
			windower.add_to_chat(6, chat_l_blue.. 	'              \'parse back|escha|all [apply]\'' .. chat_white .. '  --  Parse GearSwap augments (apply optional).')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi rank\'' .. chat_white .. '   --  Shows current unity rank setting.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi rank #\'' .. chat_white .. '  --  Change # to your unity rank, anything under 5 is set to 5.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi stp #\'' .. chat_white .. '  --  Change # to + or - \'Store TP\' manually. eg. ' .. chat_yellow .. ' //gs stp +10'.. chat_white ..' or ' .. chat_yellow  .. '//gs stp 10')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi dw #\'' .. chat_white .. '  --  Change # to + or - \'Dual Wield\' manually. eg. ' .. chat_yellow .. ' //gs dw +10'.. chat_white ..' or ' .. chat_yellow  .. '//gs dw 10')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi ghaste #\'' .. chat_white .. '  --  Change # to + or - \'Haste\' manually. eg. ' .. chat_yellow .. ' //gs ghaste +10'.. chat_white ..' or ' .. chat_yellow  .. '//gs ghaste 10')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi mhaste #\'' .. chat_white .. '  --  Change # to + or - \'Haste\' manually. eg. ' .. chat_yellow .. ' //gs mhaste +10'.. chat_white ..' or ' .. chat_yellow  .. '//gs mhaste 10')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi jahaste #\'' .. chat_white .. '  --  Change # to + or - \'Haste\' manually. eg. ' .. chat_yellow .. ' //gs jahaste +10'.. chat_white ..' or ' .. chat_yellow  .. '//gs jahaste 10')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi dwn #\'' .. chat_white .. '  --  Change # to + or - \'DW needed\'. eg. ' .. chat_yellow .. ' //gs dwn +10'.. chat_white ..' or ' .. chat_yellow  .. '//gs dwn 10')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi show main\'' .. chat_white .. '  --  Toggle main boxes (Haste/DT/TP/Acc/Att/Eva/Def/STP).')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi show block 1..13\'' .. chat_white .. '  --  Toggle main blocks by layout order.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi limit block 1..9\'' .. chat_white .. '  --  Limit number of blocks displayed.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi limit reset\'' .. chat_white .. '  --  Clear block limit.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi save/s wstp\'' .. chat_white .. '  --  saves current tp/hit into new line.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi save job\'' .. chat_white .. '  --  saves visible boxes for current job (slot 1).')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi save job [1-9]\'' .. chat_white .. '  --  saves visible boxes for current job slot.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi save job extra [1-9]\'' .. chat_white .. '  --  saves visible boxes for current job extra slot.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi save job mode <healer|magic attack|tank|pet|dd|test> [1-9]\'' .. chat_white .. '  --  saves visible boxes for current job mode slot.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi job [1-9] [only]\'' .. chat_white .. '  --  load saved boxes for current job slot.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi show job extra [1-9] [only]\'' .. chat_white .. '  --  load saved boxes for current job extra slot (no number = job preset).')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi job mode <healer|magic attack|tank|pet|dd|test> [1-9] [only]\'' .. chat_white .. '  --  load saved boxes for current job mode slot.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi mode 1..8 [only]\'' .. chat_white .. '  --  set display mode, toggle back when repeated.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi mode calc\'' .. chat_white .. '  --  toggle calc mode (show only boxes with value > 0).')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi mode <1..8> calc\'' .. chat_white .. '  --  calc mode + layout (1=4,2=8,3=12,4=6,5=3,6=2,7=1,8=16).')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi reset job\'' .. chat_white .. '  --  resets to default boxes for current job.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi delete/d wstp\'' .. chat_white .. '  --  deletes previously created line.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi brd #\'' .. chat_white .. '  --  Change # to equal your parties BRD max March Bonus.')
			windower.add_to_chat(6, chat_l_blue..	'          add \'name\' \'bonus\'' .. chat_white .. '  --  Save the bard with name and Bonus for future use.')
			windower.add_to_chat(6, chat_yellow..	'eg. //gi brd add bob 7' .. chat_white .. '  --  This will add bob to the list with +7 March Bonus.')
			windower.add_to_chat(6, chat_l_blue..	'          delete \'name\'' .. chat_white .. '  --  Delete a bard from the list.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi cor #\'' .. chat_white .. '  --  Change # to equal your parties COR "Phantom Roll +#" bonus.')
			windower.add_to_chat(6, chat_l_blue..	'          add \'name\' \'bonus\'' .. chat_white .. '  --  Save the COR with name and Bonus for future use.')
			windower.add_to_chat(6, chat_yellow..	'eg. //gi cor add bob 3' .. chat_white .. '  --  This will add bob to the list with Phantom Roll +3. eg "Merirosvo Ring"')
			windower.add_to_chat(6, chat_l_blue..	'          delete \'name\'' .. chat_white .. '  --  Delete a COR from the list.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi geo #\'' .. chat_white .. '  --  Change # to equal your parties GEO "Geomancy +#" bonus.')
			windower.add_to_chat(6, chat_l_blue..	'          add \'name\' \'bonus\'' .. chat_white .. '  --  Save the GEO with name and Bonus for future use.')
			windower.add_to_chat(6, chat_yellow..	'eg. //gi geo add bob 5' .. chat_white .. '  --  This will add bob to the list with Geomancy +5. eg "Duna"')
			windower.add_to_chat(6, chat_l_blue..	'          delete \'name\'' .. chat_white .. '  --  Delete a GEO from the list.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi dnc\'' .. chat_white .. '  --  Toggle if your party is getting Haste Samba from a main DNC or not.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi hide\'' .. chat_white .. '  --  Hide all display (not a toggle).')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi show\'' .. chat_white .. '  --  add subcommand.')
			windower.add_to_chat(6, chat_l_blue..	'              \'haste\'' .. chat_white .. '  --  Toggle hide Total haste.')
			windower.add_to_chat(6, chat_l_blue..	'              \'tp\'' .. chat_white .. '  --  Toggle hide TP Calculator.')
			windower.add_to_chat(6, chat_l_blue..	'              \'acc\'' .. chat_white .. '  --  Toggle hide Accuracy Calculations.')
			windower.add_to_chat(6, chat_l_blue..	'              \'eva\'' .. chat_white .. '  --  Toggle hide Evasion Calculations.')
			windower.add_to_chat(6, chat_l_blue..	'              \'def\'' .. chat_white .. '  --  Toggle hide Defence Calculations.')
			windower.add_to_chat(6, chat_l_blue..	'              \'att\'' .. chat_white .. '  --  Toggle hide Attack Calculations.')
			windower.add_to_chat(6, chat_l_blue..	'              \'real [on|off|status]\'' .. chat_white .. '  --  Use real in-game Attack/Defence values when available.')
			windower.add_to_chat(6, chat_l_blue..	'              \'augonly [on|off|status]\'' .. chat_white .. '  --  Show only augment-derived stats (toggle).')
			windower.add_to_chat(6, chat_l_blue..	'              \'da\'' .. chat_white .. '  --  Toggle hide DA/TA/QA.')
			windower.add_to_chat(6, chat_l_blue..	'              \'dta\'' .. chat_white .. '  --  Toggle hide DA+TA+QA total.')
			windower.add_to_chat(6, chat_l_blue..	'              \'scb\'' .. chat_white .. '  --  Toggle hide Skillchain Bonus.')
			windower.add_to_chat(6, chat_l_blue..	'              \'scd\'' .. chat_white .. '  --  Toggle hide Skillchain Damage.')
			windower.add_to_chat(6, chat_l_blue..	'              \'mab\'' .. chat_white .. '  --  Toggle hide Magic Atk. Bonus.')
			windower.add_to_chat(6, chat_l_blue..	'              \'mbd\'' .. chat_white .. '  --  Toggle hide Magic Burst Damage.')
			windower.add_to_chat(6, chat_l_blue..	'              \'mbd2\'' .. chat_white .. '  --  Toggle hide Magic Burst Damage II.')
			windower.add_to_chat(6, chat_l_blue..	'              \'pdl\'' .. chat_white .. '  --  Toggle hide PDL.')
			windower.add_to_chat(6, chat_l_blue..	'              \'sird\'' .. chat_white .. '  --  Toggle hide SIRD.')
			windower.add_to_chat(6, chat_l_blue..	'              \'int\'' .. chat_white .. '  --  Toggle hide INT.')
			windower.add_to_chat(6, chat_l_blue..	'              \'macc\'' .. chat_white .. '  --  Toggle hide Magic Accuracy.')
			windower.add_to_chat(6, chat_l_blue..	'              \'regen\'' .. chat_white .. '  --  Toggle hide Regen.')
			windower.add_to_chat(6, chat_l_blue..	'              \'regain\'' .. chat_white .. '  --  Toggle hide Regain.')
			windower.add_to_chat(6, chat_l_blue..	'              \'refresh\'' .. chat_white .. '  --  Toggle hide Refresh.')
			windower.add_to_chat(6, chat_l_blue..	'              \'parry\'' .. chat_white .. '  --  Toggle hide Parry.')
			windower.add_to_chat(6, chat_l_blue..	'              \'enmity\'' .. chat_white .. '  --  Toggle hide Enmity.')
			windower.add_to_chat(6, chat_l_blue..	'              \'critrate\'' .. chat_white .. '  --  Toggle hide Critical Hit Rate.')
			windower.add_to_chat(6, chat_l_blue..	'              \'critdmg\'' .. chat_white .. '  --  Toggle hide Critical Hit Damage.')
			windower.add_to_chat(6, chat_l_blue..	'              \'sb\'' .. chat_white .. '  --  Toggle hide Subtle Blow.')
			windower.add_to_chat(6, chat_l_blue..	'              \'sb2\'' .. chat_white .. '  --  Toggle hide Subtle Blow II.')
			windower.add_to_chat(6, chat_l_blue..	'              \'mdmg\'' .. chat_white .. '  --  Toggle hide Magic Damage.')
			windower.add_to_chat(6, chat_l_blue..	'              \'mdef\'' .. chat_white .. '  --  Toggle hide Magic Def. Bonus.')
			windower.add_to_chat(6, chat_l_blue..	'              \'meva\'' .. chat_white .. '  --  Toggle hide Magic Evasion.')
			windower.add_to_chat(6, chat_l_blue..	'              \'counter\'' .. chat_white .. '  --  Toggle hide Counter.')
			windower.add_to_chat(6, chat_l_blue..	'              \'cmp\'' .. chat_white .. '  --  Toggle hide Conserve MP.')
			windower.add_to_chat(6, chat_l_blue..	'              \'extra\'' .. chat_white .. '  --  Toggle EXTRA 1.')
			windower.add_to_chat(6, chat_l_blue..	'              \'extra2..extra34\'' .. chat_white .. '  --  Toggle EXTRA groups.')
			windower.add_to_chat(6, chat_l_blue..	'              \'EXTRA 1-34\'' .. chat_white .. '  --  1=extra, 2..34=extra2..extra34.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi extra help\'' .. chat_white .. '  --  Show EXTRA-only help list.')
			windower.add_to_chat(6, chat_l_blue..	'              \'extra all|extraall\'' .. chat_white .. '  --  Toggle all extra groups.')
			windower.add_to_chat(6, chat_l_blue..	'              \'show reset\'' .. chat_white .. '  --  Reset all display boxes to defaults.')
			windower.add_to_chat(6, chat_l_blue..	'              \'autoparse [on|off]\'' .. chat_white .. '  --  Auto parse GearSwap augments (back+escha).')
			windower.add_to_chat(6, chat_l_blue..	'              \'safe [on|off]\'' .. chat_white .. '  --  Safe mode: block GearSwap augment parsing.')
			windower.add_to_chat(6, chat_l_blue..	'              \'ultralight [on|off|status]\'' .. chat_white .. '  --  Toggle ultra light CPU mode.')
			windower.add_to_chat(6, chat_l_blue..	'              \'turbo\'' .. chat_white .. '  --  Quick toggle ultra light mode.')
			windower.add_to_chat(6, chat_l_blue..	'              \'gsdir <path>\'' .. chat_white .. '  --  Set GearSwap data folder for parsing.')
			windower.add_to_chat(6, chat_l_blue..	'              \'back\'' .. chat_white .. '  --  Parse GearSwap back augments (apply now).')
			windower.add_to_chat(6, chat_l_blue..	'              \'escha\'' .. chat_white .. '  --  Parse GearSwap Escha/Reisen augments (save only).')
			windower.add_to_chat(6, chat_l_blue..	'              \'escha apply\'' .. chat_white .. '  --  Parse GearSwap Escha/Reisen augments (apply now).')
			windower.add_to_chat(6, chat_l_blue..	'              \'stp\'' .. chat_white .. '  --  Toggle hide STP/DTA.')
			windower.add_to_chat(6, chat_l_blue..	'              \'dw\'' .. chat_white .. '  --  Toggle hide DW Calculations.')
			windower.add_to_chat(6, chat_l_blue..	'              \'ma\'' .. chat_white .. '  --  Toggle hide MA Calculations.')
			windower.add_to_chat(6, chat_l_blue..	'              \'dt\'' .. chat_white .. '  --  Toggle hide DT Calculations.')
			windower.add_to_chat(6, chat_l_blue..	'              \'pdtmode\'' .. chat_white .. '  --  Toggle DT added into PDT only.')
			windower.add_to_chat(6, chat_l_blue..	'              \'style [box|flat [1-40]]\'' .. chat_white .. '  --  Display style (boxed or flat text themes).')
			windower.add_to_chat(6, chat_l_blue..	'              \'theme 1..30\'' .. chat_white .. '  --  Set numbered texture theme (1..6 map to custom1..custom6).')
			windower.add_to_chat(6, chat_l_blue..	'              \'theme reset\'' .. chat_white .. '  --  Reset texture theme to default.')
			windower.add_to_chat(6, chat_l_blue..	'              \'size 1..9\'' .. chat_white .. '  --  Display size (5 = default).')
			windower.add_to_chat(6, chat_l_blue..	'              \'label 1..9\'' .. chat_white .. '  --  Label text size (5 = default).')
			windower.add_to_chat(6, chat_l_blue..	'              \'value 1..9\'' .. chat_white .. '  --  Value text size (5 = default).')
			windower.add_to_chat(6, chat_l_blue..	'              \'bg 0..9\'' .. chat_white .. '  --  Flat background alpha (0 = transparent).')
			windower.add_to_chat(6, chat_l_blue..	'              \'bg a..h\'' .. chat_white .. '  --  Background image (images/<letter>.png).')
			windower.add_to_chat(6, chat_l_blue..	'              \'bg reset\'' .. chat_white .. '  --  Reset background to default.')
			windower.add_to_chat(6, chat_l_blue..	'              \'font <name>|a..k\'' .. chat_white .. '  --  Label font name or preset.')
			windower.add_to_chat(6, chat_l_blue..	'              \'font reset\'' .. chat_white .. '  --  Reset label font to default.')
			windower.add_to_chat(6, chat_l_blue..	'              \'numfont <name>|a..k\'' .. chat_white .. '  --  Value font name or preset.')
			windower.add_to_chat(6, chat_l_blue..	'              \'numfont reset\'' .. chat_white .. '  --  Reset value font to default.')
			windower.add_to_chat(6, chat_l_blue..	'              \'style reset\'' .. chat_white .. '  --  Reset style to default.')
			windower.add_to_chat(6, chat_l_blue..	'              \'style|size|label|value|bg|font|numfont|mode reset\'' .. chat_white .. '  --  Reset display settings to defaults.')
			windower.add_to_chat(6, chat_l_blue..	'              \'mode 1..8\'' .. chat_white .. '  --  Display layout mode (1=4,2=8,3=12,4=6,5=3,6=2,7=1,8=16 blocks per row).')
			windower.add_to_chat(6, chat_l_blue..	'              \'mode calc\'' .. chat_white .. '  --  Toggle calc mode (show only boxes with value > 0).')
			windower.add_to_chat(6, chat_l_blue..	'              \'mode <1..8> calc\'' .. chat_white .. '  --  Calc mode + set layout mode (1=4,2=8,3=12,4=6,5=3,6=2,7=1,8=16).')
			windower.add_to_chat(6, chat_l_blue..	'              \'test\'' .. chat_white .. '  --  Toggle test mode (mode 8, show all boxes, center display).')
			windower.add_to_chat(6, chat_l_blue..	'              \'test job\'' .. chat_white .. '  --  Toggle test job mode (mode 8, job boxes only, center display).')
			windower.add_to_chat(6, chat_l_blue..	'              \'test haste [g|m|j|a] <value%|value|cap>\'' .. chat_white .. '  --  Set test haste override (test mode only).')
			windower.add_to_chat(6, chat_l_blue..	'              \'test haste cap all\'' .. chat_white .. '  --  Set all test haste to cap (test mode only).')
			windower.add_to_chat(6, chat_l_blue..	'              \'pdtsource\'' .. chat_white .. '  --  Print PDT sources (gear + set bonus) and totals.')
			windower.add_to_chat(6, chat_l_blue..	'              \'pdtdebug\'' .. chat_white .. '  --  Print DT/PDT/MDT/BDT sources to chat.')
			windower.add_to_chat(6, chat_l_blue..	'              \'pdtcheck [equipped|all]\'' .. chat_white .. '  --  Scan suspicious PDT cache values.')
			windower.add_to_chat(6, chat_l_blue..	'              \'pdtfix\'' .. chat_white .. '  --  One-shot cache cleanup: remove corrupt PDT values (no re-parse).')
			windower.add_to_chat(6, chat_l_blue..	'              \'check\'' .. chat_white .. '  --  Print computed non-zero stats for each equipped item.')
			windower.add_to_chat(6, chat_l_blue..	'              \'all\'' .. chat_white .. '  --  Toggle all display options on.')
			windower.add_to_chat(6, chat_l_blue..	'              \'cor\'' .. chat_white .. '  --  Toggle rollTracker chat display.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi help\'' .. chat_white .. '  --  This command or any mistakes will show this menu.')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi updategs'.. chat_white ..' or ' .. chat_l_blue .. 'ugs\'' .. chat_white .. '  --  toggle Send info to GearSwap for use, Can add true / false')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi update\'' .. chat_white .. '  --  forces 1 update to gearswap')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi debug\'' .. chat_white .. '  --  toggle debug mode')
			windower.add_to_chat(6, chat_l_blue..	'\'//gi r'.. chat_white ..' or ' .. chat_l_blue .. 'reload\'' .. chat_white .. '  --  Reload addon GearInfo.')
			windower.add_to_chat(6, ' ')

		-- elseif command:lower() == 'test' then	
			-- check_none_existant_ids()
		else
			windower.send_command('gi help')
		end
	else
		windower.send_command('gi help')
	end
end)

local last_auto_save_time = 0
function save_table_to_file(item_table, quiet)

	local new_item = item_table
	
	if quiet then
		local now = os.time() or 0
		if last_auto_save_time ~= 0 and (now - last_auto_save_time) < 5 then
			return
		end
		last_auto_save_time = now
	end
	local f = io.open(windower.addon_path..'data/'..player.name..'_data.lua','w')
	f:write('return ' .. T(new_item):tovstring())
    f:close()
	if not quiet then
		notice('File Saved')
	end
end

function get_equipment_from_file()

	local f = io.open(windower.addon_path..'data/'..player.name..'_data.lua','r')
	local t = f:read("*all")
	t = assert(loadstring(t))()
	f:close()
	
	return t
end

function parse_inventory()
	
	local items_in_bag = T{}
	local full_gear_table_rw = T{}
	for k,v in pairs(res.bags) do
		for i,n in pairs(windower.ffxi.get_items(v.id)) do
			items_in_bag[#items_in_bag +1] = n
		end
	end
	for k,v in pairs(items_in_bag) do
		if v ~= nil and type(v) == 'table' then
			if v.id ~= 0 then
				local this_item = find_all_values(v)
				if this_item ~= nil then
					full_gear_table_rw[#full_gear_table_rw +1] = this_item
				end
			end
		end	
	end
	
	full_gear_table_from_file = full_gear_table_rw
	invalidate_full_gear_index()
	save_table_to_file(full_gear_table_from_file)
	invalidate_equipped_cache()
end

local function parse_aug_list(list_str)
	local augments = {}
	if not list_str or list_str == "" then
		return augments
	end
	for aug in list_str:gmatch("'([^']*)'") do
		augments[#augments + 1] = aug
	end
	if #augments == 0 then
		for aug in list_str:gmatch("\"([^\"]*)\"") do
			augments[#augments + 1] = aug
		end
	end
	return augments
end

local function parse_back_block(block)
	local name = block:match("name%s*=%s*\"([^\"]+)\"") or block:match("name%s*=%s*'([^']+)'")
	if not name then
		name = block:match("%[\"name\"%]%s*=%s*\"([^\"]+)\"") or block:match("%['name'%]%s*=%s*'([^']+)'")
	end

	local aug_start = block:find("augments%s*=%s*{")
	if not aug_start then
		return name, nil
	end

	local brace_start = block:find("{", aug_start)
	if not brace_start then
		return name, nil
	end

	local depth = 0
	local in_str = nil
	local brace_end = nil
	for i = brace_start, #block do
		local ch = block:sub(i, i)
		if in_str then
			if ch == in_str and block:sub(i - 1, i - 1) ~= "\\" then
				in_str = nil
			end
		else
			if ch == "'" or ch == "\"" then
				in_str = ch
			elseif ch == "{" then
				depth = depth + 1
			elseif ch == "}" then
				depth = depth - 1
				if depth == 0 then
					brace_end = i
					break
				end
			end
		end
		-- ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â° ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¥ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â© ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂªÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¶ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â±ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â© ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â© ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¥ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â£ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â± ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂªÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â  ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂªÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂºÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â± ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯/ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂªÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â±ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂªÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â±ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Âª
	end

	if not brace_end then
		return name, nil
	end

	local list_str = block:sub(brace_start + 1, brace_end - 1)
	return name, parse_aug_list(list_str)
end

local function extract_back_refs(content)
	local refs = {}
	for key in content:gmatch("back%s*=%s*gear%.([%w_]+)") do
		refs[#refs + 1] = key
	end
	for key in content:gmatch("back%s*=%s*gear%[%s*\"([^\"]+)\"%s*%]") do
		refs[#refs + 1] = key
	end
	for key in content:gmatch("back%s*=%s*gear%[%s*'([^']+)'%s*%]") do
		refs[#refs + 1] = key
	end
	return refs
end

local function extract_slot_tables(content, slot_name)
	local blocks = {}
	local pos = 1
	local pattern = "%f[%w_]" .. slot_name .. "%s*=%s*{"
	while true do
		local s, e = content:find(pattern, pos)
		if not s then
			break
		end
		local brace_start = content:find("{", e)
		if not brace_start then
			break
		end
		local depth = 0
		local in_str = nil
		local brace_end = nil
		for i = brace_start, #content do
			local ch = content:sub(i, i)
			if in_str then
				if ch == in_str and content:sub(i - 1, i - 1) ~= "\\" then
					in_str = nil
				end
			else
				if ch == "'" or ch == "\"" then
					in_str = ch
				elseif ch == "{" then
					depth = depth + 1
				elseif ch == "}" then
					depth = depth - 1
					if depth == 0 then
						brace_end = i
						break
					end
				end
			end
		end
		if not brace_end then
			break
		end
		blocks[#blocks + 1] = content:sub(brace_start, brace_end)
		pos = brace_end + 1
	end
	return blocks
end

local function extract_inline_slot_augments(content, slot_name)
	local results = {}
	local pos = 1
	local pattern = "%f[%w_]" .. slot_name .. "%s*=%s*"
	while true do
		local s, e = content:find(pattern, pos)
		if not s then
			break
		end
		local name = content:match("^%s*\"([^\"]+)\"", e + 1) or content:match("^%s*'([^']+)'", e + 1)
		if not name then
			pos = e + 1
		else
			local after_name = content:find(name, e + 1, true)
			local aug_pos = content:find("augments%s*=%s*{", after_name + #name)
			if not aug_pos then
				pos = after_name + #name
			else
				local brace_start = content:find("{", aug_pos)
				local depth = 0
				local in_str = nil
				local brace_end = nil
				for i = brace_start, #content do
					local ch = content:sub(i, i)
					if in_str then
						if ch == in_str and content:sub(i - 1, i - 1) ~= "\\" then
							in_str = nil
						end
					else
						if ch == "'" or ch == "\"" then
							in_str = ch
						elseif ch == "{" then
							depth = depth + 1
						elseif ch == "}" then
							depth = depth - 1
							if depth == 0 then
								brace_end = i
								break
							end
						end
					end
				end
				if brace_end then
					local list_str = content:sub(brace_start + 1, brace_end - 1)
					results[#results + 1] = {name = name, augments = parse_aug_list(list_str)}
					pos = brace_end + 1
				else
					pos = aug_pos + 1
				end
			end
		end
	end
	return results
end

local function extract_slot_refs(content, slot_name)
	local refs = {}
	for key in content:gmatch("%f[%w_]" .. slot_name .. "%s*=%s*gear%.([%w_]+)") do
		refs[#refs + 1] = key
	end
	for key in content:gmatch("%f[%w_]" .. slot_name .. "%s*=%s*gear%[%s*\"([^\"]+)\"%s*%]") do
		refs[#refs + 1] = key
	end
	for key in content:gmatch("%f[%w_]" .. slot_name .. "%s*=%s*gear%[%s*'([^']+)'%s*%]") do
		refs[#refs + 1] = key
	end
	return refs
end

local function extract_gear_tables(content)
	local blocks = {}
	local pos = 1
	while true do
		local s, e, key = content:find("gear%.([%w_]+)%s*=%s*{", pos)
		if not s then
			break
		end
		local brace_start = content:find("{", e)
		if not brace_start then
			break
		end
		local depth = 0
		local in_str = nil
		local brace_end = nil
		for i = brace_start, #content do
			local ch = content:sub(i, i)
			if in_str then
				if ch == in_str and content:sub(i - 1, i - 1) ~= "\\" then
					in_str = nil
				end
			else
				if ch == "'" or ch == "\"" then
					in_str = ch
				elseif ch == "{" then
					depth = depth + 1
				elseif ch == "}" then
					depth = depth - 1
					if depth == 0 then
						brace_end = i
						break
					end
				end
			end
		end
		if not brace_end then
			break
		end
		blocks[#blocks + 1] = {key = key, block = content:sub(brace_start, brace_end)}
		pos = brace_end + 1
	end

	pos = 1
	while true do
		local s, e, key = content:find("gear%[%s*\"([^\"]+)\"%s*%]%s*=%s*{", pos)
		if not s then
			break
		end
		local brace_start = content:find("{", e)
		if not brace_start then
			break
		end
		local depth = 0
		local in_str = nil
		local brace_end = nil
		for i = brace_start, #content do
			local ch = content:sub(i, i)
			if in_str then
				if ch == in_str and content:sub(i - 1, i - 1) ~= "\\" then
					in_str = nil
				end
			else
				if ch == "'" or ch == "\"" then
					in_str = ch
				elseif ch == "{" then
					depth = depth + 1
				elseif ch == "}" then
					depth = depth - 1
					if depth == 0 then
						brace_end = i
						break
					end
				end
			end
		end
		if not brace_end then
			break
		end
		blocks[#blocks + 1] = {key = key, block = content:sub(brace_start, brace_end)}
		pos = brace_end + 1
	end

	pos = 1
	while true do
		local s, e, key = content:find("gear%[%s*'([^']+)'%s*%]%s*=%s*{", pos)
		if not s then
			break
		end
		local brace_start = content:find("{", e)
		if not brace_start then
			break
		end
		local depth = 0
		local in_str = nil
		local brace_end = nil
		for i = brace_start, #content do
			local ch = content:sub(i, i)
			if in_str then
				if ch == in_str and content:sub(i - 1, i - 1) ~= "\\" then
					in_str = nil
				end
			else
				if ch == "'" or ch == "\"" then
					in_str = ch
				elseif ch == "{" then
					depth = depth + 1
				elseif ch == "}" then
					depth = depth - 1
					if depth == 0 then
						brace_end = i
						break
					end
				end
			end
		end
		if not brace_end then
			break
		end
		blocks[#blocks + 1] = {key = key, block = content:sub(brace_start, brace_end)}
		pos = brace_end + 1
	end

	return blocks
end

parse_gearswap_back = function(mode, apply_cache)
	mode = (mode or 'all'):lower()
	local addon_path = windower.addon_path:gsub("[/\\]+$", "")
	local root = addon_path:gsub("addons[/\\][^/\\]+$", "")
	local gs_path = (settings and settings.player and settings.player.gearswap_path)
	if not gs_path or gs_path == '' then
		gs_path = root .. "addons\\GearSwap\\data"
	end
	-- Prefer player-specific folder if set; fall back to GearSwap\data when missing.
	if not windower.dir_exists(gs_path) then
		local fallback = root .. "addons\\GearSwap\\data"
		log('GearSwap folder not found: ' .. gs_path .. ' (fallback: ' .. fallback .. ')')
		gs_path = fallback
	end
	if not windower.dir_exists(gs_path) then
		log('GearSwap data folder not found: ' .. gs_path)
		return
	end

	log('GearSwap scan path: ' .. gs_path)

	local cmd = 'dir /b /s "' .. gs_path .. '\\*.lua"'
	local p = io.popen(cmd)
	if not p then
		log('Unable to scan GearSwap files.')
		return
	end

	local files_list = {}
	local player_name = ''
	if windower.ffxi.get_player() then
		player_name = (windower.ffxi.get_player().name or ''):lower()
	end
	for line in p:lines() do
		local lower = line:lower()
		local filename = lower:match("([^\\/]+)$") or lower
		local skip_display = (player_name ~= '' and (filename:find(player_name .. "-display", 1, true)
			or filename:find(player_name .. "_display", 1, true)
			or filename:find(player_name .. "display", 1, true)))
			or filename:find("display", 1, true)
		local skip_named = filename:find("smart_autoshout", 1, true)
			or filename:find("common_info.skillchain", 1, true)
			or filename:find("common_info.status", 1, true)
			or filename:find("caster_buffwatcher", 1, true)
			or filename:find("rename", 1, true)
			or filename:find("skillup", 1, true)
		if not skip_display and not skip_named
			and not lower:find("\\backup\\", 1, true) and not lower:find("\\backup_", 1, true)
			and not lower:find("\\backup.", 1, true) and not lower:find("\\backup", 1, true)
			and not lower:find("\\archive\\", 1, true) and not lower:find("\\old\\", 1, true)
			and not lower:find("\\tmp\\", 1, true) and not lower:find("\\test\\", 1, true)
			and not lower:find("\\temp\\", 1, true) and not lower:find("\\export\\", 1, true)
			and not lower:find("\\sets\\", 1, true) and not lower:find("\\code\\", 1, true)
			and not lower:find("\\codes\\", 1, true) then
			files_list[#files_list + 1] = line
		end
	end
	p:close()

	if #files_list == 0 then
		log('No GearSwap lua files found to scan.')
		return
	end
	log('GearSwap files to scan: ' .. tostring(#files_list))
	local list_path = windower.addon_path .. 'data\\gs_scan_files.txt'
	local list_file = io.open(list_path, 'w')
	if list_file then
		for _, file_path in ipairs(files_list) do
			list_file:write(file_path .. '\n')
		end
		list_file:close()
		log('GearSwap file list saved: ' .. list_path)
	else
		log('Failed to write GearSwap file list: ' .. list_path)
	end

	local variants_back = {}
	local variants_gear = {}
	local gear_defs = {}
	local result = T{}
	local found = 0
	local conflicts = 0

	local function add_variant(variants_map, item, augments)
		if not (item and item.id) then
			return
		end
		if not (augments and #augments > 0) then
			return
		end
		for i = 1, #augments do
			augments[i] = tostring(augments[i] or ""):gsub("\r", " "):gsub("\n", " "):gsub("\"", "\\\"")
		end
		local entry = {}
		for i = 1, #augments do
			entry["Aug" .. tostring(i)] = augments[i]
		end
		variants_map[item.id] = variants_map[item.id] or {}
		local sig = table.concat(augments, " | ")
		local bucket = variants_map[item.id][sig]
		if bucket then
			bucket.count = bucket.count + 1
		else
			variants_map[item.id][sig] = {count = 1, entry = entry, augments = augments}
		end
	end

	local function choose_variants(variants_map)
		local out = T{}
		local conflicts_count = 0
		for id, buckets in pairs(variants_map) do
			local chosen = nil
			local chosen_count = -1
			local prefer_store = nil
			local prefer_da = nil
			for _, b in pairs(buckets) do
				local has_store = false
				local has_da = false
				for _, aug in ipairs(b.augments) do
					local lower = tostring(aug):lower()
					if lower:find("store tp", 1, true) then
						has_store = true
					end
					if lower:find("dbl.atk", 1, true) or lower:find("double attack", 1, true) then
						has_da = true
					end
				end
				if has_store then
					if not prefer_store or b.count > prefer_store.count then
						prefer_store = b
					end
				elseif has_da then
					if not prefer_da or b.count > prefer_da.count then
						prefer_da = b
					end
				end
				if b.count > chosen_count then
					chosen = b
					chosen_count = b.count
				end
			end
			if prefer_store then
				out[id] = prefer_store.entry
			elseif prefer_da then
				out[id] = prefer_da.entry
			elseif chosen then
				out[id] = chosen.entry
			end
			if buckets and table.length(buckets) > 1 then
				conflicts_count = conflicts_count + 1
			end
		end
		return out, conflicts_count
	end

	local function sanitize_augments(augments)
		if not augments then return augments end
		for i = 1, #augments do
			local s = tostring(augments[i] or "")
			s = s:gsub("\r", " "):gsub("\n", " ")
			-- Normalize escaped quotes coming from GearSwap definitions so we don't double-escape on save.
			s = s:gsub("\\\\\"", "\""):gsub("\\\"", "\"")
			augments[i] = s
		end
		return augments
	end

	for _, file_path in ipairs(files_list) do
		local f = io.open(file_path, 'r')
		if f then
			local content = f:read("*a")
			f:close()
			if content and content ~= "" then
				-- Fast skip: files without augments never need parsing.
				if content:find("augments", 1, true) or content:find("Augments", 1, true) then
				for _, def in ipairs(extract_gear_tables(content)) do
					local name, augments = parse_back_block(def.block)
					if def.key and name and augments and #augments > 0 then
						augments = sanitize_augments(augments)
						local current = gear_defs[def.key]
						local has_store = false
						local has_da = false
						for _, aug in ipairs(augments) do
							local lower = tostring(aug):lower()
							if lower:find("store tp", 1, true) then has_store = true end
							if lower:find("dbl.atk", 1, true) or lower:find("double attack", 1, true) then has_da = true end
						end
						if not current then
							gear_defs[def.key] = {name = name, augments = augments, has_store = has_store, has_da = has_da}
						else
							if has_store and not current.has_store then
								gear_defs[def.key] = {name = name, augments = augments, has_store = has_store, has_da = has_da}
							elseif (not has_store) and (not current.has_store) and has_da and not current.has_da then
								gear_defs[def.key] = {name = name, augments = augments, has_store = has_store, has_da = has_da}
							end
						end
					end
				end
				local slots = {"main","sub","range","ammo","head","body","hands","legs","feet","neck","waist","left_ear","right_ear","left_ring","right_ring","back"}
				for _, slot in ipairs(slots) do
					if (mode == 'back' and slot ~= 'back') or (mode == 'escha' and slot == 'back') then
						-- skip slots not requested
					else
						for _, block in ipairs(extract_slot_tables(content, slot)) do
							local name, augments = parse_back_block(block)
							if name and augments and #augments > 0 then
								augments = sanitize_augments(augments)
								local item = res.items:with('en', name)
								if not item then
									local lower = name:lower()
								item = res.items:with('enl', lower)
								if not item then
									for _, it in pairs(res.items) do
										if it.en and it.en:lower() == lower then
											item = it
											break
										end
									end
								end
							end
								if slot == "back" then
									add_variant(variants_back, item, augments)
								else
									-- Escha/Reisenjima augments: only accept ARMOR slots to avoid bad IDs on grips/ammo/etc.
									if mode ~= 'escha' or (slot == 'head' or slot == 'body' or slot == 'hands' or slot == 'legs' or slot == 'feet') then
										add_variant(variants_gear, item, augments)
									end
								end
							end
						end

						for _, inline in ipairs(extract_inline_slot_augments(content, slot)) do
							if inline.name and inline.augments and #inline.augments > 0 then
								local augments = sanitize_augments(inline.augments)
								local item = res.items:with('en', inline.name)
								if not item then
									local lower = inline.name:lower()
									item = res.items:with('enl', lower)
									if not item then
										for _, it in pairs(res.items) do
											if it.en and it.en:lower() == lower then
												item = it
												break
											end
										end
									end
								end
								if slot == "back" then
									add_variant(variants_back, item, augments)
								else
									if mode ~= 'escha' or (slot == 'head' or slot == 'body' or slot == 'hands' or slot == 'legs' or slot == 'feet') then
										add_variant(variants_gear, item, augments)
									end
								end
							end
						end

						for _, key in ipairs(extract_slot_refs(content, slot)) do
							local def = gear_defs[key]
							if def and def.name and def.augments and #def.augments > 0 then
								local item = res.items:with('en', def.name)
								if not item then
									local lower = def.name:lower()
									item = res.items:with('enl', lower)
									if not item then
										for _, it in pairs(res.items) do
											if it.en and it.en:lower() == lower then
												item = it
												break
											end
										end
									end
								end
								if slot == "back" then
									add_variant(variants_back, item, def.augments)
								else
									if mode ~= 'escha' or (slot == 'head' or slot == 'body' or slot == 'hands' or slot == 'legs' or slot == 'feet') then
										add_variant(variants_gear, item, def.augments)
									end
								end
							end
						end
					end
				end
				end
			end
		end
	end
	local result_back, conflicts_back = choose_variants(variants_back)
	local result_gear, conflicts_gear = choose_variants(variants_gear)
	conflicts = conflicts_back + conflicts_gear
	found = table.length(result_back) + table.length(result_gear)

	local function clean_aug_table(tbl)
		for _, entry in pairs(tbl or {}) do
			if type(entry) == 'table' then
				for k, v in pairs(entry) do
					if type(k) == 'string' and k:find("Aug", 1, true) and type(v) == 'string' then
						entry[k] = v:gsub("\\\\\"", "\""):gsub("\\\"", "\"")
					end
				end
			end
		end
	end

	clean_aug_table(result_back)
	clean_aug_table(result_gear)

	if mode == 'back' or mode == 'all' then
		local out_back_path = windower.addon_path .. 'aug_gears/Aug_back.lua'
		local out_back = io.open(out_back_path, 'w')
		if out_back then
			out_back:write('return ' .. T(result_back):tovstring())
			out_back:close()
			Aug_back = result_back
			log('Back augments parsed: ' .. tostring(table.length(result_back)) .. ' items. Saved to aug_gears/Aug_back.lua')
		else
			log('Failed to write aug_gears/Aug_back.lua')
		end
	end

	if mode == 'escha' or mode == 'all' then
		local out_gear_path = windower.addon_path .. 'aug_gears/Aug_escha.lua'
		local out_gear = io.open(out_gear_path, 'w')
		if out_gear then
			out_gear:write('return ' .. T(result_gear):tovstring())
			out_gear:close()
			Aug_escha = result_gear
			log('Escha/Reisen augments parsed: ' .. tostring(table.length(result_gear)) .. ' items. Saved to aug_gears/Aug_escha.lua')
		else
			log('Failed to write aug_gears/Aug_escha.lua')
		end
	end

	if conflicts > 0 then
		log('Augments conflicts: ' .. tostring(conflicts) .. ' (same item with different augments).')
	end
	if (mode == 'back' or mode == 'all') and table.length(result_back) == 0 then
		log('No back augments found.')
	end
	if (mode == 'escha' or mode == 'all') and table.length(result_gear) == 0 then
		log('No Escha/Reisen augments found.')
	end

	if apply_cache then
		log('Refreshing inventory cache to apply augments...')
		parse_inventory()
	else
		log('Augments files saved. Run //gi parse to apply when ready.')
	end
end

parse_gearswap_escha = function()
	parse_gearswap_back('escha')
end

local stats_refresh_version = 3
function parse_new_single_item(item, defer_save)

	if item ~= nil and type(item) == 'table' then
		if item.id ~= 0 then
			local this_item = find_all_values(item)
			if this_item ~= nil then
				this_item._stats_version = stats_refresh_version
				full_gear_table_from_file[#full_gear_table_from_file +1] = this_item
				invalidate_full_gear_index()
			end
			
			if not defer_save then
				save_table_to_file(full_gear_table_from_file, true)
			end
			
			return this_item
		end
	end
end

local function needs_refresh_for_new_stats(item_id, cached_item)
	if not item_id or not cached_item or not res.item_descriptions then
		return false
	end
	if cached_item._stats_version == stats_refresh_version then
		return false
	end

	local new_keys = {
		'Treasure Hunter','Fast Cast','Cure potency','Cure potency II','Enemy critical hit rate',
		'Waltz','Block rate','Zanshin','TP Bonus','Killer','Samba',
		'Healing Magic skill','Phalanx','Quick Cast','Cure spellcasting time','Healing magic casting time',
		'Snapshot','Rapid Shot','Elemental magic casting time','Inquartata',
		'Enhancing magic effect duration','Steal','Sneak Attack','Trick Attack',
		'All songs','Song effect duration','Song spellcasting time',
		'Pet: Regen','Pet: Damage Taken','Pet: Physical Damage Taken','Pet: Magic Damage Taken','Pet: Haste','Indicolure effect duration',
		'Cure potency received','Cursna',
		'Blood Pact Delay','Blood Pact Delay II','Blood Pact Damage','Avatar Perpetuation Cost',
		'Pet: Magic Atk. Bonus','Pet: Attack','Pet: Double Attack','Pet: Accuracy','Pet: Magic Accuracy',
		'Summoning Magic skill','Pet: Blood Pact Damage','Pet: Magic Damage'
	}
	for _, k in ipairs(new_keys) do
		if cached_item[k] ~= nil then
			return false
		end
	end

	local desc = res.item_descriptions:with('id', item_id)
	if not desc or not desc.en then
		return false
	end
	local s = desc.en:lower()
	local needles = {
		'treasure hunter','fast cast','cure potency','enemy critical hit rate','waltz','block rate',
		'chance of successful block','shield block rate','zanshin','tp bonus','killer','samba',
		'healing magic skill','phalanx','quick cast','cure spellcasting time','healing magic casting time',
		'snapshot','rapid shot','elemental magic casting time','inquartata',
		'enhancing magic effect duration','steal','sneak attack','trick attack',
		'all songs','song effect duration','song spellcasting time',
		'pet:','indicolure effect duration','blood pact','perpetuation cost','summoning magic skill','cursna','cure effects received','cure potency received'
		,'pet: physical damage taken','pet: magic damage taken','pet: haste'
	}
	for _, n in ipairs(needles) do
		if s:find(n, 1, true) then
			return true
		end
	end
	return false
end

local function normalize_cached_stat_key(key)
	if type(key) ~= 'string' then
		return key
	end

	local k = key:gsub('^"+', ''):gsub('"+$', '')
	k = k:gsub('^%s+', ''):gsub('%s+$', '')
	k = k:gsub('%s+', ' ')

	local aliases = {
		['"Treasure Hunter"'] = 'Treasure Hunter',
		['Treasure Hunter'] = 'Treasure Hunter',
		['Fast Cast'] = 'Fast Cast',
		['Cure Potency'] = 'Cure potency',
		['Cure Potency II'] = 'Cure potency II',
		['Enemy crit. hit rate'] = 'Enemy critical hit rate',
		['Enemy crit hit rate'] = 'Enemy critical hit rate',
		['Enemy critical hit rate'] = 'Enemy critical hit rate',
		['Waltz potency'] = 'Waltz',
		['Waltz'] = 'Waltz',
		['Block rate'] = 'Block rate',
		['Chance of successful block'] = 'Block rate',
		['Shield Block Rate'] = 'Block rate',
		['Zanshin'] = 'Zanshin',
		['TP Bonus'] = 'TP Bonus',
		['Killer effects'] = 'Killer',
		['Killer'] = 'Killer',
		['Samba duration'] = 'Samba',
		['Samba'] = 'Samba',
		['Enemy crit. hit rate'] = 'Enemy critical hit rate',
		['Enemy crit hit rate'] = 'Enemy critical hit rate',
		['Enemy critical hit rate'] = 'Enemy critical hit rate',

		['Block rate'] = 'Block rate',
		['Chance of successful block'] = 'Block rate',
		['Shield Block Rate'] = 'Block rate',
		['Phalanx received'] = 'Phalanx',
		['Quick Cast'] = 'Quick Cast',
		['"Quick Cast"'] = 'Quick Cast',
		['Occ. quickens spellcasting'] = 'Quick Cast',
		['Elemental Magic Casting Time'] = 'Elemental magic casting time',
		['Elemental magic casting time'] = 'Elemental magic casting time',
		['"Elemental Magic Casting Time"'] = 'Elemental magic casting time',
		['Inquartata'] = 'Inquartata',
		['Enhancing Magic Effect Duration'] = 'Enhancing magic effect duration',
		['Enhancing magic effect duration'] = 'Enhancing magic effect duration',
		['Enh. Mag. Eff. Dur.'] = 'Enhancing magic effect duration',
		['Steal'] = 'Steal',
		['Sneak Attack'] = 'Sneak Attack',
		['Trick Attack'] = 'Trick Attack',
		['All songs'] = 'All songs',
		['Song effect duration'] = 'Song effect duration',
		['Song spellcasting time'] = 'Song spellcasting time',
		['Pet: Regen'] = 'Pet: Regen',
		['Pet: Damage Taken'] = 'Pet: Damage Taken',
		['Pet: Physical Damage Taken'] = 'Pet: Physical Damage Taken',
		['Pet: Magic Damage Taken'] = 'Pet: Magic Damage Taken',
		['Pet: Phys. Dmg. Taken'] = 'Pet: Physical Damage Taken',
		['Pet: Mag. Dmg. Taken'] = 'Pet: Magic Damage Taken',
		['Pet: Haste'] = 'Pet: Haste',
		['Cursna'] = 'Cursna',
		['Potency of cure effects received'] = 'Cure potency received',
		['Cure Potency Received'] = 'Cure potency received',
		['Cure potency received'] = 'Cure potency received',
		['Indicolure effect duration'] = 'Indicolure effect duration',
		['Blood Pact Delay'] = 'Blood Pact Delay',
		['Blood Pact Delay II'] = 'Blood Pact Delay II',
		['Blood Pact Damage'] = 'Blood Pact Damage',
		['Avatar Perpetuation Cost'] = 'Avatar Perpetuation Cost',
		['Pet: Magic Atk. Bonus'] = 'Pet: Magic Atk. Bonus',
		['Pet: Magic Attack Bonus'] = 'Pet: Magic Atk. Bonus',
		['Pet: Attack'] = 'Pet: Attack',
		['Pet: Double Attack'] = 'Pet: Double Attack',
		['Pet: Accuracy'] = 'Pet: Accuracy',
		['Pet: Magic Accuracy'] = 'Pet: Magic Accuracy',
		['Pet: Blood Pact Damage'] = 'Pet: Blood Pact Damage',
		['Pet: Magic Damage'] = 'Pet: Magic Damage',
		['Summoning Magic skill'] = 'Summoning Magic skill',
		['Cure Spellcasting Time'] = 'Cure spellcasting time',
		['Cure spellcasting time'] = 'Cure spellcasting time',
		['"Cure Spellcasting Time"'] = 'Cure spellcasting time',
		['Healing Magic Casting Time'] = 'Healing magic casting time',
		['Healing magic casting time'] = 'Healing magic casting time',
		['"Healing Magic Casting Time"'] = 'Healing magic casting time',
		['Mag. Acc.'] = 'Magic Accuracy',
		['Mag.Acc.'] = 'Magic Accuracy',
		['Mag.Atk.Bns.'] = 'Magic Atk. Bonus',
		['Magic Attack Bonus'] = 'Magic Atk. Bonus',
		['Magic Attack'] = 'Magic Atk. Bonus',
		['WS Acc'] = 'Accuracy',
		['Weapon Skill Acc'] = 'Accuracy',
		['Weapon Skill Accuracy'] = 'Accuracy',
	}

	if aliases[k] then
		return aliases[k]
	end

	return k
end

local function normalize_cached_item_stats(item)
	if type(item) ~= 'table' then
		return
	end
	local function norm_table(t)
		if type(t) ~= 'table' then
			return
		end
		for key, value in pairs(t) do
			if type(key) == 'string' then
				local new_key = normalize_cached_stat_key(key)
				if new_key and new_key ~= key then
					if t[new_key] == nil then
						t[new_key] = value
					elseif type(value) == 'number' and type(t[new_key]) == 'number' then
						t[new_key] = t[new_key] + value
					end
					t[key] = nil
				end
			end
		end
	end
	norm_table(item)
	norm_table(item._aug_only)
end

text_mentions_pdt = function(s)
	if type(s) ~= 'string' then
		return false
	end
	local l = s:lower()
	return l:find('physical damage taken', 1, true)
		or l:find('phys. dmg. taken', 1, true)
		or l:find('phys dmg taken', 1, true)
		or l:find('pdt', 1, true)
end

augments_mentions_pdt = function(augs)
	if type(augs) == 'string' then
		return text_mentions_pdt(augs)
	end
	if type(augs) ~= 'table' then
		return false
	end
	for _, v in pairs(augs) do
		if text_mentions_pdt(v) then
			return true
		end
	end
	return false
end

base_desc_mentions_pdt = function(item_id)
	local d = res.item_descriptions and res.item_descriptions:with('id', item_id)
	if not d or not d.en then
		return false
	end
	return text_mentions_pdt(d.en)
end

purge_pdt_fields = function(item)
	if type(item) ~= 'table' then
		return
	end
	item.PDT = nil
	item.PDT2 = nil
	if type(item._aug_only) == 'table' then
		item._aug_only.PDT = nil
		item._aug_only.PDT2 = nil
	end
end

-- If cache contains PDT but neither base description nor augments mention PDT, it's almost certainly corrupt.
-- Clean it in-place (no forced re-parse) to avoid hangs/File Saved spam on gear swaps.
maybe_purge_suspicious_pdt = function(item, decoded_item_augments, force_scan)
	if type(item) ~= 'table' or not item.id or item.id == 0 then
		return false
	end
	-- Expensive check: do it once per cached item to avoid per-frame lag.
	if item._pdt_sanity_checked and not force_scan then
		return false
	end
	item._pdt_sanity_checked = true

	local has_pdt = (type(item.PDT) == 'number' and item.PDT ~= 0)
		or (type(item._aug_only) == 'table' and type(item._aug_only.PDT) == 'number' and item._aug_only.PDT ~= 0)
	if not has_pdt then
		return false
	end
	if base_desc_mentions_pdt(item.id) then
		return false
	end
	if augments_mentions_pdt(item.augments) then
		return false
	end
	if augments_mentions_pdt(decoded_item_augments) then
		return false
	end
	purge_pdt_fields(item)
	return true
end

local function apply_missing_desc_stats(item)
	if type(item) ~= 'table' or not item.id or item._desc_applied then
		return
	end
	local keys = {
		'Treasure Hunter','Fast Cast','Cure potency','Cure potency II','Enemy critical hit rate',
		'Waltz','Block rate','Zanshin','TP Bonus','Killer','Samba'
	}
	for _, k in ipairs(keys) do
		if item[k] ~= nil then
			item._stats_version = stats_refresh_version
			item._desc_applied = true
			return
		end
	end
	local desc = res.item_descriptions and res.item_descriptions:with('id', item.id)
	if not desc or not desc.en then
		return
	end
	local parsed = desypher_description(desc.en, res.items and res.items:with('id', item.id))
	if type(parsed) == 'table' then
		for k, v in pairs(parsed) do
			if item[k] == nil then
				item[k] = v
			end
		end
	end
	item._stats_version = stats_refresh_version
	item._desc_applied = true
end

function check_equipped()

	local new_gear_table = T{}
	local local_gear_table = T{}
	local cache_dirty = false
	local items_equipped = windower.ffxi.get_items().equipment
	if type(full_gear_table_from_file) ~= 'table' then
		full_gear_table_from_file = T{}
	end
	
	local default_slot = T{'sub','range','ammo','head','body','hands','legs','feet','neck','waist', 'left_ear', 'right_ear', 'left_ring', 'right_ring','back'}
	default_slot[0]= 'main'	
	
	if items_equipped then
		for id,name in pairs(default_slot) do
			items_equipped[name] = {
                    slot = items_equipped[name],
                    bag = items_equipped[name..'_bag']
                    }
                    items_equipped[name..'_bag'] = nil
			
		end
	end
	
	for k,v in pairs(items_equipped) do
		if v.slot == 0 then
			new_gear_table[k] = {count = 0 ,status = 0,id = 0,slot = 0,bazaar = 0,extdata = ''}
		else
			new_gear_table[k] = windower.ffxi.get_items(v.bag, v.slot)
		end
	end

	local sloted_items = new_gear_table
	for k,v in pairs(new_gear_table) do
		if v.count > 0 then
			-- Only trust per-item decoded augments. Do NOT fall back to global Extdata,
			-- because that can leak augments from another item and corrupt cache/stats.
			local item_augments = nil
			if (not GI_ULTRA_LIGHT_MODE) and v and v.extdata and ExtdataLib and ExtdataLib.decode then
				local ok, decoded = pcall(ExtdataLib.decode, v)
				if ok and decoded and type(decoded.augments) == 'table' and table.length(decoded.augments) > 0 then
					item_augments = decoded.augments
				end
			end
			local no_match = true
			local temp_item = new_gear_table[k]
			if GI_ULTRA_LIGHT_MODE then
				local candidates = get_cached_candidates(v.id)
				if candidates and candidates[1] then
					local selected = candidates[1]
					if type(item_augments) == 'table' and table.length(item_augments) > 0 then
						selected.augments = item_augments
					end
					local_gear_table[#local_gear_table + 1] = selected
					sloted_items[k] = local_gear_table[#local_gear_table]
					no_match = false
				else
					local quick = build_quick_item(temp_item)
					if type(item_augments) == 'table' and table.length(item_augments) > 0 then
						quick.augments = item_augments
					end
					apply_aug_sr_to_item(quick)
					local_gear_table[#local_gear_table + 1] = quick
					sloted_items[k] = local_gear_table[#local_gear_table]
					full_gear_table_from_file[#full_gear_table_from_file + 1] = quick
					invalidate_full_gear_index()
					no_match = false
				end
			end
			if no_match then
			local skip_cache = (nyame_ids and nyame_ids[v.id] and not nyame_cache_refreshed[v.id]) or false
			if (not skip_cache) and Aug_escha and Aug_escha[v.id] and is_accessory_item(v.id) and not cache_refresh_once[v.id] then
				skip_cache = true
			end
			if skip_cache then
				-- remove stale cached entries for this id so we always re-parse it
				for i = #full_gear_table_from_file, 1, -1 do
					if full_gear_table_from_file[i] and full_gear_table_from_file[i].id == v.id then
						table.remove(full_gear_table_from_file, i)
					end
				end
				invalidate_full_gear_index()
			else
				local candidates = get_cached_candidates(v.id)
				for _, y in ipairs(candidates or {}) do
					if v.id == y.id then
						if type(item_augments) == 'table' and table.length(item_augments) > 0 then
							local cached_augs = y.augments
							if type(cached_augs) == 'table' then
								local matched = 0
								for a,b in pairs(item_augments) do
									local ca = cached_augs[a]
									if type(ca) == 'string' and ca:contains(b) then
										matched = matched + 1
									end
								end
								if matched == table.length(item_augments) then
									normalize_cached_item_stats(y)
									apply_missing_desc_stats(y)
									y.augments = item_augments
									local_gear_table[#local_gear_table +1] = y
									sloted_items[k] = local_gear_table[#local_gear_table]
									no_match = false
									break
								end
							end
						else
							-- PDT sanity: clean corrupt PDT fields in-place (do not force re-parse).
							maybe_purge_suspicious_pdt(y, item_augments)
							if needs_refresh_for_new_stats(v.id, y) then
								no_match = true
								break
							end
							local selected = y
							normalize_cached_item_stats(selected)
							apply_missing_desc_stats(selected)
							maybe_purge_suspicious_pdt(selected, item_augments)
							if Aug_SR and Aug_SR[v.id] and not y['Aug_SR_Source'] then
								selected = T{}
								for kk,vv in pairs(y) do
									selected[kk] = vv
								end
								normalize_cached_item_stats(selected)
								apply_missing_desc_stats(selected)
								maybe_purge_suspicious_pdt(selected, item_augments)
								apply_aug_sr_to_item(selected)
							end
							no_match = false
							local_gear_table[#local_gear_table+1] = selected
							sloted_items[k] = local_gear_table[#local_gear_table]
							break
						end
					end	
				end
			end
			end

			if no_match == true then
				if GI_ULTRA_LIGHT_MODE then
					local quick = build_quick_item(temp_item)
					if type(item_augments) == 'table' and table.length(item_augments) > 0 then
						quick.augments = item_augments
					end
					apply_aug_sr_to_item(quick)
					local_gear_table[#local_gear_table+1] = quick
				else
					local_gear_table[#local_gear_table+1] = parse_new_single_item(temp_item, true)
				end
				if nyame_ids and nyame_ids[v.id] then
					nyame_cache_refreshed[v.id] = true
				end
				if Aug_escha and Aug_escha[v.id] and is_accessory_item(v.id) then
					cache_refresh_once[v.id] = true
				end
				sloted_items[k] = local_gear_table[#local_gear_table]
				apply_aug_sr_to_item(sloted_items[k])
				cache_dirty = true
				no_match = false
			end			
		else
			local_gear_table[#local_gear_table+1] = {id = 0, en = '', category = '', delay = 0, haste = 0, dual_wield = 0, stp = 0, augments = '' }
			sloted_items[k] = local_gear_table[#local_gear_table]
		end
	end

	if cache_dirty then
		cache_save_pending = true
		gear_info_cache_signature = nil
		gear_info_cache_aug_only = nil
		gear_info_cache_value = nil
	end
	
	--log(table.length(local_gear_table) .. ' ' .. table.length(sloted_items))
	
	player.equipment = sloted_items
	
	return sloted_items
end

--options_load()
			
-- windower.register_event('job change',function()
	-- player = windower.ffxi.get_player()
	-- -- get_player_skill_in_gear(check_equipped())
	-- -- player.stats = get_packet_data_base_stats()
    -- --initialize(text_box,settings)
-- end)

function incoming_chunk(id,data,modified,injected,blocked)
        
    if not injected and parse.i[id] then
        parse.i[id](data,blocked)
    end
end

function outgoing_chunk(id,original,data,injected,blocked)
    
    if not blocked and parse.o[id] then
        parse.o[id](data,injected)
    end
end

--table.vprint(windower.get_windower_settings())

function update()
	local inform = {}
						
	if windower.ffxi.get_info().logged_in == false then
		return
	else
		if not sections then
			sections = {block = {}}
		elseif not sections.block then
			sections.block = {}
		end
		if manual_hide == true then
			--text_box:hide()
		else
			-- if windower.ffxi.get_info().zone == 0 then
				-- text_box:hide()
			-- else
				-- text_box:show()
			-- end
		end
	
		local white = '(220,220,220)'
		local blue = '(150,150,235)'
		local red = '(255,0,0)'
		local dark_green_color = 'dark-green'
		local berry_color = 'berry'

			local main_job = player.main_job and player.main_job:upper() or ''
			local main_job_key = main_job:lower()
			if main_job ~= '' and main_job ~= last_main_job then
				last_main_job = main_job
				local slot_state = nil
				local active_slot = settings.player.job_visibility_active_slot and settings.player.job_visibility_active_slot[main_job_key]
				if active_slot and settings.player.job_visibility_slots
					and settings.player.job_visibility_slots[main_job_key]
					and settings.player.job_visibility_slots[main_job_key][active_slot] then
					slot_state = settings.player.job_visibility_slots[main_job_key][active_slot]
				elseif settings.player.job_visibility and settings.player.job_visibility[main_job_key] then
					slot_state = settings.player.job_visibility[main_job_key]
				end
				if type(slot_state) == 'table' then
					apply_job_show_state(slot_state)
				else
					apply_job_defaults(main_job)
				end
				settings:save('all')
				-- ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â£ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂªÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â·ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¡ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â  ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â±ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â© ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â© ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂªÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂªÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â«
				mode_refresh_pending = true
			end
		
		----------------------------------------------------- Haste Stuff ------------------------------------------
		local equip_sig = get_equipped_signature()
		local current_equip = get_current_equip_cached()
		local aug_only = settings.player.show_aug_only and true or false
		local aug_mode_changed = (gear_info_cache_aug_only ~= nil and gear_info_cache_aug_only ~= aug_only)
		local need_recompute = aug_mode_changed
			or (type(gear_info_cache_value) ~= 'table')
			or (gear_info_cache_signature ~= equip_sig)
		if need_recompute then
			local now = os.clock()
			local can_recompute = aug_mode_changed or (type(gear_info_cache_value) ~= 'table')
			if not can_recompute then
				if gear_info_pending_signature ~= equip_sig then
					gear_info_pending_signature = equip_sig
					gear_info_pending_since = now
				elseif (now - gear_info_pending_since) >= GEAR_INFO_STABLE_DELAY then
					can_recompute = true
				end
			end
			if can_recompute then
				current_equip = current_equip or get_current_equip_cached()
				if aug_only then
					Gear_info = get_equip_stats_aug_only(current_equip)
				else
					Gear_info = get_equip_stats(current_equip)
				end
				gear_info_cache_signature = equip_sig
				gear_info_cache_aug_only = aug_only
				gear_info_cache_value = Gear_info
				gear_info_pending_signature = nil
				gear_info_pending_since = 0
			else
				Gear_info = gear_info_cache_value
			end
		else
			Gear_info = gear_info_cache_value
		end
		if type(Gear_info) ~= 'table' then
			Gear_info = T{}
		end
		Total_haste = get_total_haste()
		
		if settings.player.show_logo == true then
			if not sections.logo then sections.logo = ImageBlock.New(1,'logo','') end
		else
			if sections.logo then sections.logo:delete() end
		end
		
			if settings.player.show_total_haste ==  true then
				if sections.block[1] and sections.block[1].color ~= 'red' then sections.block[1]:delete(); sections.block[1] = nil end
				if sections.block[2] and sections.block[2].color ~= 'red' then sections.block[2]:delete(); sections.block[2] = nil end
				if sections.block[3] and sections.block[3].color ~= 'red' then sections.block[3]:delete(); sections.block[3] = nil end
				if sections.block[4] and sections.block[4].color ~= 'red' then sections.block[4]:delete(); sections.block[4] = nil end
				if not sections.block[1] then sections.block[1] = ImageBlock.New(2,'block','red', 'G-Haste', 00) end
				if not sections.block[2] then sections.block[2] = ImageBlock.New(3,'block','red', 'M-Haste', 00) end
				if not sections.block[3] then sections.block[3] = ImageBlock.New(4,'block','red', 'JA-Haste', 00) end
				if not sections.block[4] then sections.block[4] = ImageBlock.New(5,'block','red', 'Total', 00) end
				
				if sections.block[1] and sections.block[1].text and sections.block[1].text[2] then
					local g_val = (Gear_info['Haste'] + Buffs_inform['g_haste'])
					if GI_test_mode_active and GI_test_haste_g ~= nil then
						g_val = GI_test_haste_g
					end
					safe_set_text(sections.block[1], 2, g_val)
					if g_val > 256 then
						safe_set_color(sections.block[1], 2, 255, 255, 255, 255)
					else
						safe_set_color(sections.block[1], 2, 120, 255, 255, 255)
					end
				end
			
				if sections.block[2] and sections.block[2].text and sections.block[2].text[2] then
					local m_val = (Buffs_inform['ma_haste'] + manual_mhaste)
					if GI_test_mode_active and GI_test_haste_m ~= nil then
						m_val = GI_test_haste_m
					end
					safe_set_text(sections.block[2], 2, m_val)
					if m_val > 448 then
						safe_set_color(sections.block[2], 2, 255, 255, 255, 255)
					else
						safe_set_color(sections.block[2], 2, 120, 255, 255, 255)
					end
				end
			
				if sections.block[3] and sections.block[3].text and sections.block[3].text[2] then
					local j_val = (Buffs_inform['ja_haste'] + manual_jahaste)
					if GI_test_mode_active and GI_test_haste_j ~= nil then
						j_val = GI_test_haste_j
					end
					safe_set_text(sections.block[3], 2, j_val)
					if j_val > 256 then
						safe_set_color(sections.block[3], 2, 255, 255, 255, 255)
					else
						safe_set_color(sections.block[3], 2, 120, 255, 255, 255)
					end
				end
			
				if sections.block[4] and sections.block[4].text and sections.block[4].text[2] then
					safe_set_text(sections.block[4], 2, Total_haste)
					if Total_haste > 820 then
						safe_set_color(sections.block[4], 2, 255, 255, 255, 255)
					else
						safe_set_color(sections.block[4], 2, 120, 255, 255, 255)
					end
				end
		else
			if sections.block[1] then sections.block[1]:delete() end
			if sections.block[2] then sections.block[2]:delete() end
			if sections.block[3] then sections.block[3]:delete() end
			if sections.block[4] then sections.block[4]:delete() end
		end
		
		-------------------------------------------------------------- DT stuff ---------------------------------------------------------------
		
		if settings.player.show_dt_Stuff == true then
			if not sections.block[5] then sections.block[5] = ImageBlock.New(6,'block','purple', 'DT/PDT', 00) end
			if not sections.block[7] then sections.block[7] = ImageBlock.New(8,'block','purple', 'MDT/BDT', 00) end
			if sections.block[6] then sections.block[6]:delete() end
			if sections.block[8] then sections.block[8]:delete() end
			
			local dt = (Gear_info['DT'] * (-1))
			if dt == -0 then dt = 0 end
			
			local include_dt_all = settings.player.pdt_include_dt
			local pdt_val = 0
			local pdt_warn = false
			if Gear_info['PDT2'] < 0 then
				-- PDT2 modifies the cap, but should NOT be added to display value
				local pdt = (Gear_info['PDT'] + (include_dt_all and Gear_info['DT'] or 0)) * (-1)
				if pdt == -0 then pdt = 0 end
				pdt_val = pdt
				-- Calculate cap with PDT2
				local cap = -87.6
				if (-50 + Gear_info['PDT2']) > -87.6 then
					cap = (-50 + Gear_info['PDT2'])
				end
				-- Warn if exceeding the modified cap
				if (Gear_info['PDT'] + (include_dt_all and Gear_info['DT'] or 0)) < cap then
					pdt_warn = true
				end
			else
				local pdt = (Gear_info['PDT'] + (include_dt_all and Gear_info['DT'] or 0)) * (-1)
				if pdt == -0 then pdt = 0 end
				pdt_val = pdt
				if (Gear_info['PDT'] + (include_dt_all and Gear_info['DT'] or 0)) < -51 then
					pdt_warn = true
				end
			end
			
				if sections.block[5] and sections.block[5].text and sections.block[5].text[1] and sections.block[5].text[2] then
					safe_set_text(sections.block[5], 1, 'DT/PDT')
					safe_set_text(sections.block[5], 2, tostring(dt) .. '/' .. tostring(pdt_val))
					local dt_pdt_warn = (Gear_info['DT'] < (-51)) or pdt_warn
					if dt_pdt_warn then
						safe_set_color(sections.block[5], 2, 255, 255, 0, 0)
					else
						safe_set_color(sections.block[5], 2, 255, 255, 255, 255)
					end
				end
			
			local include_dt_mdt = settings.player.dt_include_dt
			local mdt_val = 0
			local mdt_warn = false
			if Gear_info['MDT2'] < 0 then
				-- MDT2 modifies the cap, but should NOT be added to display value
				local mdt = (Gear_info['MDT'] + (include_dt_mdt and Gear_info['DT'] or 0)) * (-1)
				if mdt == -0 then mdt = 0 end
				mdt_val = mdt
				-- Calculate cap with MDT2
				local cap = -87.6
				if (-50 + Gear_info['MDT2']) > -87.6 then
					cap = (-50 + Gear_info['MDT2'])
				end
				-- Warn if exceeding the modified cap
				if (Gear_info['MDT'] + (include_dt_mdt and Gear_info['DT'] or 0)) < cap then
					mdt_warn = true
				end
			else
				local mdt = (Gear_info['MDT'] + (include_dt_mdt and Gear_info['DT'] or 0)) * (-1)
				if mdt == -0 then mdt = 0 end
				mdt_val = mdt
				if (Gear_info['MDT'] + (include_dt_mdt and Gear_info['DT'] or 0)) < -51 then
					mdt_warn = true
				end
			end
			
			local bdt = (Gear_info['BDT'] + (include_dt_mdt and Gear_info['DT'] or 0)) * (-1)
			if bdt == -0 then bdt = 0 end
			
			local mdt_bdt_warn = mdt_warn or (Gear_info['BDT'] + (include_dt_mdt and Gear_info['DT'] or 0)) < -51
				if sections.block[7] and sections.block[7].text and sections.block[7].text[1] and sections.block[7].text[2] then
					safe_set_text(sections.block[7], 1, 'MDT/BDT')
					safe_set_text(sections.block[7], 2, tostring(mdt_val) .. '/' .. tostring(bdt))
					if mdt_bdt_warn then
						safe_set_color(sections.block[7], 2, 255, 255, 0, 0)
					else
						safe_set_color(sections.block[7], 2, 255, 255, 255, 255)
					end
				end
			
		else
		
			if sections.block[5] then sections.block[5]:delete() end
			if sections.block[6] then sections.block[6]:delete() end
			if sections.block[7] then sections.block[7]:delete() end
			if sections.block[8] then sections.block[8]:delete() end
			
		end
		
		----------------------------------------------- TP calc Stuff ------------------------------------------
		
			if settings.player.show_tp_Stuff == true then 
				Gear_TP = get_tp_per_hit()
				local tp_melee = (Gear_TP and Gear_TP.tp_per_hit_melee) or 0
				local tp_range = (Gear_TP and Gear_TP.tp_per_hit_range) or 0
				if not sections.block[9] then sections.block[9] = ImageBlock.New(10,'block','yellow', 'TP/swing', 00) end
				if not sections.block[10]  then sections.block[10] = ImageBlock.New(11,'block','yellow', 'X-hit', 00) end
				if sections.block[9] and sections.block[9].text and sections.block[9].text[2] then
					safe_set_text(sections.block[9], 2, tp_melee)
				end
				if sections.block[10] and sections.block[10].text and sections.block[10].text[2] then
					if tp_melee > 0 then
						safe_set_text(sections.block[10], 2, (math.ceil(10000/tp_melee)/10))
					else
						safe_set_text(sections.block[10], 2, 0)
					end
				end
			
				if tp_range > 0 then
					if not sections.block[16] then sections.block[16] = ImageBlock.New(17,'block', dark_green_color, 'TP/shot', 00) end
					if not sections.block[17] then sections.block[17] = ImageBlock.New(18,'block', dark_green_color, 'X-hit', 00) end
					if sections.block[16] and sections.block[16].text and sections.block[16].text[2] then
						safe_set_text(sections.block[16], 2, tp_range )
					end
					if sections.block[17] and sections.block[17].text and sections.block[17].text[2] then
						safe_set_text(sections.block[17], 2, (math.ceil(10000/tp_range)/10) )
					end
				else
					if sections.block[16] then sections.block[16]:delete() end
					if sections.block[17] then sections.block[17]:delete() end
				end
			
				if WSTP > 0 then
					if not sections.block[11] then sections.block[11] = ImageBlock.New(12,'block','yellow', 'aft WS', 00) end
					if sections.block[10] and sections.block[10].text and sections.block[10].text[1] then
						safe_set_text(sections.block[10], 1, 'for WS' )
					end
					if sections.block[10] and sections.block[10].text and sections.block[10].text[2] then
						safe_set_text(sections.block[10], 2, WSTP)
					end
					if sections.block[9] and sections.block[9].text and sections.block[9].text[2] then
						if tp_melee > 0 then
							safe_set_text(sections.block[9], 2, (math.ceil((10000 - (WSTP *10))/tp_melee)/10) )
						else
							safe_set_text(sections.block[9], 2, 0)
						end
					end
					if tp_range > 0 then
						if not sections.block[18] then sections.block[18] = ImageBlock.New(19,'block', dark_green_color, 'R.Aft WS', 00) end
						if sections.block[17] and sections.block[17].text and sections.block[17].text[1] then
							safe_set_text(sections.block[17], 1, 'R.for WS' )
						end
						if sections.block[17] and sections.block[17].text and sections.block[17].text[2] then
							safe_set_text(sections.block[17], 2, WSTP)
						end
						if sections.block[16] and sections.block[16].text and sections.block[16].text[2] then
							safe_set_text(sections.block[16], 2, (math.ceil((10000 - (WSTP *10))/tp_range)/10) )
						end
					end
				else
					if sections.block[10] and sections.block[10].text and sections.block[10].text[1] then
						safe_set_text(sections.block[10], 1, 'X-hit' )
					end
					if sections.block[11] then sections.block[11]:delete() end
					if sections.block[18] then sections.block[18]:delete() end
			end
		else
			if sections.block[9] then sections.block[9]:delete() end
			if sections.block[10] then sections.block[10]:delete() end
			if sections.block[11] then sections.block[11]:delete() end
			if sections.block[16] then sections.block[16]:delete() end
			if sections.block[17] then sections.block[17]:delete() end
			if sections.block[18] then sections.block[18]:delete() end
		end
		
		----------------------------------------------------- ACC Stuff ------------------------------------------
		
		if settings.player.show_acc_Stuff == true then
			local Total_acc = get_player_acc(Gear_info)
			if Total_acc.sub > 0 then
				if not sections.block[12] then
					sections.block[12] = ImageBlock.New(13,'block','yellow', 'Acc.1', 00)
				end
				if not sections.block[13] then
					sections.block[13] = ImageBlock.New(14,'block','yellow', 'Acc.2', 00)
				end
				safe_set_text(sections.block[12], 2, Total_acc.main)
				safe_set_text(sections.block[13], 2, Total_acc.sub)
			else
				if not sections.block[12] then
					sections.block[12] = ImageBlock.New(13,'block','yellow', 'Acc.', 00)
				end
				safe_set_text(sections.block[12], 2, Total_acc.main)
				if sections.block[13] then sections.block[13]:delete() end
			end
			if Total_acc.range > 0 then
				if not sections.block[19] then
					sections.block[19] = ImageBlock.New(20,'block', dark_green_color, 'R.Acc.', 00)
				end
				safe_set_text(sections.block[19], 2, Total_acc.range)
			elseif Total_acc.range == 0 and Total_acc.ammo > 0 then
				if not sections.block[19] then
					sections.block[19] = ImageBlock.New(20,'block', dark_green_color, 'R.Acc.', 00)
				end
				safe_set_text(sections.block[19], 2, Total_acc.ammo)
			else
				if sections.block[19] then sections.block[19]:delete() end
			end
		else
			if sections.block[12] then sections.block[12]:delete() end
			if sections.block[13] then sections.block[13]:delete() end
			if sections.block[20] then sections.block[20]:delete() end
		end
		
		----------------------------------------------------- ATT Stuff ------------------------------------------
		
		if settings.player.show_att_Stuff == true then
			local Total_att = get_player_att(Gear_info)
			if Total_att.sub > 0 then
				if not sections.block[14] then
					sections.block[14] = ImageBlock.New(15,'block','yellow', 'Att.1', 00)
				end
				if not sections.block[15] then
					sections.block[15] = ImageBlock.New(16,'block','yellow', 'Att.2', 00)
				end
				safe_set_text(sections.block[14], 2, Total_att.main)
				safe_set_text(sections.block[15], 2, Total_att.sub)
			else
				if not sections.block[14] then
					sections.block[14] = ImageBlock.New(15,'block','yellow', 'Att.', 00)
				end
				safe_set_text(sections.block[14], 2, Total_att.main)
				if sections.block[15] then sections.block[15]:delete() end
			end
			if Total_att.range > 0 then
				if not sections.block[21] then
					sections.block[21] = ImageBlock.New(22,'block', dark_green_color, 'R.Att.', 00)
				end
				safe_set_text(sections.block[21], 2, Total_att.range)
			elseif Total_att.range == 0 and Total_att.ammo > 0 then
				if not sections.block[21] then
					sections.block[21] = ImageBlock.New(22,'block', dark_green_color, 'R.Att.', 00)
				end
				safe_set_text(sections.block[21], 2, Total_att.ammo)
			else
				if sections.block[21] then sections.block[21]:delete() end
			end

			local da = Gear_info['Double Attack'] or 0
			local ta = (Gear_info['Triple Attack'] or 0) + (Gear_info['Tripple Attack'] or 0)
			local qa = Gear_info['Quadruple Attack'] or 0

			if settings.player.show_qa_da_ta == true then
				if not sections.block[30] then sections.block[30] = ImageBlock.New(31,'block', 'yellow', 'DA', 00) end
				if not sections.block[31] then sections.block[31] = ImageBlock.New(32,'block', 'yellow', 'TA', 00) end
				if not sections.block[32] then sections.block[32] = ImageBlock.New(33,'block', 'yellow', 'QA', 00) end

				safe_set_text(sections.block[30], 2, da)
				safe_set_text(sections.block[31], 2, ta)
				safe_set_text(sections.block[32], 2, qa)
			else
				if sections.block[30] then sections.block[30]:delete() end
				if sections.block[31] then sections.block[31]:delete() end
				if sections.block[32] then sections.block[32]:delete() end
			end

			if sections.block[29] then sections.block[29]:delete() end
		else
			if sections.block[14] then sections.block[14]:delete() end
			if sections.block[15] then sections.block[15]:delete() end
			if sections.block[21] then sections.block[21]:delete() end
			if sections.block[30] then sections.block[30]:delete() end
			if sections.block[31] then sections.block[31]:delete() end
			if sections.block[32] then sections.block[32]:delete() end
			if sections.block[29] then sections.block[29]:delete() end
		end
		
		------------------------------------------- Evasion ------------------------------------------------------
		
		local Total_eva = get_player_evasion(Gear_info)
		if settings.player.show_Evasion == true then
			if not sections.block[22] then sections.block[22] = ImageBlock.New(23,'block','purple', 'Eva.', '') end
			safe_set_text(sections.block[22], 2, tostring(Total_eva))
		else
			if sections.block[22] then sections.block[22]:delete() end
		end
		
		------------------------------------------- Defence ------------------------------------------------------
		
		local Total_def = get_player_defence(Gear_info)
		if settings.player.show_Defence == true then
			if not sections.block[23] then sections.block[23] = ImageBlock.New(24,'block','purple', 'Def.', '') end
			safe_set_text(sections.block[23], 2, tostring(Total_def))
		else
			if sections.block[23] then sections.block[23]:delete() end
		end
		
		----------------------------------------------------------- DW stuff ----------------------------------------------
		DW_needed = dual_wield_needed()
		if settings.player.show_DW_Stuff == true then
			
			if player.equipment.sub.category == 'Weapon' then 
				if player.equipment.sub.damage then
					DW = true
					
					if not sections.block[24] then sections.block[24] = ImageBlock.New(25,'block','yellow', 'DW/Need', 00) end
					safe_set_text(sections.block[24], 1, 'DW/Need')
					local dw_value = Gear_info['Dual Wield'] or 0
					local dw_needed_value = DW_needed + manual_dw_needed
					safe_set_text(sections.block[24], 2, tostring(dw_value) .. '/' .. tostring(dw_needed_value))
					if dw_needed_value < 0 then
						safe_set_color(sections.block[24], 2, 255, 255, 0, 0)
					else
						safe_set_color(sections.block[24], 2, 255, 255, 255, 255)
					end
					if sections.block[25] then sections.block[25]:delete() end
				else
					if sections.block[24] then sections.block[24]:delete() end
					if sections.block[25] then sections.block[25]:delete() end
				end
			else
				if sections.block[24] then sections.block[24]:delete() end
				if sections.block[25] then sections.block[25]:delete() end
			end
		else
			if sections.block[24] then sections.block[24]:delete() end
			if sections.block[25] then sections.block[25]:delete() end
		end
		
		----------------------------------------------------------- MA stuff ----------------------------------------------
		if settings.player.show_MA_Stuff == true then
			local total_ma , MA_needed = martial_arts_needed()
			
			if player.equipment.main.skill == "Hand-to-Hand" or player.equipment.main.en == '' then
			
				if not sections.block[26] then sections.block[26] = ImageBlock.New(27,'block','pink', 'MA', 00) end
				if not sections.block[27] then sections.block[27] = ImageBlock.New(28,'block','pink', 'Needed', 00) end
				
				safe_set_text(sections.block[26], 2, total_ma)
				safe_set_text(sections.block[27], 2, MA_needed)
				if (MA_needed) < 0 then
					safe_set_color(sections.block[27], 2, 255, 255, 0, 0)
				else
					safe_set_color(sections.block[27], 2, 255, 255, 255, 255)
				end
			else
				if sections.block[26] then sections.block[26]:delete() end
				if sections.block[27] then sections.block[27]:delete() end
			end
		else
			if sections.block[26] then sections.block[26]:delete() end
			if sections.block[27] then sections.block[27]:delete() end
		end
			
		----------------------------------------------------------- Store TP stuff ----------------------------------------------
		local stp_total = Gear_info['Store TP'] + Buffs_inform['Store TP']
		local ta_value = (Gear_info['Triple Attack'] or 0) + (Gear_info['Tripple Attack'] or 0)
		local qa_value = (Gear_info['Quadruple Attack'] or 0)
		local dta_for_stp = (Gear_info['Double Attack'] or 0)
			+ (ta_value * 2)
			+ (qa_value * 3)
		if settings.player.show_STP == true then
			if not sections.block[28] then sections.block[28] = ImageBlock.New(29,'block', 'yellow', 'STP/DTA', 00) end
			safe_set_text(sections.block[28], 1, 'STP/DTA')
			safe_set_text(sections.block[28], 2, tostring(stp_total) .. '/' .. tostring(dta_for_stp))
		else
			if sections.block[28] then sections.block[28]:delete() end
		end		

		----------------------------------------------------------- Extra stats ----------------------------------------------
		local sc_bonus = Gear_info['Skillchain Bonus'] or 0
		local sc_damage = Gear_info['Skillchain Damage'] or 0
		local player_stats = player.stats or {}
		local base_mab = player_stats['Magic Atk. Bonus'] or player_stats['Magic Attack Bonus']
			or player_stats.MAB or player_stats.mab or 0
		local mab = (Gear_info['Magic Atk. Bonus'] or 0) + (Buffs_inform['Magic Atk. Bonus'] or 0) + base_mab
		local mbd = (Gear_info['Magic Burst Damage'] or 0) + (Gear_info['Magic Burst Bonus'] or 0)
		local mbd2 = Gear_info['Magic Burst Damage II'] or 0
		local pdl = Gear_info['PDL'] or 0
		local sird = Gear_info['SIRD'] or 0
		local int_total = (Gear_info['INT'] or 0) + (Buffs_inform['INT'] or 0) + ((player.stats and player.stats.INT) or 0)
		local str_total = (Gear_info['STR'] or 0) + (Buffs_inform['STR'] or 0) + ((player.stats and player.stats.STR) or 0)
		local dex_total = (Gear_info['DEX'] or 0) + (Buffs_inform['DEX'] or 0) + ((player.stats and player.stats.DEX) or 0)
		local vit_total = (Gear_info['VIT'] or 0) + (Buffs_inform['VIT'] or 0) + ((player.stats and player.stats.VIT) or 0)
		local agi_total = (Gear_info['AGI'] or 0) + (Buffs_inform['AGI'] or 0) + ((player.stats and player.stats.AGI) or 0)
		local mnd_total = (Gear_info['MND'] or 0) + (Buffs_inform['MND'] or 0) + ((player.stats and player.stats.MND) or 0)
		local chr_total = (Gear_info['CHR'] or 0) + (Buffs_inform['CHR'] or 0) + ((player.stats and player.stats.CHR) or 0)
		local base_macc = player_stats['Magic Accuracy'] or player_stats.MACC or player_stats.macc or 0
		local macc_total = (Gear_info['Magic Accuracy'] or 0) + (Buffs_inform['Magic Accuracy'] or 0) + base_macc
		local regen_total = (Gear_info['Regen'] or 0) + (Buffs_inform['Regen'] or 0)
		local regain_total = (Gear_info['Regain'] or 0) + (Buffs_inform['Regain'] or 0)
		local refresh_total = (Gear_info['Refresh'] or 0) + (Buffs_inform['Refresh'] or 0)
		local parry_total = (Gear_info['Parrying skill'] or 0) + (Buffs_inform['Parrying skill'] or 0)
			+ ((player_base_skills and player_base_skills.parrying) or 0)
		local enmity_total = (Gear_info['Enmity'] or 0) + (Buffs_inform['Enmity'] or 0)
		local crit_rate_total = (Gear_info['Critical hit rate'] or 0) + (Buffs_inform['Critical hit rate'] or 0)
		local crit_damage_total = (Gear_info['Critical hit damage'] or 0) + (Buffs_inform['Critical hit damage'] or 0)
		local subtle_blow_total = (Gear_info['Subtle Blow'] or 0) + (Buffs_inform['Subtle Blow'] or 0)
		local subtle_blow2_total = (Gear_info['Subtle Blow II'] or 0) + (Buffs_inform['Subtle Blow II'] or 0)
		local base_mdef = player_stats['Magic Def. Bonus'] or player_stats.MDB or player_stats.mdb or 0
		local base_meva = player_stats['Magic Evasion'] or player_stats.MEVA or player_stats.meva or 0
		local magic_damage_total = (Gear_info['Magic Damage'] or 0) + (Buffs_inform['Magic Damage'] or 0)
		local magic_def_bonus_total = (Gear_info['Magic Def. Bonus'] or 0) + (Buffs_inform['Magic Def. Bonus'] or 0) + base_mdef
		local magic_eva_total = (Gear_info['Magic Evasion'] or 0) + (Buffs_inform['Magic Evasion'] or 0) + base_meva
		local counter_total = (Gear_info['Counter'] or 0) + (Buffs_inform['Counter'] or 0)
		local conserve_mp_total = (Gear_info['Conserve MP'] or 0) + (Buffs_inform['Conserve MP'] or 0)
		local function sum_stats(tbl, keys)
			local total = 0
			if type(tbl) ~= 'table' then
				return total
			end
			for _, key in ipairs(keys) do
				if tbl[key] then
					total = total + tbl[key]
				end
			end
			return total
		end
		local function sum_from_equip(equip, keys)
			local total = 0
			if type(equip) ~= 'table' then
				return total
			end
			for _, item in pairs(equip) do
				if type(item) == 'table' then
					total = total + sum_stats(item, keys)
				end
			end
			return total
		end
		-- New stats should always include base + aug values, regardless of aug-only mode.
		local th_total = sum_from_equip(current_equip, {'Treasure Hunter','"Treasure Hunter"'}) + (Buffs_inform['Treasure Hunter'] or 0)
		local fast_cast_total = sum_from_equip(current_equip, {'Fast Cast','"Fast Cast"'}) + (Buffs_inform['Fast Cast'] or 0)
		local cure_pot_total = sum_from_equip(current_equip, {'Cure potency','Cure Potency','"Cure Potency"'})
			+ sum_stats(Buffs_inform, {'Cure potency','Cure Potency'})
		local cure_pot2_total = sum_from_equip(current_equip, {'Cure potency II','Cure Potency II','"Cure Potency II"'})
			+ sum_stats(Buffs_inform, {'Cure potency II','Cure Potency II'})
		local enemy_crit_total = sum_from_equip(current_equip, {'Enemy critical hit rate','Enemy crit. hit rate','Enemy crit hit rate','"Enemy critical hit rate"'})
			+ (Buffs_inform['Enemy critical hit rate'] or 0)
		local waltz_total = sum_from_equip(current_equip, {'Waltz','Waltz potency','"Waltz potency"'})
			+ sum_stats(Buffs_inform, {'Waltz','Waltz potency'})
		local block_rate_total = sum_from_equip(current_equip, {'Block rate','Chance of successful block','Shield Block Rate','"Shield Block Rate"'})
			+ (Buffs_inform['Block rate'] or 0)
		local zanshin_total = sum_from_equip(current_equip, {'Zanshin'}) + (Buffs_inform['Zanshin'] or 0)
		local tpb_total = sum_from_equip(current_equip, {'TP Bonus','"TP Bonus"'}) + (Buffs_inform['TP Bonus'] or 0)
		local killer_total = sum_from_equip(current_equip, {'Killer','Killer effects','"Killer effects"'})
			+ sum_stats(Buffs_inform, {'Killer','Killer effects'})
		local samba_total = sum_from_equip(current_equip, {'Samba','Samba duration','"Samba duration"'}) + (Buffs_inform['Samba'] or 0)
		local base_hms = (player.skills and player.skills.healing_magic) or (player_base_skills and player_base_skills.healing_magic) or 0
		local hms_total = sum_from_equip(current_equip, {'Healing Magic skill'}) + (Buffs_inform['Healing Magic skill'] or 0) + base_hms
		local phalanx_total = sum_from_equip(current_equip, {'Phalanx'}) + (Buffs_inform['Phalanx'] or 0)
		local qc_total = sum_from_equip(current_equip, {'Quick Cast','"Quick Cast"'}) + (Buffs_inform['Quick Cast'] or 0)
		local cst_total = sum_from_equip(current_equip, {'Cure spellcasting time','Cure Spellcasting Time','"Cure Spellcasting Time"'}) + (Buffs_inform['Cure spellcasting time'] or 0)
		local hmct_total = sum_from_equip(current_equip, {'Healing magic casting time','Healing Magic Casting Time','"Healing Magic Casting Time"'}) + (Buffs_inform['Healing magic casting time'] or 0)
		local snapshot_total = sum_from_equip(current_equip, {'Snapshot'}) + (Buffs_inform['Snapshot'] or 0)
		local rapid_shot_total = sum_from_equip(current_equip, {'Rapid Shot','Rapid shot'}) + (Buffs_inform['Rapid Shot'] or 0)
		local emct_total = sum_from_equip(current_equip, {'Elemental magic casting time','Elemental Magic Casting Time'}) + (Buffs_inform['Elemental magic casting time'] or 0)
		local inq_total = sum_from_equip(current_equip, {'Inquartata'}) + (Buffs_inform['Inquartata'] or 0)
		local emed_total = sum_from_equip(current_equip, {'Enhancing magic effect duration','Enhancing Magic Effect Duration','Enh. Mag. Eff. Dur.'}) + sum_stats(Buffs_inform, {'Enhancing magic effect duration','Enhancing Magic Effect Duration'})
		local steal_total = sum_from_equip(current_equip, {'Steal'}) + (Buffs_inform['Steal'] or 0)
		local sneak_total = sum_from_equip(current_equip, {'Sneak Attack'}) + (Buffs_inform['Sneak Attack'] or 0)
		local trick_total = sum_from_equip(current_equip, {'Trick Attack'}) + (Buffs_inform['Trick Attack'] or 0)
		local all_songs_total = sum_from_equip(current_equip, {'All songs'}) + (Buffs_inform['All songs'] or 0)
		local sed_total = sum_from_equip(current_equip, {'Song effect duration','Song Effect Duration'}) + sum_stats(Buffs_inform, {'Song effect duration','Song Effect Duration'})
		local sst_total = sum_from_equip(current_equip, {'Song spellcasting time'}) + (Buffs_inform['Song spellcasting time'] or 0)
		local pr_total = sum_from_equip(current_equip, {'Pet: Regen'}) + (Buffs_inform['Pet: Regen'] or 0)
		local petdt_total = sum_from_equip(current_equip, {'Pet: Damage Taken'}) + (Buffs_inform['Pet: Damage Taken'] or 0)
		local petpdt_total = sum_from_equip(current_equip, {'Pet: Physical Damage Taken'}) + (Buffs_inform['Pet: Physical Damage Taken'] or 0)
		local petmdt_total = sum_from_equip(current_equip, {'Pet: Magic Damage Taken'}) + (Buffs_inform['Pet: Magic Damage Taken'] or 0)
		local ied_total = sum_from_equip(current_equip, {'Indicolure effect duration','Indicolure Effect Duration'}) + sum_stats(Buffs_inform, {'Indicolure effect duration','Indicolure Effect Duration'})
		local pethaste_total = sum_from_equip(current_equip, {'Pet: Haste'}) + (Buffs_inform['Pet: Haste'] or 0)
		local bpd_total = sum_from_equip(current_equip, {'Blood Pact Delay'}) + (Buffs_inform['Blood Pact Delay'] or 0)
		local bpd2_total = sum_from_equip(current_equip, {'Blood Pact Delay II'}) + (Buffs_inform['Blood Pact Delay II'] or 0)
		local bpdmg_total = sum_from_equip(current_equip, {'Blood Pact Damage'}) + (Buffs_inform['Blood Pact Damage'] or 0)
		local apc_total = sum_from_equip(current_equip, {'Avatar Perpetuation Cost'}) + (Buffs_inform['Avatar Perpetuation Cost'] or 0)
		local pmab_total = sum_from_equip(current_equip, {'Pet: Magic Atk. Bonus'}) + (Buffs_inform['Pet: Magic Atk. Bonus'] or 0)
		local patt_total = sum_from_equip(current_equip, {'Pet: Attack'}) + (Buffs_inform['Pet: Attack'] or 0)
		local pda_total = sum_from_equip(current_equip, {'Pet: Double Attack'}) + (Buffs_inform['Pet: Double Attack'] or 0)
		local pacc_total = sum_from_equip(current_equip, {'Pet: Accuracy'}) + (Buffs_inform['Pet: Accuracy'] or 0)
		local pmacc_total = sum_from_equip(current_equip, {'Pet: Magic Accuracy'}) + (Buffs_inform['Pet: Magic Accuracy'] or 0)
		local sms_total = sum_from_equip(current_equip, {'Summoning Magic skill'}) + (Buffs_inform['Summoning Magic skill'] or 0)
		local pbpd_total = sum_from_equip(current_equip, {'Pet: Blood Pact Damage'}) + (Buffs_inform['Pet: Blood Pact Damage'] or 0)
		local pmdmg_total = sum_from_equip(current_equip, {'Pet: Magic Damage'}) + (Buffs_inform['Pet: Magic Damage'] or 0)
		local cursna_total = sum_from_equip(current_equip, {'Cursna'}) + (Buffs_inform['Cursna'] or 0)
		local extra_color = 'blue'
		local extra2_color = 'orange'
		local extra3_color = 'pink'
		local extra4_color = 'grey'
		local dijon_color = 'gold-dark'
		local stats_color = 'blue'
		local extra2_job_ok = (extra2_jobs[main_job] == true) or (settings.player.extra32_override == true)
		local dd_melee_job_ok = dd_melee_jobs[main_job] == true
		local extra5_job_ok = extra5_jobs[main_job] == true
		if settings.player.extra_all_override == true then
			extra2_job_ok = true
			dd_melee_job_ok = true
			extra5_job_ok = true
		end

		if (settings.player.show_sc_bonus == true or settings.player.show_sc_damage == true) and dd_melee_job_ok == true then
			if not sections.block[33] then sections.block[33] = ImageBlock.New(34,'block', 'yellow', 'SCB/SCD', 00) end
			safe_set_text(sections.block[33], 2, tostring(sc_bonus) .. '/' .. tostring(sc_damage))
		else
			if sections.block[33] then sections.block[33]:delete() end
		end

		if settings.player.show_int == true and extra2_job_ok == true then
			if sections.block[34] and sections.block[34].text and sections.block[34].text[1] and sections.block[34].text[1].text == 'INT' then sections.block[34]:delete() end
			if sections.block[114] and sections.block[114].order ~= 114 then sections.block[114]:delete() end
			if sections.block[114] and sections.block[114].text and sections.block[114].text[1] and sections.block[114].text[1].text ~= 'INT' then sections.block[114]:delete() end
			if not sections.block[114] then sections.block[114] = ImageBlock.New(114,'block', extra_color, 'INT', 00) end
			safe_set_text(sections.block[114], 2, int_total)
		else
			if sections.block[34] then sections.block[34]:delete() end
			if sections.block[114] then sections.block[114]:delete() end
		end

		if settings.player.show_mab == true and extra2_job_ok == true then
			if sections.block[35] and sections.block[35].text and sections.block[35].text[1] and sections.block[35].text[1].text == 'MAB' then sections.block[35]:delete() end
			if sections.block[117] and sections.block[117].order ~= 117 then sections.block[117]:delete() end
			if sections.block[117] and sections.block[117].text and sections.block[117].text[1] and sections.block[117].text[1].text ~= 'MAB' then sections.block[117]:delete() end
			if not sections.block[117] then sections.block[117] = ImageBlock.New(117,'block', extra_color, 'MAB', 00) end
			safe_set_text(sections.block[117], 2, mab)
		else
			if sections.block[35] then sections.block[35]:delete() end
			if sections.block[117] then sections.block[117]:delete() end
		end

		if (settings.player.show_mbd == true or settings.player.show_mbd2 == true) and extra2_job_ok == true then
			if sections.block[36] and sections.block[36].text and sections.block[36].text[1] and sections.block[36].text[1].text == 'MBD/MBD2' then sections.block[36]:delete() end
			if sections.block[118] and sections.block[118].order ~= 118 then sections.block[118]:delete() end
			if sections.block[118] and sections.block[118].text and sections.block[118].text[1] and sections.block[118].text[1].text ~= 'MBD/MBD2' then sections.block[118]:delete() end
			if not sections.block[118] then sections.block[118] = ImageBlock.New(118,'block', extra_color, 'MBD/MBD2', 00) end
			safe_set_text(sections.block[118], 2, tostring(mbd) .. '/' .. tostring(mbd2))
		else
			if sections.block[36] then sections.block[36]:delete() end
			if sections.block[118] then sections.block[118]:delete() end
		end

		if settings.player.show_macc == true and extra2_job_ok == true then
			if sections.block[37] and sections.block[37].text and sections.block[37].text[1] and sections.block[37].text[1].text == 'M.Acc' then sections.block[37]:delete() end
			if sections.block[115] and sections.block[115].order ~= 115 then sections.block[115]:delete() end
			if sections.block[115] and sections.block[115].text and sections.block[115].text[1] and sections.block[115].text[1].text ~= 'M.Acc' then sections.block[115]:delete() end
			if not sections.block[115] then sections.block[115] = ImageBlock.New(115,'block', extra_color, 'M.Acc', 00) end
			safe_set_text(sections.block[115], 2, macc_total)
		else
			if sections.block[37] then sections.block[37]:delete() end
			if sections.block[115] then sections.block[115]:delete() end
		end

		if settings.player.show_pdl == true and dd_melee_job_ok == true then
			if not sections.block[38] then sections.block[38] = ImageBlock.New(39,'block', 'yellow', 'PDL', 00) end
			safe_set_text(sections.block[38], 2, pdl)
		else
			if sections.block[38] then sections.block[38]:delete() end
		end

		if settings.player.show_sird == true and extra5_job_ok == true then
			if not sections.block[39] then sections.block[39] = ImageBlock.New(40,'block', extra4_color, 'SIRD', 00) end
			safe_set_text(sections.block[39], 2, sird)
		else
			if sections.block[39] then sections.block[39]:delete() end
		end

		if settings.player.show_regen == true and extra5_job_ok == true then
			if not sections.block[40] then sections.block[40] = ImageBlock.New(41,'block', extra4_color, 'Regen', 00) end
			safe_set_text(sections.block[40], 2, regen_total)
		else
			if sections.block[40] then sections.block[40]:delete() end
		end

		if settings.player.show_regain == true and extra5_job_ok == true then
			if not sections.block[41] then sections.block[41] = ImageBlock.New(42,'block', extra4_color, 'Regain', 00) end
			safe_set_text(sections.block[41], 2, regain_total)
		else
			if sections.block[41] then sections.block[41]:delete() end
		end

		if settings.player.show_refresh == true and extra5_job_ok == true then
			if not sections.block[42] then sections.block[42] = ImageBlock.New(43,'block', extra4_color, 'Refresh', 00) end
			safe_set_text(sections.block[42], 2, refresh_total)
		else
			if sections.block[42] then sections.block[42]:delete() end
		end

		if settings.player.show_parry == true and extra5_job_ok == true then
			if sections.block[43] then sections.block[43]:delete() end
			if sections.block[80] and sections.block[80].order ~= 82 then sections.block[80]:delete() end
			if not sections.block[80] then sections.block[80] = ImageBlock.New(82,'block', 'purple', 'Parry', 00) end
			safe_set_text(sections.block[80], 2, parry_total)
		else
			if sections.block[43] then sections.block[43]:delete() end
			if sections.block[80] then sections.block[80]:delete() end
		end

		if settings.player.show_enmity == true and extra5_job_ok == true then
			if not sections.block[44] then sections.block[44] = ImageBlock.New(45,'block', extra4_color, 'Enmity', 00) end
			safe_set_text(sections.block[44], 2, enmity_total)
		else
			if sections.block[44] then sections.block[44]:delete() end
		end

		if (settings.player.show_crit_rate == true or settings.player.show_crit_damage == true) and dd_melee_job_ok == true then
			if not sections.block[45] then sections.block[45] = ImageBlock.New(46,'block', extra3_color, 'CRIT/CRTD', 00) end
			safe_set_text(sections.block[45], 1, 'CRIT/CRTD')
			safe_set_text(sections.block[45], 2, tostring(crit_rate_total) .. '/' .. tostring(crit_damage_total))
		else
			if sections.block[45] then sections.block[45]:delete() end
		end

		if (settings.player.show_subtle_blow == true or settings.player.show_subtle_blow_ii == true) and dd_melee_job_ok == true then
			if not sections.block[46] then sections.block[46] = ImageBlock.New(47,'block', extra3_color, 'SB/SB2', 00) end
			safe_set_text(sections.block[46], 1, 'SB/SB2')
			safe_set_text(sections.block[46], 2, tostring(subtle_blow_total) .. '/' .. tostring(subtle_blow2_total))
		else
			if sections.block[46] then sections.block[46]:delete() end
		end

		if sections.block[47] then sections.block[47]:delete() end
		if sections.block[48] then sections.block[48]:delete() end

		if settings.player.show_magic_damage == true and extra2_job_ok == true then
			if sections.block[49] and sections.block[49].text and sections.block[49].text[1] and sections.block[49].text[1].text == 'M.Dmg' then sections.block[49]:delete() end
			if sections.block[116] and sections.block[116].order ~= 116 then sections.block[116]:delete() end
			if sections.block[116] and sections.block[116].text and sections.block[116].text[1] and sections.block[116].text[1].text ~= 'M.Dmg' then sections.block[116]:delete() end
			if not sections.block[116] then sections.block[116] = ImageBlock.New(116,'block', extra_color, 'M.Dmg', 00) end
			safe_set_text(sections.block[116], 2, magic_damage_total)
		else
			if sections.block[49] then sections.block[49]:delete() end
			if sections.block[116] then sections.block[116]:delete() end
		end

		if settings.player.show_magic_def_bonus == true and extra5_job_ok == true then
			if not sections.block[50] then sections.block[50] = ImageBlock.New(51,'block', 'purple', 'M.Def.Bn', 00) end
			safe_set_text(sections.block[50], 2, magic_def_bonus_total)
		else
			if sections.block[50] then sections.block[50]:delete() end
		end

		if settings.player.show_magic_evasion == true and extra5_job_ok == true then
			if not sections.block[51] then sections.block[51] = ImageBlock.New(52,'block', 'purple', 'M.Eva', 00) end
			safe_set_text(sections.block[51], 2, magic_eva_total)
		else
			if sections.block[51] then sections.block[51]:delete() end
		end

		if settings.player.show_counter == true then
			if not sections.block[52] then sections.block[52] = ImageBlock.New(53,'block', extra3_color, 'Counter', 00) end
			safe_set_text(sections.block[52], 2, counter_total)
		else
			if sections.block[52] then sections.block[52]:delete() end
		end

		if settings.player.show_conserve_mp == true then
			if not sections.block[53] then sections.block[53] = ImageBlock.New(54,'block', extra3_color, 'C.MP', 00) end
			safe_set_text(sections.block[53], 2, conserve_mp_total)
		else
			if sections.block[53] then sections.block[53]:delete() end
		end

		if settings.player.show_stats == true then
			if not sections.block[54] then sections.block[54] = ImageBlock.New(55,'block', stats_color, 'STR', 00) end
			if not sections.block[55] then sections.block[55] = ImageBlock.New(56,'block', stats_color, 'DEX', 00) end
			if not sections.block[56] then sections.block[56] = ImageBlock.New(57,'block', stats_color, 'VIT', 00) end
			if not sections.block[57] then sections.block[57] = ImageBlock.New(58,'block', stats_color, 'AGI', 00) end
			if not sections.block[58] then sections.block[58] = ImageBlock.New(59,'block', stats_color, 'INT', 00) end
			if not sections.block[59] then sections.block[59] = ImageBlock.New(60,'block', stats_color, 'MND', 00) end
			if not sections.block[60] then sections.block[60] = ImageBlock.New(61,'block', stats_color, 'CHR', 00) end
			safe_set_text(sections.block[54], 2, str_total)
			safe_set_text(sections.block[55], 2, dex_total)
			safe_set_text(sections.block[56], 2, vit_total)
			safe_set_text(sections.block[57], 2, agi_total)
			safe_set_text(sections.block[58], 2, int_total)
			safe_set_text(sections.block[59], 2, mnd_total)
			safe_set_text(sections.block[60], 2, chr_total)
		else
			if sections.block[54] then sections.block[54]:delete() end
			if sections.block[55] then sections.block[55]:delete() end
			if sections.block[56] then sections.block[56]:delete() end
			if sections.block[57] then sections.block[57]:delete() end
			if sections.block[58] then sections.block[58]:delete() end
			if sections.block[59] then sections.block[59]:delete() end
			if sections.block[60] then sections.block[60]:delete() end
		end

		if settings.player.show_th == true then
			if sections.block[61] then sections.block[61]:delete() end
			if sections.block[82] and sections.block[82].order ~= 83 then sections.block[82]:delete() end
			if not sections.block[82] then sections.block[82] = ImageBlock.New(83,'block', 'brown', 'TH', 00) end
			safe_set_text(sections.block[82], 2, th_total)
		else
			if sections.block[61] then sections.block[61]:delete() end
			if sections.block[82] then sections.block[82]:delete() end
		end

		if settings.player.show_fc == true then
			if sections.block[74] and sections.block[74].order ~= 75 then sections.block[74]:delete() end
			if not sections.block[74] then sections.block[74] = ImageBlock.New(75,'block', dark_green_color, 'FC', 00) end
			safe_set_text(sections.block[74], 2, fast_cast_total)
		else
			if sections.block[74] then sections.block[74]:delete() end
		end
		if sections.block[62] then sections.block[62]:delete() end

		if settings.player.show_cp == true or settings.player.show_cp2 == true then
			if sections.block[63] then sections.block[63]:delete() end
			if sections.block[119] and sections.block[119].order ~= 119 then sections.block[119]:delete() end
			if sections.block[119] and sections.block[119].text and sections.block[119].text[1] and sections.block[119].text[1].text ~= 'CP/CP2' then sections.block[119]:delete() end
			if not sections.block[119] then sections.block[119] = ImageBlock.New(119,'block', dark_green_color, 'CP/CP2', 00) end
			safe_set_text(sections.block[119], 1, 'CP/CP2')
			safe_set_text(sections.block[119], 2, tostring(cure_pot_total) .. '/' .. tostring(cure_pot2_total))
		else
			if sections.block[63] then sections.block[63]:delete() end
			if sections.block[119] then sections.block[119]:delete() end
		end

		if settings.player.show_echr == true then
			if sections.block[65] and sections.block[65].order ~= 66 then sections.block[65]:delete() end
			if sections.block[65] and sections.block[65].text and sections.block[65].text[1] and sections.block[65].text[1].text ~= 'E.Crit' then sections.block[65]:delete() end
			if not sections.block[65] then sections.block[65] = ImageBlock.New(66,'block', 'purple', 'E.Crit', 00) end
			safe_set_text(sections.block[65], 2, enemy_crit_total)
		else
			if sections.block[65] then sections.block[65]:delete() end
		end

		if settings.player.show_br == true then
			if sections.block[66] and sections.block[66].order ~= 67 then sections.block[66]:delete() end
			if sections.block[66] and sections.block[66].text and sections.block[66].text[1] and sections.block[66].text[1].text ~= 'B.Rate' then sections.block[66]:delete() end
			if not sections.block[66] then sections.block[66] = ImageBlock.New(67,'block', 'purple', 'B.Rate', 00) end
			safe_set_text(sections.block[66], 2, block_rate_total)
		else
			if sections.block[66] then sections.block[66]:delete() end
		end

		if settings.player.show_waltz == true then
			if sections.block[67] and sections.block[67].order ~= 68 then sections.block[67]:delete() end
			if sections.block[67] and sections.block[67].text and sections.block[67].text[1] and sections.block[67].text[1].text ~= 'Waltz' then sections.block[67]:delete() end
			if not sections.block[67] then sections.block[67] = ImageBlock.New(68,'block', 'brown', 'Waltz', 00) end
			safe_set_text(sections.block[67], 2, waltz_total)
		else
			if sections.block[67] then sections.block[67]:delete() end
		end

		if settings.player.show_samba == true then
			if sections.block[68] and sections.block[68].order ~= 69 then sections.block[68]:delete() end
			if sections.block[68] and sections.block[68].text and sections.block[68].text[1] and sections.block[68].text[1].text ~= 'Samba' then sections.block[68]:delete() end
			if not sections.block[68] then sections.block[68] = ImageBlock.New(69,'block', 'brown', 'Samba', 00) end
			safe_set_text(sections.block[68], 2, samba_total)
		else
			if sections.block[68] then sections.block[68]:delete() end
		end

		if settings.player.show_zanshin == true then
			if sections.block[69] and sections.block[69].order ~= 70 then sections.block[69]:delete() end
			if sections.block[69] and sections.block[69].text and sections.block[69].text[1] and sections.block[69].text[1].text ~= 'Zanshin' then sections.block[69]:delete() end
			if not sections.block[69] then sections.block[69] = ImageBlock.New(70,'block', 'yellow', 'Zanshin', 00) end
			safe_set_text(sections.block[69], 2, zanshin_total)
		else
			if sections.block[69] then sections.block[69]:delete() end
		end

		if settings.player.show_tpb == true then
			if sections.block[70] and sections.block[70].order ~= 71 then sections.block[70]:delete() end
			if sections.block[70] and sections.block[70].text and sections.block[70].text[1] and sections.block[70].text[1].text ~= 'TPB' then sections.block[70]:delete() end
			if not sections.block[70] then sections.block[70] = ImageBlock.New(71,'block', 'yellow', 'TPB', 00) end
			safe_set_text(sections.block[70], 2, tpb_total)
		else
			if sections.block[70] then sections.block[70]:delete() end
		end

		if settings.player.show_killer == true then
			if sections.block[71] and sections.block[71].order ~= 72 then sections.block[71]:delete() end
			if sections.block[71] and sections.block[71].text and sections.block[71].text[1] and sections.block[71].text[1].text ~= 'Killer' then sections.block[71]:delete() end
			if not sections.block[71] then sections.block[71] = ImageBlock.New(72,'block', 'yellow', 'Killer', 00) end
			safe_set_text(sections.block[71], 2, killer_total)
		else
			if sections.block[71] then sections.block[71]:delete() end
		end

		if settings.player.show_hms == true then
			if sections.block[64] then sections.block[64]:delete() end
			if sections.block[106] then sections.block[106]:delete() end
			if sections.block[120] and sections.block[120].order ~= 120 then sections.block[120]:delete() end
			if sections.block[120] and sections.block[120].text and sections.block[120].text[1] and sections.block[120].text[1].text ~= 'HMS' then sections.block[120]:delete() end
			if not sections.block[120] then sections.block[120] = ImageBlock.New(120,'block', dark_green_color, 'HMS', 00) end
			safe_set_text(sections.block[120], 2, hms_total)
		else
			if sections.block[64] then sections.block[64]:delete() end
			if sections.block[106] then sections.block[106]:delete() end
			if sections.block[120] then sections.block[120]:delete() end
		end

		if settings.player.show_phalanx == true then
			if sections.block[73] then sections.block[73]:delete() end
			if sections.block[107] and sections.block[107].text and sections.block[107].text[1] and sections.block[107].text[1].text == 'Phalanx' then sections.block[107]:delete() end
			if sections.block[112] and sections.block[112].order ~= 112 then sections.block[112]:delete() end
			if sections.block[112] and sections.block[112].text and sections.block[112].text[1] and sections.block[112].text[1].text ~= 'Phalanx' then sections.block[112]:delete() end
			if not sections.block[112] then sections.block[112] = ImageBlock.New(112,'block', dark_green_color, 'Phalanx', 00) end
			safe_set_text(sections.block[112], 2, phalanx_total)
		else
			if sections.block[73] then sections.block[73]:delete() end
			if sections.block[112] then sections.block[112]:delete() end
		end

		if settings.player.show_qc == true then
			if sections.block[75] and sections.block[75].order ~= 76 then sections.block[75]:delete() end
			if not sections.block[75] then sections.block[75] = ImageBlock.New(76,'block', dark_green_color, 'QC', 00) end
			safe_set_text(sections.block[75], 2, qc_total)
		else
			if sections.block[75] then sections.block[75]:delete() end
		end

		if settings.player.show_cst == true or settings.player.show_hmct == true then
			if sections.block[76] and sections.block[76].order ~= 77 then sections.block[76]:delete() end
			if not sections.block[76] then sections.block[76] = ImageBlock.New(77,'block', dark_green_color, 'CST/HMCT', 00) end
			safe_set_text(sections.block[76], 1, 'CST/HMCT')
			safe_set_text(sections.block[76], 2, tostring(cst_total) .. '/' .. tostring(hmct_total))
		else
			if sections.block[76] then sections.block[76]:delete() end
		end

		if settings.player.show_snapshot == true or settings.player.show_rapid_shot == true then
			if sections.block[78] and sections.block[78].order ~= 79 then sections.block[78]:delete() end
			if not sections.block[78] then sections.block[78] = ImageBlock.New(79,'block', 'yellow', 'Snap/Rsht', 00) end
			safe_set_text(sections.block[78], 1, 'Snap/Rsht')
			safe_set_text(sections.block[78], 2, tostring(snapshot_total) .. '/' .. tostring(rapid_shot_total))
		else
			if sections.block[78] then sections.block[78]:delete() end
		end

		if settings.player.show_emct == true then
			if sections.block[77] and sections.block[77].order ~= 78 then sections.block[77]:delete() end
			if not sections.block[77] then sections.block[77] = ImageBlock.New(78,'block', dark_green_color, 'EMCT', 00) end
			safe_set_text(sections.block[77], 2, emct_total)
		else
			if sections.block[77] then sections.block[77]:delete() end
		end

		if settings.player.show_inq == true then
			if not sections.block[79] then sections.block[79] = ImageBlock.New(81,'block', 'purple', 'INQ', 00) end
			safe_set_text(sections.block[79], 2, inq_total)
		else
			if sections.block[79] then sections.block[79]:delete() end
		end

		if settings.player.show_emed == true then
			if sections.block[81] then sections.block[81]:delete() end
			if sections.block[108] and sections.block[108].text and sections.block[108].text[1] and sections.block[108].text[1].text == 'EMED' then sections.block[108]:delete() end
			if sections.block[113] and sections.block[113].order ~= 113 then sections.block[113]:delete() end
			if sections.block[113] and sections.block[113].text and sections.block[113].text[1] and sections.block[113].text[1].text ~= 'EMED' then sections.block[113]:delete() end
			if not sections.block[113] then sections.block[113] = ImageBlock.New(113,'block', dark_green_color, 'EMED', 00) end
			safe_set_text(sections.block[113], 2, emed_total)
		else
			if sections.block[81] then sections.block[81]:delete() end
			if sections.block[113] then sections.block[113]:delete() end
		end

		if settings.player.show_steal == true then
			if sections.block[83] and sections.block[83].order ~= 84 then sections.block[83]:delete() end
			if not sections.block[83] then sections.block[83] = ImageBlock.New(84,'block', 'brown', 'Steal', 00) end
			safe_set_text(sections.block[83], 2, steal_total)
		else
			if sections.block[83] then sections.block[83]:delete() end
		end

		if settings.player.show_sa == true or settings.player.show_ta == true then
			if sections.block[84] and sections.block[84].order ~= 85 then sections.block[84]:delete() end
			if not sections.block[84] then sections.block[84] = ImageBlock.New(85,'block', 'brown', 'SA/TA', 00) end
			safe_set_text(sections.block[84], 1, 'SA/TA')
			safe_set_text(sections.block[84], 2, tostring(sneak_total) .. '/' .. tostring(trick_total))
		else
			if sections.block[84] then sections.block[84]:delete() end
		end

		if settings.player.show_allsongs == true then
			if not sections.block[85] then sections.block[85] = ImageBlock.New(86,'block', dark_green_color, 'Songs', 00) end
			safe_set_text(sections.block[85], 2, all_songs_total)
		else
			if sections.block[85] then sections.block[85]:delete() end
		end

		if settings.player.show_sed == true or settings.player.show_sst == true then
			if not sections.block[86] then sections.block[86] = ImageBlock.New(87,'block', dark_green_color, 'SED/SST', 00) end
			safe_set_text(sections.block[86], 1, 'SED/SST')
			safe_set_text(sections.block[86], 2, tostring(sed_total) .. '/' .. tostring(sst_total))
		else
			if sections.block[86] then sections.block[86]:delete() end
		end
		if sections.block[87] then sections.block[87]:delete() end

		if settings.player.show_pr == true or settings.player.show_petdt == true then
			if sections.block[88] then sections.block[88]:delete() end
			if sections.block[109] and sections.block[109].order ~= 109 then sections.block[109]:delete() end
			if sections.block[109] and sections.block[109].text and sections.block[109].text[1] and sections.block[109].text[1].text ~= 'P.Reg/P,DT' then sections.block[109]:delete() end
			if not sections.block[109] then sections.block[109] = ImageBlock.New(109,'block', dijon_color, 'P.Reg/P,DT', 00) end
			safe_set_text(sections.block[109], 1, 'P.Reg/P,DT')
			safe_set_text(sections.block[109], 2, tostring(pr_total) .. '/' .. tostring(petdt_total))
		else
			if sections.block[88] then sections.block[88]:delete() end
			if sections.block[109] then sections.block[109]:delete() end
		end
		if sections.block[89] then sections.block[89]:delete() end

		if settings.player.show_ied == true then
			if not sections.block[90] then sections.block[90] = ImageBlock.New(91,'block', 'brown', 'IED', 00) end
			safe_set_text(sections.block[90], 2, ied_total)
		else
			if sections.block[90] then sections.block[90]:delete() end
		end

		if settings.player.show_bpd == true or settings.player.show_bpd2 == true then
			if sections.block[91] and sections.block[91].color ~= dijon_color then sections.block[91]:delete() end
			if not sections.block[91] then sections.block[91] = ImageBlock.New(92,'block', dijon_color, 'BPD/B2', 00) end
			safe_set_text(sections.block[91], 1, 'BPD/B2')
			safe_set_text(sections.block[91], 2, tostring(bpd_total) .. '/' .. tostring(bpd2_total))
		else
			if sections.block[91] then sections.block[91]:delete() end
		end
		if sections.block[92] then sections.block[92]:delete() end

		if settings.player.show_bpdmg == true or settings.player.show_apc == true then
			if sections.block[93] and sections.block[93].color ~= dijon_color then sections.block[93]:delete() end
			if not sections.block[93] then sections.block[93] = ImageBlock.New(94,'block', dijon_color, 'BPDmg/APC', 00) end
			safe_set_text(sections.block[93], 1, 'BPDmg/APC')
			safe_set_text(sections.block[93], 2, tostring(bpdmg_total) .. '/' .. tostring(apc_total))
		else
			if sections.block[93] then sections.block[93]:delete() end
		end
		if sections.block[94] then sections.block[94]:delete() end

		if settings.player.show_pmab == true or settings.player.show_pmacc == true then
			if sections.block[95] and sections.block[95].color ~= dijon_color then sections.block[95]:delete() end
			if not sections.block[95] then sections.block[95] = ImageBlock.New(96,'block', dijon_color, 'P.MAB/MAcc', 00) end
			safe_set_text(sections.block[95], 1, 'P.MAB/MAcc')
			safe_set_text(sections.block[95], 2, tostring(pmab_total) .. '/' .. tostring(pmacc_total))
		else
			if sections.block[95] then sections.block[95]:delete() end
		end

		if settings.player.show_patt == true or settings.player.show_pda == true then
			if sections.block[96] and sections.block[96].color ~= dijon_color then sections.block[96]:delete() end
			if not sections.block[96] then sections.block[96] = ImageBlock.New(97,'block', dijon_color, 'P.Att/P.DA', 00) end
			safe_set_text(sections.block[96], 1, 'P.Att/P.DA')
			safe_set_text(sections.block[96], 2, tostring(patt_total) .. '/' .. tostring(pda_total))
		else
			if sections.block[96] then sections.block[96]:delete() end
		end
		if sections.block[97] then sections.block[97]:delete() end

		if settings.player.show_pacc == true then
			if sections.block[98] and sections.block[98].color ~= dijon_color then sections.block[98]:delete() end
			if not sections.block[98] then sections.block[98] = ImageBlock.New(99,'block', dijon_color, 'P.Acc', 00) end
			safe_set_text(sections.block[98], 2, pacc_total)
		else
			if sections.block[98] then sections.block[98]:delete() end
		end

		if sections.block[99] then sections.block[99]:delete() end

		if settings.player.show_sms == true then
			if sections.block[100] and sections.block[100].color ~= dijon_color then sections.block[100]:delete() end
			if not sections.block[100] then sections.block[100] = ImageBlock.New(101,'block', dijon_color, 'SMS', 00) end
			safe_set_text(sections.block[100], 2, sms_total)
		else
			if sections.block[100] then sections.block[100]:delete() end
		end

		if settings.player.show_pbpd == true then
			if sections.block[101] and sections.block[101].color ~= dijon_color then sections.block[101]:delete() end
			if not sections.block[101] then sections.block[101] = ImageBlock.New(102,'block', dijon_color, 'P.BPD', 00) end
			safe_set_text(sections.block[101], 2, pbpd_total)
		else
			if sections.block[101] then sections.block[101]:delete() end
		end

		if settings.player.show_pmdmg == true then
			if sections.block[102] and sections.block[102].color ~= dijon_color then sections.block[102]:delete() end
			if not sections.block[102] then sections.block[102] = ImageBlock.New(103,'block', dijon_color, 'P.MDmg', 00) end
			safe_set_text(sections.block[102], 2, pmdmg_total)
		else
			if sections.block[102] then sections.block[102]:delete() end
		end

		if settings.player.show_petpdt == true or settings.player.show_petmdt == true then
			if sections.block[103] then sections.block[103]:delete() end
			if sections.block[110] and sections.block[110].order ~= 110 then sections.block[110]:delete() end
			if sections.block[110] and sections.block[110].text and sections.block[110].text[1] and sections.block[110].text[1].text ~= 'PetPDT/MDT' then sections.block[110]:delete() end
			if not sections.block[110] then sections.block[110] = ImageBlock.New(110,'block', dijon_color, 'PetPDT/MDT', 00) end
			safe_set_text(sections.block[110], 1, 'PetPDT/MDT')
			safe_set_text(sections.block[110], 2, tostring(petpdt_total) .. '/' .. tostring(petmdt_total))
		else
			if sections.block[103] then sections.block[103]:delete() end
			if sections.block[110] then sections.block[110]:delete() end
		end
		if sections.block[104] then sections.block[104]:delete() end

		if settings.player.show_pethaste == true then
			if sections.block[105] then sections.block[105]:delete() end
			if sections.block[111] and sections.block[111].order ~= 111 then sections.block[111]:delete() end
			if sections.block[111] and sections.block[111].text and sections.block[111].text[1] and sections.block[111].text[1].text ~= 'Pet.haste' then sections.block[111]:delete() end
			if not sections.block[111] then sections.block[111] = ImageBlock.New(111,'block', dijon_color, 'Pet.haste', 00) end
			safe_set_text(sections.block[111], 1, 'Pet.haste')
			safe_set_text(sections.block[111], 2, pethaste_total)
		else
			if sections.block[105] then sections.block[105]:delete() end
			if sections.block[111] then sections.block[111]:delete() end
		end

		if settings.player.show_cursna == true then
			if sections.block[107] then sections.block[107]:delete() end
			if sections.block[121] and sections.block[121].order ~= 121 then sections.block[121]:delete() end
			if sections.block[121] and sections.block[121].text and sections.block[121].text[1] and sections.block[121].text[1].text ~= 'Cursna' then sections.block[121]:delete() end
			if not sections.block[121] then sections.block[121] = ImageBlock.New(121,'block', dark_green_color, 'Cursna', 00) end
			safe_set_text(sections.block[121], 2, cursna_total)
		else
			if sections.block[107] then sections.block[107]:delete() end
			if sections.block[121] then sections.block[121]:delete() end
		end

		-- In calc mode, keep only blocks with value > 0 visible.
		apply_calc_mode_visibility()

		-------------------------------------------------------------- update GS ---------------------------------------------------------------
		-- if old_inform ~= inform then
			-- --text_box:update(inform)
			-- old_inform = inform
		-- end
		--log(DW_needed)
		if settings.player.update_gs == true then
			local new_dw = DW_needed + manual_dw_needed
			local total_ma , MA_needed = martial_arts_needed()
			local MA = false
			
			if player.equipment.main.skill == "Hand-to-Hand" or player.equipment.main.en == '' then
				MA = true
			end
			update_gs(DW, new_dw, Total_haste, MA, MA_needed)
			old_DW_needed = new_dw
		end
		-- ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â° ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂªÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â« ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â±ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â© ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â© ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â· ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â­ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â© (ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂªÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂºÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â± ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨/ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¥ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â± ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â±ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Âª)
		if test_mode_pending and type(check_positions) == 'function' then
			check_positions()
			if sections and sections.background then
				local width = sections.background.width
				local height = sections.background.height
				if not width or not height then
					local bw, bh = calc_block_dimensions()
					local cols = tonumber(settings.display.mode) or 4
					width = cols * bw
					height = bh
				end
				local ws = windower.get_windower_settings()
				local sw = ws and ws.x_res or 1920
				local sh = ws and ws.y_res or 1080
				local x = math.floor((sw - width) / 2)
				local y = math.floor((sh - height) / 2)
				if x < 0 then x = 0 end
				if y < 0 then y = 0 end
				settings.display.pos.x = x
				settings.display.pos.y = y
				sections.background:position(x, y)
				check_positions()
			end
			test_mode_pending = false
			mode_refresh_pending = false
		elseif mode_refresh_pending and type(check_positions) == 'function' then
			check_positions()
			mode_refresh_pending = false
		end
	end
	--print('updating')
end


loop_count = 0
frame_count = 0
local GI_UPDATE_FRAME_INTERVAL = 45
local GI_BUFF_FRAME_INTERVAL = 90
local GI_PARTY_FRAME_INTERVAL = 180
windower.register_event('prerender',function()
	if frame_count%2 == 0 and windower.ffxi.get_info().logged_in then
		if type(centre_all_text) == 'function' then
			centre_all_text()
		end
	end
    if frame_count%GI_UPDATE_FRAME_INTERVAL == 0 and windower.ffxi.get_info().logged_in then
        local temp_equip = player.equipment
        local temp_stats = player.stats
		local temp_pos = player.position
        player = windower.ffxi.get_player()
        player.equipment = temp_equip
		-- get_player_skill_in_gear(check_equipped())
        player.stats = temp_stats
		player.position = temp_pos
		player.is_moving = check_player_movement(player)
		if frame_count%GI_BUFF_FRAME_INTERVAL == 0 then
			check_buffs()
		end
		if frame_count%GI_PARTY_FRAME_INTERVAL == 0 then
			update_party()
		end
		calculate_total_haste()
        update()
		if (_text_layout_dirty_frames or 0) > 0 and type(centre_all_text) == 'function' then
			centre_all_text()
			_text_layout_dirty_frames = _text_layout_dirty_frames - 1
		end
		-- Debounced cache write: avoid heavy disk I/O on rapid gear swaps.
		if cache_save_pending then
			local now = os.clock()
			if (now - cache_save_last) >= CACHE_SAVE_COOLDOWN then
				save_table_to_file(full_gear_table_from_file, true)
				cache_save_last = now
				cache_save_pending = false
			end
		end
		loop_count = loop_count + 1
    end
    frame_count = frame_count + 1
end)

windower.register_event('incoming chunk',incoming_chunk)
windower.register_event('outgoing chunk',outgoing_chunk)

windower.register_event('incoming text', function(old, new, color)
    --Hides Battlemod
	if settings.player.show_COR_messages then
		if old:match("Roll.* The total.*") or old:match('.*Roll.*' .. string.char(0x81, 0xA8)) or old:match('.*uses Double.*The total') and color ~= 123 then
			return true
		end

		--Hides normal
		if old:match('.* receives the effect of .* Roll.') ~= nil then
			return true
		end

		--Hides Older Battlemod versions --Antiquated
		if old:match('%('..'%w+'..'%).* Roll ') then
			new = old
		end

		return new, color
	-- else
		-- return old, color
	end
end)

function update_gs(DW, Total_DW_needed, haste, MA, MA_needed, force_send)
	local payload = nil
	if DW == true then
		payload = tostring(Total_DW_needed) .. ' ' .. tostring(haste) .. ' ' .. tostring(player.is_moving) .. ' ' .. tostring(MA)
	elseif DW == false then
		if MA then
			payload = tostring(DW) .. ' ' .. tostring(haste) .. ' ' .. tostring(player.is_moving) .. ' ' .. tostring(MA_needed)
		else
			payload = tostring(Total_DW_needed) .. ' ' .. tostring(haste) .. ' ' .. tostring(player.is_moving) .. ' ' .. tostring(MA)
		end
	end
	if not payload then
		return
	end
	local now = os.clock()
	if not force_send then
		if _gs_last_payload == payload then
			return
		end
		if (now - _gs_last_send_at) < _gs_min_interval then
			return
		end
	end
	_gs_last_payload = payload
	_gs_last_send_at = now
	windower.send_command('gs c gearinfo ' .. payload)
end

windower.register_event('unload', function()
	if cache_save_pending then
		save_table_to_file(full_gear_table_from_file, true)
		cache_save_pending = false
	end
end)

-- One-time notice after first HUD build showing how many equipped items matched Aug_DB
local function _augdb_notice_once(equipment)
    if _aug_db_display_notice then return end
    local count = 0
    if Aug_DB and equipment then
        for slot, item in pairs(equipment) do
            if item and item.id and Aug_DB[item.id] then
                count = count + 1
            end
        end
    end
    if count > 0 then
        windower.add_to_chat(158, string.format('[GearInfo] Aug_DB applied to %d equipped items.', count)) -- green
    else
        windower.add_to_chat(167, '[GearInfo] No Aug_DB matches in current gear.') -- red
    end
    _aug_db_display_notice = true
end


windower.register_event('load', function()
    if _aug_db_display_notice then return end
    windower.add_to_chat(207, '[GearInfo] Aug_DB ready (load event).')
end)
