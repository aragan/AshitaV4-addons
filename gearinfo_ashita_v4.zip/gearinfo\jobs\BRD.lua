return {
    code = 'BRD',
    extra2 = false,
    dd_melee = false,
    extra5 = false,
    extra_preset = {
        'show_allsongs',
        'show_sed',
        'show_sst',
    },
}
