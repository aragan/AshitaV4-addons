local compat = {};
local fonts = require('fonts');
local primitives = require('primitives');
local imgui = require('imgui');
local chatlib = require('chat');
local packetlib = require('packets');
local actionlib = require('ashita_action');
local resources = require('resources');
local bit = require('bit');
local debuglib = debug;
local unpack_values = unpack;

local function snapshot_library(value)
    local result = {};
    for key, item in pairs(value) do result[key] = item; end
    return result;
end

local function apply_library(target, source)
    for key in pairs(target) do
        if (source[key] == nil) then target[key] = nil; end
    end
    for key, item in pairs(source) do target[key] = item; end
end

local ashita_sugar = {
    T=T,
    string_mt=debuglib.getmetatable(''),
    number_mt=debuglib.getmetatable(0),
    boolean_mt=debuglib.getmetatable(false),
    function_mt=debuglib.getmetatable(function () end),
    string_lib=snapshot_library(string),
    table_lib=snapshot_library(table),
    math_lib=snapshot_library(math),
};

local callbacks = {};
local text_objects = {};
local primitive_objects = {};
local texture_load_failures = {};
local initialized = false;
local started = false;
local sequence = 0;

local function with_ashita_sugar(callback)
    local current = {
        T=T,
        string_mt=debuglib.getmetatable(''),
        number_mt=debuglib.getmetatable(0),
        boolean_mt=debuglib.getmetatable(false),
        function_mt=debuglib.getmetatable(function () end),
        string_lib=snapshot_library(string),
        table_lib=snapshot_library(table),
        math_lib=snapshot_library(math),
    };
    T = ashita_sugar.T;
    apply_library(string, ashita_sugar.string_lib);
    apply_library(table, ashita_sugar.table_lib);
    apply_library(math, ashita_sugar.math_lib);
    debuglib.setmetatable('', ashita_sugar.string_mt);
    debuglib.setmetatable(0, ashita_sugar.number_mt);
    debuglib.setmetatable(false, ashita_sugar.boolean_mt);
    debuglib.setmetatable(function () end, ashita_sugar.function_mt);
    local ok, result = xpcall(callback, debuglib.traceback);
    T = current.T;
    apply_library(string, current.string_lib);
    apply_library(table, current.table_lib);
    apply_library(math, current.math_lib);
    debuglib.setmetatable('', current.string_mt);
    debuglib.setmetatable(0, current.number_mt);
    debuglib.setmetatable(false, current.boolean_mt);
    debuglib.setmetatable(function () end, current.function_mt);
    if (not ok) then error(result, 0); end
    return result;
end

local slot_names = {
    'main','sub','range','ammo','head','body','hands','legs','feet',
    'neck','waist','left_ear','right_ear','left_ring','right_ring','back',
};

local skill_names = {
    [1]='hand_to_hand',[2]='dagger',[3]='sword',[4]='great_sword',[5]='axe',
    [6]='great_axe',[7]='scythe',[8]='polearm',[9]='katana',[10]='great_katana',
    [11]='club',[12]='staff',[25]='archery',[26]='marksmanship',[27]='throwing',
    [28]='guarding',[29]='evasion',[30]='shield',[31]='parrying',
    [32]='divine_magic',[33]='healing_magic',[34]='enhancing_magic',
    [35]='enfeebling_magic',[36]='elemental_magic',[37]='dark_magic',
    [38]='summoning_magic',[39]='ninjutsu',[40]='singing',
    [41]='stringed_instrument',[42]='wind_instrument',[43]='blue_magic',
    [44]='geomancy',[45]='handbell',
};

local function mm()
    return AshitaCore:GetMemoryManager();
end

local function safe(object, method, default, ...)
    if (object == nil or type(object[method]) ~= 'function') then return default; end
    local ok, value = pcall(object[method], object, ...);
    if (ok and value ~= nil) then return value; end
    return default;
end

local function invoke(name, ...)
    local list = callbacks[name];
    if (list == nil) then return false; end
    local arguments = { n=select('#', ...), ... };
    local blocked = false;
    for _, callback in ipairs(list) do
        local ok, result = xpcall(function ()
            return callback(unpack_values(arguments, 1, arguments.n));
        end, debuglib.traceback);
        if (not ok) then
            print(('[GearInfo] %s event failed: %s'):format(name, result));
        elseif (result == true) then
            blocked = true;
        end
    end
    return blocked;
end

local function register_callback(name, callback)
    callbacks[name] = callbacks[name] or {};
    table.insert(callbacks[name], callback);
    sequence = sequence + 1;
    return sequence;
end

local function argb(a, r, g, b)
    local value = bit.bor(
        bit.lshift(bit.band(tonumber(a) or 255, 0xFF), 24),
        bit.lshift(bit.band(tonumber(r) or 255, 0xFF), 16),
        bit.lshift(bit.band(tonumber(g) or 255, 0xFF), 8),
        bit.band(tonumber(b) or 255, 0xFF)
    );
    return value < 0 and (value + 0x100000000) or value;
end

local function player_buffs(player)
    local result = {};
    local buffs = safe(player, 'GetBuffs', nil);
    if (buffs == nil) then buffs = safe(player, 'GetStatusIcons', nil); end
    if (type(buffs) == 'table') then
        for _, value in pairs(buffs) do
            value = tonumber(value);
            if (value ~= nil and value > 0 and value < 1023 and value ~= 255) then
                table.insert(result, value);
            end
        end
    elseif (buffs ~= nil) then
        for index = 0, 31 do
            local ok, value = pcall(function () return buffs[index]; end);
            value = ok and tonumber(value) or nil;
            if (value ~= nil and value > 0 and value < 1023 and value ~= 255) then
                table.insert(result, value);
            end
        end
    end
    return result;
end

local function combat_skills(player)
    local result = {};
    for id, name in pairs(skill_names) do
        local entry = safe(player, 'GetCombatSkill', nil, id - 1);
        local value = safe(entry, 'GetSkill', 0);
        if (type(entry) == 'table' and tonumber(entry.Skill) ~= nil) then value = entry.Skill; end
        result[name] = tonumber(value) or 0;
    end
    return result;
end

local function job_points(player)
    local result = {};
    for id = 1, 22 do
        local job = resources.jobs[id];
        if (job ~= nil and job.ens ~= nil) then
            result[job.ens:lower()] = {
                jp = tonumber(safe(player, 'GetJobPoints', 0, id)) or 0,
                jp_spent = tonumber(safe(player, 'GetJobPointsSpent', 0, id)) or 0,
            };
        end
    end
    return result;
end

local function player_stats(player)
    local names = { 'STR', 'DEX', 'VIT', 'AGI', 'INT', 'MND', 'CHR' };
    local result = {};
    for index, name in ipairs(names) do
        result[name] = tonumber(safe(player, 'GetStat', 0, index - 1)) or 0;
    end
    result.Attack = tonumber(safe(player, 'GetAttack', 0)) or 0;
    result.Defense = tonumber(safe(player, 'GetDefense', 0)) or 0;
    result.attack = result.Attack;
    result.defense = result.Defense;
    return result;
end

local function current_player()
    local memory = mm();
    local player = memory and memory:GetPlayer() or nil;
    local party = memory and memory:GetParty() or nil;
    local entity = memory and memory:GetEntity() or nil;
    local index = safe(party, 'GetMemberTargetIndex', 0, 0);
    local main_id = safe(player, 'GetMainJob', 0);
    local sub_id = safe(player, 'GetSubJob', 0);
    local main = resources.jobs[main_id];
    local sub = resources.jobs[sub_id];
    local name = safe(party, 'GetMemberName', '', 0);
    local server_id = safe(party, 'GetMemberServerId', 0, 0);
    local skills = combat_skills(player);
    return {
        id = server_id,
        index = index,
        name = name,
        main_job_id = main_id,
        sub_job_id = sub_id,
        main_job = main and main.ens or '',
        sub_job = sub and sub.ens or '',
        main_job_level = safe(player, 'GetMainJobLevel', 0),
        sub_job_level = safe(player, 'GetSubJobLevel', 0),
        status = safe(entity, 'GetStatus', 0, index),
        buffs = player_buffs(player),
        skills = skills,
        skill = skills,
        job_points = job_points(player),
        merits = { desperate_blows=0, ikishoten=0, store_tp_effect=0, aggressive_aim=0 },
        stats = player_stats(player),
        vitals = {
            hp=safe(party, 'GetMemberHP', 0, 0),
            mp=safe(party, 'GetMemberMP', 0, 0),
            tp=safe(party, 'GetMemberTP', 0, 0),
            hpp=safe(party, 'GetMemberHPPercent', 100, 0),
            mpp=safe(party, 'GetMemberMPPercent', 100, 0),
            max_hp=safe(player, 'GetHPMax', 0),
            max_mp=safe(player, 'GetMPMax', 0),
        },
        equipment = {},
    };
end

local function mob_by_index(index)
    index = tonumber(index) or 0;
    local entity = mm() and mm():GetEntity() or nil;
    if (entity == nil or index <= 0) then return nil; end
    local id = safe(entity, 'GetServerId', 0, index);
    if (id == 0) then return nil; end
    local pet_index = safe(entity, 'GetPetTargetIndex', 0, index);
    return {
        id=id, index=index, name=safe(entity, 'GetName', '', index),
        x=safe(entity, 'GetLocalPositionX', 0, index),
        y=safe(entity, 'GetLocalPositionZ', 0, index),
        z=safe(entity, 'GetLocalPositionY', 0, index),
        hpp=safe(entity, 'GetHPPercent', 0, index),
        distance=safe(entity, 'GetDistance', 0, index),
        status=safe(entity, 'GetStatus', 0, index),
        claim_id=safe(entity, 'GetClaimStatus', 0, index),
        spawn_type=safe(entity, 'GetSpawnFlags', 0, index),
        pet_index=pet_index ~= 0 and pet_index or nil,
        charmed=false, valid_target=true,
    };
end

local function extra_string(extra)
    if (extra == nil) then return ''; end
    if (type(extra) == 'string') then return extra; end
    local ok, values = pcall(function () return extra:totable(); end);
    if (not ok or type(values) ~= 'table') then return ''; end
    local chars = {};
    for index, value in ipairs(values) do chars[index] = string.char(tonumber(value) or 0); end
    return table.concat(chars);
end

local function decode_equipped(entry)
    if (entry == nil) then return 0, 0; end
    local encoded = tonumber(entry.Index or entry.index) or 0;
    local container = tonumber(entry.Container or entry.container);
    if (container ~= nil) then return container, encoded % 256; end
    if (encoded < 2048) then return 0, encoded; end
    if (encoded < 2560) then return 8, encoded - 2048; end
    if (encoded < 2816) then return 10, encoded - 2560; end
    if (encoded < 3072) then return 11, encoded - 2816; end
    if (encoded < 3328) then return 12, encoded - 3072; end
    if (encoded < 3584) then return 13, encoded - 3328; end
    if (encoded < 3840) then return 14, encoded - 3584; end
    if (encoded < 4096) then return 15, encoded - 3840; end
    if (encoded < 4352) then return 16, encoded - 4096; end
    return 0, encoded % 256;
end

local function item_at(container, index)
    local inventory = mm() and mm():GetInventory() or nil;
    local item = safe(inventory, 'GetContainerItem', nil, tonumber(container) or 0, tonumber(index) or 0);
    if (item == nil) then
        return { id=0, count=0, status=0, slot=tonumber(index) or 0, bag=tonumber(container) or 0, bazaar=0, extdata='' };
    end
    return {
        id=tonumber(item.Id or item.ItemId) or 0,
        count=tonumber(item.Count or item.Quantity) or 0,
        status=tonumber(item.Status) or 0,
        slot=tonumber(index) or tonumber(item.Index) or 0,
        bag=tonumber(container) or 0,
        bazaar=tonumber(item.Price) or 0,
        extdata=extra_string(item.Extra),
    };
end

local function inventory_items(container, index)
    if (container ~= nil and index ~= nil) then return item_at(container, index); end
    local inventory = mm() and mm():GetInventory() or nil;
    if (container ~= nil) then
        local result = {};
        local max = safe(inventory, 'GetContainerCountMax', 80, tonumber(container) or 0);
        for slot = 0, max do
            local item = item_at(container, slot);
            if (item.id ~= 0) then result[slot] = item; end
        end
        return result;
    end
    local result = { gil=0, equipment={} };
    for slot = 0, 15 do
        local equipped = safe(inventory, 'GetEquippedItem', nil, slot);
        local bag, item_index = decode_equipped(equipped);
        local name = slot_names[slot + 1];
        result.equipment[name] = item_index;
        result.equipment[name .. '_bag'] = bag;
    end
    return result;
end

local function party_table()
    local result = {};
    local party = mm() and mm():GetParty() or nil;
    local keys = {
        'p0','p1','p2','p3','p4','p5',
        'a10','a11','a12','a13','a14','a15',
        'a20','a21','a22','a23','a24','a25',
    };
    for member = 0, 17 do
        local id = safe(party, 'GetMemberServerId', 0, member);
        local name = safe(party, 'GetMemberName', '', member);
        local index = safe(party, 'GetMemberTargetIndex', 0, member);
        if (id ~= 0 and name ~= '') then
            result[keys[member + 1]] = {
                id=id, name=name, mob=mob_by_index(index),
                hpp=safe(party, 'GetMemberHPPercent', 0, member),
                mpp=safe(party, 'GetMemberMPPercent', 0, member),
                tp=safe(party, 'GetMemberTP', 0, member),
            };
        end
    end
    return result;
end

local blu_offset = nil;
local function blu_spells()
    local result = {};
    local ok = pcall(function ()
        if (blu_offset == nil) then
            local address = ashita.memory.find(0, 0, 'C1E1032BC8B0018D????????????B9????????F3A55F5E5B', 10, 0);
            if (address == 0) then blu_offset = false; return; end
            blu_offset = ashita.memory.read_uint32(address);
        end
        if (blu_offset == false) then return; end
        local pointer = ashita.memory.read_uint32(AshitaCore:GetPointerManager():Get('inventory'));
        if (pointer == 0) then return; end
        pointer = ashita.memory.read_uint32(pointer);
        if (pointer == 0) then return; end
        local player = mm():GetPlayer();
        local offset = safe(player, 'GetMainJob', 0) == 16 and 0x04 or 0xA0;
        local values = ashita.memory.read_array(pointer + blu_offset + offset, 0x14);
        for _, value in ipairs(values) do
            if (value ~= 0) then table.insert(result, value + 512); end
        end
    end);
    return ok and result or {};
end

local function add_to_chat(_, value)
    print(('[GearInfo] %s'):format(tostring(value or '')));
end

local function queue_command(command)
    command = tostring(command or ''):gsub('^%s*input%s+', '');
    command = command:gsub('^%s*lua%s+r%s+gearinfo%s*;?%s*$', '/addon reload gearinfo');
    command = command:gsub('^%s*lua%s+u%s+gearinfo%s*;?%s*$', '/addon unload gearinfo');
    if (command:sub(1, 1) ~= '/') then command = '/' .. command; end
    AshitaCore:GetChatManager():QueueCommand(-1, command);
end

local function create_text(name)
    if (text_objects[name] ~= nil) then return; end
    text_objects[name] = with_ashita_sugar(function ()
        return fonts.new({
            visible=false, can_focus=false, locked=true, lockedz=false,
            font_family='Tahoma', font_height=10, color=0xFFFFFFFF,
            color_outline=0xFF000000, position_x=0, position_y=0,
            auto_resize=true, text='',
        });
    end);
end

local function create_primitive(name)
    if (primitive_objects[name] ~= nil) then return; end
    primitive_objects[name] = with_ashita_sugar(function ()
        local font = fonts.new({
            visible=true, can_focus=false, locked=true, lockedz=false,
            font_family='Tahoma', font_height=1, color=0x00000000,
            position_x=0, position_y=0, auto_resize=false, text=' ',
            background={
                visible=false, can_focus=false, locked=true, lockedz=false,
                position_x=0, position_y=0, width=1, height=1,
                color=0xFFFFFFFF,
            },
        });
        return {
            font=font, font_obj=font.obj, obj=font.obj:GetBackground(),
            visible=false, x=0, y=0, width=1, height=1,
            alpha=255, red=255, green=255, blue=255, is_solid=false,
        };
    end);
end

local function install_ui()
    windower.text = {};
    function windower.text.create(name) create_text(name); end
    function windower.text.delete(name)
        local value = text_objects[name];
        if (value ~= nil) then value:destroy(); text_objects[name] = nil; end
    end
    function windower.text.set_text(name, value) create_text(name); text_objects[name].text = tostring(value or ''); end
    function windower.text.set_visibility(name, value) create_text(name); text_objects[name].visible = value == true; end
    function windower.text.set_bold(name, value) create_text(name); text_objects[name].bold = value == true; end
    function windower.text.set_font(name, value) create_text(name); text_objects[name].font_family = tostring(value or 'Tahoma'); end
    function windower.text.set_font_size(name, value) create_text(name); text_objects[name].font_height = tonumber(value) or 10; end
    function windower.text.set_location(name, x, y) create_text(name); text_objects[name].position_x = tonumber(x) or 0; text_objects[name].position_y = tonumber(y) or 0; end
    function windower.text.set_color(name, a, r, g, b) create_text(name); text_objects[name].color = argb(a, r, g, b); end
    function windower.text.set_stroke_color(name, a, r, g, b) create_text(name); text_objects[name].color_outline = argb(a, r, g, b); end
    function windower.text.set_stroke_width(name, value)
        create_text(name);
        text_objects[name].padding = (tonumber(value) or 0) > 0 and 0.2 or 0.0;
    end
    function windower.text.get_extents(name)
        create_text(name);
        local width, height;
        with_ashita_sugar(function ()
            width, height = text_objects[name]:get_text_size();
        end);
        return width, height;
    end

    windower.prim = {};
    function windower.prim.create(name) create_primitive(name); end
    function windower.prim.delete(name)
        local value = primitive_objects[name];
        if (value ~= nil) then value.font:destroy(); primitive_objects[name] = nil; end
    end
    function windower.prim.set_visibility(name, value)
        create_primitive(name);
        local primitive = primitive_objects[name];
        primitive.visible = value == true;
        primitive.font_obj:SetVisible(primitive.visible);
        primitive.obj:SetVisible(primitive.visible);
    end
    function windower.prim.set_position(name, x, y)
        create_primitive(name);
        local primitive = primitive_objects[name];
        primitive.x = tonumber(x) or 0;
        primitive.y = tonumber(y) or 0;
        primitive.font_obj:SetPositionX(primitive.x);
        primitive.font_obj:SetPositionY(primitive.y);
        primitive.obj:SetPositionX(0);
        primitive.obj:SetPositionY(0);
    end
    function windower.prim.set_size(name, width, height)
        create_primitive(name);
        local primitive = primitive_objects[name];
        width = tonumber(width) or 1;
        height = tonumber(height) or 1;
        primitive.width = width;
        primitive.height = height;
        primitive.font_obj:SetWindowWidth(width);
        primitive.font_obj:SetWindowHeight(height);
        primitive.obj:SetWidth(width);
        primitive.obj:SetHeight(height);
    end
    function windower.prim.set_color(name, a, r, g, b)
        create_primitive(name);
        local primitive = primitive_objects[name];
        primitive.alpha = tonumber(a) or 255;
        primitive.red = tonumber(r) or 255;
        primitive.green = tonumber(g) or 255;
        primitive.blue = tonumber(b) or 255;
        primitive.obj:SetColor(argb(a, r, g, b));
    end
    function windower.prim.set_texture(name, path)
        create_primitive(name);
        path = tostring(path or '');
        primitive_objects[name].is_solid = path == '';
        if (path == '') then
            path = addon.path .. 'images/solid.png';
        end
        local primitive = primitive_objects[name];
        local ok, loaded = pcall(function ()
            return primitive.obj:SetTextureFromFile(path);
        end);
        if ((not ok or loaded == false) and not texture_load_failures[path]) then
            texture_load_failures[path] = true;
            print(('[GearInfo] Failed to load primitive texture: %s'):format(path));
        end
    end
    function windower.prim.set_fit_to_texture(_, _) end
end

local primitive_render_error = false;
local function render_solid_primitive_backgrounds()
    local ok, err = pcall(function ()
        local flags = bit.bor(
            ImGuiWindowFlags_NoDecoration,
            ImGuiWindowFlags_NoInputs,
            ImGuiWindowFlags_NoSavedSettings,
            ImGuiWindowFlags_NoFocusOnAppearing,
            ImGuiWindowFlags_NoBringToFrontOnFocus
        );
        for name, primitive in pairs(primitive_objects) do
            if primitive.is_solid and primitive.visible and primitive.alpha > 0
                and primitive.width > 1 and primitive.height > 1 then
                local red = math.max(0, math.min(255, primitive.red)) / 255;
                local green = math.max(0, math.min(255, primitive.green)) / 255;
                local blue = math.max(0, math.min(255, primitive.blue)) / 255;
                local alpha = math.max(0, math.min(255, primitive.alpha)) / 255;

                imgui.SetNextWindowPos({ primitive.x, primitive.y }, ImGuiCond_Always);
                imgui.SetNextWindowSize({ primitive.width, primitive.height }, ImGuiCond_Always);
                imgui.SetNextWindowBgAlpha(alpha);
                imgui.PushStyleColor(ImGuiCol_WindowBg, { red, green, blue, 1.0 });
                imgui.PushStyleVar(ImGuiStyleVar_WindowPadding, { 0, 0 });
                imgui.PushStyleVar(ImGuiStyleVar_WindowRounding, 3.0);
                imgui.PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0);
                if imgui.Begin('##GearInfoBackground_' .. tostring(name), true, flags) then
                    imgui.End();
                end
                imgui.PopStyleVar(3);
                imgui.PopStyleColor(1);
            end
        end
    end);
    if not ok and not primitive_render_error then
        primitive_render_error = true;
        print(('[GearInfo] ImGui background render failed: %s'):format(tostring(err)));
    end
end

local function install_events()
    ashita.events.register('d3d_present', 'gearinfo_compat_present', function ()
        if (started) then
            invoke('prerender');
            render_solid_primitive_backgrounds();
        end
    end);
    ashita.events.register('packet_in', 'gearinfo_compat_packet_in', function (event)
        local data = event.data_modified or event.data;
        packetlib._remember(event.id, data);
        invoke('incoming chunk', event.id, data, data, event.injected, event.blocked);
        if (event.id == 0x028) then invoke('action', actionlib.parse(data)); end
    end);
    ashita.events.register('packet_out', 'gearinfo_compat_packet_out', function (event)
        local data = event.data_modified or event.data;
        invoke('outgoing chunk', event.id, data, data, event.injected, event.blocked);
    end);
    ashita.events.register('text_in', 'gearinfo_compat_text_in', function (event)
        invoke('incoming text', event.message, event.message_modified or event.message, event.mode);
    end);
    ashita.events.register('command', 'gearinfo_compat_command', function (event)
        local command = tostring(event.command or '');
        local body = command:match('^%s*/+%s*[Gg][Ii]%s*(.*)$') or command:match('^%s*/+%s*[Gg][Ee][Aa][Rr][Ii][Nn][Ff][Oo]%s*(.*)$');
        if (body == nil) then return; end
        event.blocked = true;
        local args = {};
        for value in body:gmatch('%S+') do table.insert(args, value); end
        invoke('addon command', unpack_values(args));
    end);
    ashita.events.register('mouse', 'gearinfo_compat_mouse', function (event)
        local kind = nil;
        if (event.message == 0x200) then kind = 0;
        elseif (event.message == 0x201) then kind = 1;
        elseif (event.message == 0x202) then kind = 2; end
        if (kind ~= nil and invoke('mouse', kind, event.x, event.y, event.delta or 0, event.blocked) == true) then
            event.blocked = true;
        end
    end);
    ashita.events.register('unload', 'gearinfo_compat_unload', function ()
        invoke('unload');
        compat.shutdown();
    end);
end

function compat.initialize()
    if (initialized) then return; end
    initialized = true;
    package.path = addon.path .. '?.lua;' .. addon.path .. '?\\init.lua;' .. addon.path .. 'aug_gears\\?.lua;' .. package.path;
    _addon = _addon or {};
    _addon.name = 'GearInfo';
    _addon.author = 'Sebyg666; Ashita v4 port by Aragan';
    _addon.version = '4.0.0';
    _addon.commands = { 'gi', 'gearinfo' };

    chat = chatlib;
    chat.controls = chat.controls or { reset='' };
    windower = { ffxi={}, packets=packetlib };
    windower.addon_path = addon.path;
    windower.add_to_chat = add_to_chat;
    windower.send_command = queue_command;
    windower.dir_exists = function (path)
        local ok, _, code = os.rename(path, path);
        return ok or code == 13;
    end
    windower.get_windower_settings = function ()
        local width, height = 1920, 1080;
        pcall(function ()
            local imgui = require('imgui');
            local io = imgui.GetIO();
            width, height = tonumber(io.DisplaySize.x) or width, tonumber(io.DisplaySize.y) or height;
        end);
        return { x_res=width, y_res=height, ui_x_res=width, ui_y_res=height };
    end
    windower.register_event = register_callback;
    windower.raw_register_event = register_callback;

    windower.ffxi.get_player = current_player;
    windower.ffxi.get_info = function ()
        local party = mm() and mm():GetParty() or nil;
        local id = safe(party, 'GetMemberServerId', 0, 0);
        return { zone=safe(party, 'GetMemberZone', 0, 0), logged_in=id ~= 0 };
    end
    windower.ffxi.get_items = inventory_items;
    windower.ffxi.get_party = party_table;
    windower.ffxi.get_mob_by_index = mob_by_index;
    windower.ffxi.get_mob_by_id = function (id)
        local entity = mm() and mm():GetEntity() or nil;
        if (entity == nil) then return nil; end
        for index = 0, 2303 do
            if (safe(entity, 'GetServerId', 0, index) == id) then return mob_by_index(index); end
        end
        return nil;
    end
    windower.ffxi.get_mob_by_target = function (target)
        target = tostring(target or 't'):lower();
        if (target == 'me') then return mob_by_index(current_player().index); end
        if (target == 'pet') then
            local player = mm() and mm():GetPlayer() or nil;
            local pet_index = safe(player, 'GetPetTargetIndex', 0);
            if (pet_index == 0) then pet_index = safe(player, 'GetPetIndex', 0); end
            return mob_by_index(pet_index);
        end
        local target_manager = mm() and mm():GetTarget() or nil;
        return mob_by_index(safe(target_manager, 'GetTargetIndex', 0, 0));
    end
    windower.ffxi.get_mjob_data = function () return { spells=blu_spells() }; end

    install_ui();
    install_events();
end

function compat.start()
    if (started) then return; end
    started = true;
    invoke('load');
    print('[GearInfo] Ashita v4 full port loaded. Use /gi help.');
end

function compat.shutdown()
    for name, value in pairs(text_objects) do pcall(function () value:destroy(); end); text_objects[name] = nil; end
    for name, value in pairs(primitive_objects) do pcall(function () value:destroy(); end); primitive_objects[name] = nil; end
    started = false;
end

return compat;
