local dragged

math.randomseed(os.clock())

imageColors = L{'amber','amber-dark','amber-light','aqua','aqua-dark','aqua-light','azure','azure-dark','azure-light','berry','blue','brown','chartreuse','chartreuse-dark','chartreuse-light','chocolate','chocolate-dark','chocolate-light','cobalt','cobalt-dark','cobalt-light','coffee','coffee-dark','coffee-light','coral','coral-dark','coral-light','crimson','crimson-dark','crimson-light','cyan','cyan-dark','cyan-light','dark-blue','dark-green','dijon','emerald','emerald-dark','emerald-light','fuchsia','fuchsia-dark','fuchsia-light','gold','gold-dark','gold-light','green','grey','indigo','indigo-dark','indigo-light','jade','jade-dark','jade-light','lemon','lemon-dark','lemon-light','light-green','lime','lime-dark','lime-light','magenta','magenta-dark','magenta-light','maroon','maroon-dark','maroon-light','olive','olive-dark','olive-light','orange','pink','plum','plum-dark','plum-light','purple','red','rose','rose-dark','rose-light','scarlet','scarlet-dark','scarlet-light','sky','sky-dark','sky-light','slate','slate-dark','slate-light','sunflower','sunflower-dark','sunflower-light','tangerine','tangerine-dark','tangerine-light','teal','teal-dark','teal-light','turquoise','turquoise-dark','turquoise-light','violet','violet-dark','violet-light','yellow'}

local function grid_columns()
	local mode = 1
	if settings and settings.display and settings.display.mode then
		mode = tonumber(settings.display.mode) or 1
	end
	if mode == 2 then
		return 8
	end
	if mode == 3 then
		return 12
	end
	if mode == 4 then
		return 6
	end
	if mode == 5 then
		return 3
	end
	if mode == 6 then
		return 2
	end
	if mode == 7 then
		return 1
	end
	if mode == 8 then
		return 16
	end
	return 4
end

local function grid_block_width()
	local size = 5
	if settings and settings.display and settings.display.size then
		size = tonumber(settings.display.size) or 5
	end
	if size < 1 then size = 1 end
	if size > 9 then size = 9 end
	local scale = size / 5
	local width = math.floor((72 * scale) + 0.5)
	if width < 24 then width = 24 end
	return width
end

local function grid_block_height()
	local size = 5
	if settings and settings.display and settings.display.size then
		size = tonumber(settings.display.size) or 5
	end
	if size < 1 then size = 1 end
	if size > 9 then size = 9 end
	local scale = size / 5
	local height = math.floor((42 * scale) + 0.5)
	if height < 18 then height = 18 end
	return height
end

local function is_flat_style()
	if settings and settings.display and settings.display.style then
		local style = tostring(settings.display.style):lower()
		return style == 'flat' or style == 'text' or style == 'plain'
	end
	return false
end

local function font_size_scale(kind)
	local size = 5
	if settings and settings.display then
		if kind == 'label' then
			size = tonumber(settings.display.label_size) or 5
		elseif kind == 'value' then
			size = tonumber(settings.display.value_size) or 5
		else
			size = tonumber(settings.display.size) or 5
		end
	end
	if size < 1 then size = 1 end
	if size > 9 then size = 9 end
	return size / 5
end


--[[ui scaling shrinks display 
	x_res = 1920
	y_res = 1080
	ui_x_res = 1476
	ui_y_res = 830
	settings = ui scale 1.3
	ui_x_res = x_res / ui scale 
]]--
-- image / icon Block Class
local function table_count(t)
	local c = 0
	for _ in pairs(t or {}) do
		c = c + 1
	end
	return c
end

ImageBlock = {
	x = 0,
	y = 0,
	width = 228,
	height = 1,
	alpha = 255,
	red = 255,
	green = 255,
	blue = 255,
	visible = true,
	draggable = false,
	fit = true,

	New = function(order, image_type, image_color, text1, text2)
		local o = {}
		for k, v in pairs(ImageBlock) do
			o[k] = v
		end
		local order_exists = false
		if table_count(sections) > 0 then
			if sections[image_type] and image_type == 'background' then
				return error('can only have 1 background!')
			elseif image_type == 'background' then 
				order = 0 
			end
			if sections[image_type] and image_type == 'logo' then
				return error('can only have 1 logo!')
			elseif image_type == 'logo' then 
				order = 1
			end
			if image_type == 'block' and table_count(sections.block) > 0 then
				for k, v in pairs(sections.block)  do
					if sections[image_type][k] and sections[image_type][k].order == order then
						order_exists = true
					end
				end
				if order_exists == false then
					o.order = order
				else
					return error('order magnitude ' .. order .. ' is already assigned!')
				end
			elseif image_type == 'block' and table_count(sections.block) == 0 then
				o.order = order
			end
		end
		if image_type == 'block' then
			local limit = 0
			if settings and settings.display and settings.display.block_limit then
				limit = tonumber(settings.display.block_limit) or 0
			end
			if limit > 0 and o.order and o.order > limit then
				return nil
			end
		end
		
		if image_type == 'background' then
			o.width = grid_columns() * grid_block_width()
			o.height = 1
			o.image_path = ''
			o.dragable = true
			o.draggable = true
			if is_flat_style() then
				o.alpha = 140
			else
				o.alpha = 0
			end
			o.red = 0
			o.green = 0 
			o.blue = 0
			o.type = image_type
			o.color = image_color
			o.name = (_addon and _addon.name or 'image') .. '_gensym_' .. tostring(t):sub(8) .. ('_%.8x'):format(16^8 * math.random()):sub(3)
			o.x = tonumber(settings.display.pos.x) or 0
			o.y = tonumber(settings.display.pos.y) or 0
		elseif image_type == 'logo' then
			o.width = grid_columns() * grid_block_width()
			o.height = 1
			o.type = image_type
			o.color = image_color
			o.image_path = windower.addon_path..'textures/'..settings.image_folder_name..'/'.. image_type ..'.png'
			o.name = (_addon and _addon.name or 'image') .. '_gensym_' .. tostring(t):sub(8) .. ('_%.8x'):format(16^8 * math.random()):sub(3)
			o.x = sections.background:position_x()
			o.y = sections.background:position_y()
			check_positions()
			
		elseif image_type == 'block' then
			if imageColors:contains(image_color) then
				local block_width = grid_block_width()
				local block_height = grid_block_height()
				local scale = block_width / 72
				o.width = block_width
				o.height = block_height
				o.type = image_type
				o.color = image_color
				o.image_path = windower.addon_path..'textures/'..settings.image_folder_name..'/'..image_color ..'.png'
				if is_flat_style() then
					o.alpha = 0
				end
				o.name = (_addon and _addon.name or 'image') .. '_gensym_' .. tostring(t):sub(8) .. ('_%.8x'):format(16^8 * math.random()):sub(3)
				o.x, o.y = get_position(o)
				o.text = {}
				
	
				local t1_scale = font_size_scale('label') * scale
				local t2_scale = font_size_scale('value') * scale
				local t1_size = math.max(6, math.floor(8 * t1_scale + 0.5))
				local t2_size = math.max(8, math.floor(11 * t2_scale + 0.5))
				local offset_x1 = math.max(1, math.floor(3 * scale + 0.5))
				local offset_y1 = math.max(1, math.floor(5 * scale + 0.5))
				local offset_x2 = math.max(1, math.floor(3 * scale + 0.5))
				local offset_y2 = math.max(1, math.floor(22 * scale + 0.5))
				o.text[1] = {name = 'text1'..o.name, text = text1, offset_x = offset_x1 , offset_y = offset_y1}
				
				windower.text.create(o.text[1].name)
				windower.text.set_text(o.text[1].name, o.text[1].text)
				--windower.text.set_color(o.text[1].name, 255, 0, 0, 0)
				windower.text.set_color(o.text[1].name, 255, 255,255,255)
				windower.text.set_font_size(o.text[1].name, t1_size)
				windower.text.set_visibility(o.text[1].name, true)
				local label_font = (settings and settings.display and settings.display.label_font) and settings.display.label_font or 'Tahoma'
				local value_font = (settings and settings.display and settings.display.value_font) and settings.display.value_font or 'Tahoma'
				windower.text.set_font(o.text[1].name, label_font) --'Verdana'
				windower.text.set_stroke_width(o.text[1].name, 0)
				windower.text.set_stroke_color(o.text[1].name, 255, 0, 0, 0)
				--windower.text.set_stroke_color(o.text[1].name, 255, 247,243,195)
				windower.text.set_location(o.text[1].name, o.text[1].offset_x + o.x, o.text[1].offset_y + o.y)
				windower.text.set_bold(o.text[1].name, true)
				
				--print(windower.text.get_extents(o.text[1].name))
				
				o.text[2] = {name = 'text2'..o.name, text = text2, offset_x = offset_x2 , offset_y = offset_y2}
				
				windower.text.create(o.text[2].name)
				windower.text.set_text(o.text[2].name, o.text[2].text)
				windower.text.set_bold(o.text[2].name, false)
				windower.text.set_color(o.text[2].name, 255, 255, 255, 255)
				windower.text.set_font_size(o.text[2].name, t2_size)
				windower.text.set_visibility(o.text[2].name, true)
				windower.text.set_font(o.text[2].name, value_font) --'Verdana'
				windower.text.set_stroke_width(o.text[2].name, 0)
				windower.text.set_stroke_color(o.text[2].name, 255, 0, 0, 0)
				windower.text.set_location(o.text[2].name, o.text[2].offset_x + o.x, o.text[2].offset_y + o.y)
				
			else
				return error('Wrong color type')
			end
		else
			return error('Wrong image type!')
		end

		windower.prim.create(o.name)
		windower.prim.set_color(o.name, o.alpha, o.red, o.green, o.blue)
		windower.prim.set_texture(o.name, o.image_path)
		windower.prim.set_fit_to_texture(o.name, o.fit)
		windower.prim.set_size(o.name, o.width, o.height)
		windower.prim.set_visibility(o.name, o.visible)
		windower.prim.set_position(o.name, o.x, o.y)
		
		return o
	end,
	
	-- Makes the primitive visible
	show = function(self)
		windower.prim.set_visibility(self.name, true)
		self.visible = true
	end,

	-- Makes the primitive invisible
	hide = function(self)
		windower.prim.set_visibility(self.name, false)
		self.visible = false
	end,
	
	-- Returns whether or not the image object is visible
	visible = function(self, visible)
		if visible == nil then
			return self.visible
		end
		windower.prim.set_visibility(self.name, visible)
	end,
	
	position = function(self, new_x, new_y)
		if new_x == nil then
			return self.x, self.y
		end
		self.x = new_x
		self.y = new_y
		windower.prim.set_position(self.name, new_x, new_y)
		if self.type == 'block' then
			windower.text.set_location(self.text[1].name, new_x + self.text[1].offset_x , new_y + self.text[1].offset_y)
			windower.text.set_location(self.text[2].name, new_x + self.text[2].offset_x , new_y + self.text[2].offset_y)
		end
	end,
	
	position_x = function(self, new_x)
		if new_x == nil then
			return self.x
		end
		self:position(new_x, self.y)
		if self.type == 'block' then
			windower.text.set_location(self.text[1].name, new_x + self.text[1].offset_x , self.y + self.text[1].offset_y)
			windower.text.set_location(self.text[2].name, new_x + self.text[2].offset_x , self.y + self.text[2].offset_y)
		end
	end,
	
	position_y = function(self, new_y)
		if new_y == nil then
			return self.y
		end
		self:position(self.x, new_y)
		if self.type == 'block' then
			windower.text.set_location(self.text[1].name, self.x + self.text[1].offset_x , new_y + self.text[1].offset_y)
			windower.text.set_location(self.text[2].name, self.x + self.text[2].offset_x , new_y + self.text[2].offset_y)
		end
	end,
	
	image_size = function(self, width, height)
		if width == nil then
			return self.width, self.height
		end

		windower.prim.set_size(self.name, width, height)
		self.width = width
		self.height = height
	end,
	
	image_width = function(self, width)
		if width == nil then
			return self.width
		end

		self:size(width, self.height)
	end,
	
	image_height = function(self, height)
		if height == nil then
			return self.height
		end

		self:size(self.width, height)
	end,
	
	get_extents = function(self)
		
		local ext_x = self.x + self.width
		local ext_y = self.y + self.height

		return ext_x, ext_y
	end,
	
	hover = function(self, mouse_x, mouse_y)
		if not self:visible() then
			return false
		end
		
		local x_bool = false
		local y_bool = false
		local pos_x, pos_y = self:position()
		pos_x = tonumber(pos_x) or 0
		pos_y = tonumber(pos_y) or 0
		local off_x, off_y = self:get_extents()
		
		if mouse_x >= pos_x and mouse_x <= (pos_x + self.width) then
			x_bool = true
			--log('x hit ' .. tostring(x_bool))
		end
		if mouse_y > pos_y and mouse_y < (pos_y + self.height) then
			y_bool = true
			--log('y hit ' .. tostring(y_bool))
		end
		if x_bool == true and y_bool == true then
			return true
		else
			return false
		end
		
	end,
	
	draggable = function(self, drag)
		if drag == nil then
			return self.draggable
		end

		self.draggable = drag
	end,
	
	image_color = function(self, red, green, blue)
		if red == nil then
			return self.red, self.green, self.blue
		end

		windower.prim.set_color(self.name, self.alpha, red, green, blue)
		self.red = red
		self.green = green
		self.blue = blue
	end,
	
	image_alpha = function(self, alpha)
		if alpha == nil then
			return self.alpha
		end

		windower.prim.set_color(self.name, alpha, self.red, self.green, self.blue)
		self.alpha = alpha
	end,
	
	pos_diff = function (self, t)
		local self_x, self_y = self:position()
		local bg_x, bg_y = t:position()
		
		return self_x - bg_x , self_y - bg_y
	end,
	
	delete = function(self)
		windower.prim.delete(self.name)
		for k, v in pairs(sections) do
			if k ~= 'block' then
				if v.name == self.name then
					sections[k] = nil
					check_positions()
				end
			else
				for i, j in pairs(v) do
					if j.name == self.name then	
						--notice('Delete '..k..' of color '..j.color.. '  '..j.name)
						windower.text.delete(self.text[1].name)
						windower.text.delete(self.text[2].name)
						sections[k][i] = nil
						check_positions()
					end
				end
			end
		end
	end,
	
}

--ImageBlock.mt.__index = ImageBlock
-- ImageBlock.mt.__newindex = function(self,k,v)
	-- error('cannot change '.. k.. ' to ' .. v.. ' in table ' ..tostring(self))
-- end

-- Handle drag and drop
windower.register_event('mouse', function(type, x, y, delta, blocked)
    if blocked then
        return
    end

    -- Mouse drag
    if type == 0 then
        if dragged then
			update_all(x - dragged.x, y - dragged.y, dragged.image )
			centre_all_text()
            dragged.image:position(x - dragged.x, y - dragged.y)
            return true
        end

    -- Mouse left click
    elseif type == 1 then
		if sections and sections.background and sections.background.draggable and sections.background:hover(x, y) then
			local pos_x, pos_y =sections.background:position()
			dragged = {image = sections.background, x = x - pos_x, y = y - pos_y}
			return true
		end
    -- Mouse left release
    elseif type == 2 then
        if dragged and sections and sections.background then
            dragged = nil
			settings.display.pos.x = tonumber(sections.background:position_x()) or settings.display.pos.x
			settings.display.pos.y = tonumber(sections.background:position_y()) or settings.display.pos.y
			settings:save('all')
            return true
        end
    end

    return false
end)

function update_all(x, y, background)
	local difx, dify = 0, 0
	
	if table_count(sections) > 0 then
		for k, v in pairs(sections) do
			if k ~= 'background' then
				if k == 'logo' then
					difx, dify = sections.logo:pos_diff(background)
					sections.logo:position(difx + x, dify + y)
				elseif k == 'block' then
					for i, j in pairs(v) do
						difx, dify = sections.block[i]:pos_diff(background)
						sections.block[i]:position(difx + x, dify + y)
					end
				end
			end
		end
	end
end

function check_positions()
	local x, y = 0, 0
	local max_columns = grid_columns()
	local has_logo = (settings.player.show_logo == true and sections.logo ~= nil)
	local min_rows = has_logo and 2 or 1
	local visible_block_count = 0
	for _, blk in pairs(sections.block) do
		if blk and blk.visible ~= false then
			visible_block_count = visible_block_count + 1
		end
	end
	local block_count = visible_block_count + (has_logo and 1 or 0)
	local grid = {}
	local block_width = grid_block_width()
	local block_height = grid_block_height()
	local added = {}
	--notice('----------------------------------------------------------------------')
	local highest_order = 0
	local order_exists = {}
	for k, v in pairs(sections.block) do
		if sections.block[k] and sections.block[k].visible ~= false and sections.block[k].order > highest_order then
			highest_order = sections.block[k].order
		end
	end
	
	for i = 1, highest_order do
		if sections.block[i] and sections.block[i].visible ~= false then	
			order_exists[i] = true
		else
			order_exists[i] = false
		end
	end
	
	if block_count > 0 and has_logo then min_rows = 2 end
	--print( (min_rows + math.floor((block_count - 1) / 4) ))
	for i = 1,  (min_rows + math.floor((block_count - 1) / max_columns) ) do
		grid[i] = {}
		for j = 1,  max_columns do
			grid[i][j] = {}
			grid[i][j]['empty'] = true
			grid[i][j]['image'] = {}
			if i == 1 and j < (max_columns + 1) and has_logo then
				grid[i][j]['empty'] = false
				grid[i][j]['image'] = sections.logo
			end
				if grid[i][j]['empty'] == true then
				for k, v in ipairs(order_exists) do
					if not added[k] and v then
						grid[i][j]['empty'] = false
						grid[i][j]['image'] = sections.block[k]
						sections.block[k]:position_x(((j - 1) * block_width) + sections.background:position_x())
						sections.block[k]:position_y(((i - 1) * block_height) + sections.background:position_y())
						added[k] = true
						break
					end
				end
				-- for k, v in pairs(sections.block) do
					-- if not added[k] then
						-- --log('order = '..v.order)
						-- grid[i][j]['empty'] = false
						-- grid[i][j]['image'] = sections.block[k]
						-- sections.block[k]:position_x(((j - 1) * block_width) + sections.background:position_x())
						-- sections.block[k]:position_y(((i - 1) * block_height) + sections.background:position_y())
						-- added[k] = true
						-- break
					-- end
				-- end
				end
			--notice(i, j, grid[i][j]['empty'] )	
		end
	end
	
	for i = 1,  (min_rows + math.floor((block_count - 1) / max_columns) ) do
		for j = 1,  max_columns do
			if grid[i][j]['empty'] == false then
				--notice(i, j, grid[i][j]['empty'], grid[i][j]['image'].type,  grid[i][j]['image'].color)
				sections.background:image_size((max_columns * block_width), (i * block_height))
			else
				--notice(i, j, grid[i][j]['empty'] )
			end
		end
	end
end

function get_position(this_image)
	local x, y = 0, 0
	local max_columns = grid_columns()
	local has_logo = (settings.player.show_logo == true and sections.logo ~= nil)
	local min_rows = has_logo and 2 or 1
	local visible_block_count = 0
	for _, blk in pairs(sections.block) do
		if blk and blk.visible ~= false then
			visible_block_count = visible_block_count + 1
		end
	end
	local block_count = visible_block_count + (has_logo and 1 or 0)
	local grid = {}
	local block_width = grid_block_width()
	local block_height = grid_block_height()
	local order_start = 2
	--notice('----------------------------------------------------------------------')
	local added = {}
	local highest_order = 0
	local order_exists = {}
	-- print(this_image.order)
	for k, v in pairs(sections.block) do
		if sections.block[k] and sections.block[k].visible ~= false and sections.block[k].order > highest_order then
			highest_order = sections.block[k].order
		end
	end
	if this_image.order > highest_order then highest_order = this_image.order end
	
	for i = 1, highest_order do
		if sections.block[i] and sections.block[i].visible ~= false then	
			order_exists[i] = true
		else
			order_exists[i] = false
		end
		if (this_image.order - 1) == i then
			order_exists[i] = true
		end
	end
	--table.vprint(order_exists)
	--table.rekey(order_exists)
	
	if block_count > 0 and has_logo then min_rows = 2 end
	--print( (min_rows + math.floor((block_count - 1) / 4) ))
	for i = 1,  (min_rows + math.floor((block_count - 1) / max_columns) ) do
		grid[i] = {}
		for j = 1,  max_columns do
			grid[i][j] = {}
			grid[i][j]['empty'] = true
			grid[i][j]['image'] = {}
			if i == 1 and j < (max_columns + 1) and has_logo then
				grid[i][j]['empty'] = false
				grid[i][j]['image'] = sections.logo
			end
			if grid[i][j]['empty'] == true then
				for k, v in ipairs(order_exists) do
					if not added[k] and v and (this_image.order - 1) ~= k then
						grid[i][j]['empty'] = false
						grid[i][j]['image'] = sections.block[k]
						sections.block[k]:position_x(((j - 1) * block_width) + sections.background:position_x())
						sections.block[k]:position_y(((i - 1) * block_height) + sections.background:position_y())
						added[k] = true
						break
					end
					if not added[k] and (this_image.order - 1) == k then
						added[k] = true
						break
					end
				end
			end
			--notice(i, j, grid[i][j]['empty'] )	
		end
	end
	
	-- for i = 1,  (min_rows + math.floor((block_count - 1) / 4) ) do
		-- for j = 1,  4 do
			-- if grid[i][j]['empty'] == false then
				-- notice(i, j, grid[i][j]['empty'], grid[i][j]['image'].type,  grid[i][j]['image'].color)
			-- else
				-- notice(i, j, grid[i][j]['empty'] )
			-- end
		-- end
	-- end
	
	local added_last = false
	
	if this_image then
		for i = 1,  (min_rows + math.floor((block_count - 1) / max_columns) ) do
			for j = 1,  max_columns do
				if grid[i][j]['empty'] == true and added_last  == false then
					added_last  = true
					grid[i][j]['empty'] = false
					x = ((j - 1) * block_width) + sections.background:position_x()
					y = ((i - 1) * block_height) + sections.background:position_y()
					--notice(i, j, grid[i][j]['empty'], this_image.type, this_image.color)
				end
				sections.background:image_size((max_columns * block_width), (i * block_height))
				--notice(i, j, grid[i][j]['empty'])
			end	
		end
		return x, y
	end
	
end

function centre_all_text()

--print(windower.text.get_extents(sections.block[1].text[1].name))

	for k, v in pairs(sections.block) do
		if sections.block[k] and sections.block[k].text and sections.block[k].text[1] and sections.block[k].text[2] then
			local block_width = grid_block_width()
			local width = windower.text.get_extents(sections.block[k].text[1].name) or 0
			local width2 = windower.text.get_extents(sections.block[k].text[2].name) or 0
			--x offset = 3
			local centre_of_block = block_width / 2
			local centre_of_text = width / 2
			local centre_of_text2 = width2 / 2
			local new_centre =  centre_of_block - centre_of_text
			local new_centre2 =  centre_of_block - centre_of_text2
			windower.text.set_location(sections.block[k].text[1].name, new_centre + sections.block[k].x , sections.block[k].text[1].offset_y + sections.block[k].y)
			windower.text.set_location(sections.block[k].text[2].name, new_centre2 + sections.block[k].x , sections.block[k].text[2].offset_y + sections.block[k].y)
		end
	end
end
