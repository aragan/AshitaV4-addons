return {

    -- =========================
    -- T1 / Atonement 1 (Rank 30)
    -- =========================
    [21431] = {["Attack"]=15,["STR"]=10,["DEX"]=10}, -- Coiste Bodhar :contentReference[oaicite:3]{index=3}
    [21432] = {["Avatar: Acc"]=30,["Avatar: MAcc"]=30,["Avatar: All Attr"]=15,["Avatar: Enmity"]=10}, -- Epitaph :contentReference[oaicite:4]{index=4}
    [21430] = {["Pet: Attack"]=15,["Attack"]=15,["Pet: All Attr"]=10}, -- Hesperiidae :contentReference[oaicite:5]{index=5}
    [21433] = {["Automaton: Acc"]=30,["Automaton: MAcc"]=30,["Automaton: RAcc"]=30,["Automaton: HP"]=60,["Automaton: SpecialAtkDmg%"]=5}, -- Neo Animator :contentReference[oaicite:6]{index=6}

    -- =========================
    -- T2 / Atonement 2 (Rank 30)
    -- =========================
    [21568] = {["DEF"]=30,["Waltz Potency%"]=10,["MDB"]=5}, -- Acrontica :contentReference[oaicite:7]{index=7}
    [26218] = {["WS Acc"]=15,["Attack"]=15,["SC Dmg%"]=5}, -- Beithir Ring :contentReference[oaicite:8]{index=8}
    [21926] = {["DEF"]=30,["Daken"]=10,["MEva"]=10}, -- Tsuru :contentReference[oaicite:9]{index=9}
    [26116] = {["Acc"]=15,["Attack"]=15,["STP"]=5}, -- Schere Earring :contentReference[oaicite:10]{index=10}
    [26362] = {["RAcc"]=15,["RAtk"]=15,["Enmity"]=-5}, -- Tellen Belt :contentReference[oaicite:11]{index=11}
    [26363] = {["MAcc"]=15,["Enfeeb Skill"]=15,["Enmity"]=-5}, -- Obstin. Sash :contentReference[oaicite:12]{index=12}


    -- =========================
    -- T4 / Atonement 4 (Nyame) - Rank 30 Path B
    -- =========================

    [23761] = {["Attack"]=30,["Ranged Attack"]=30,["Weapon skill damage"]=10,["Double Attack"]=4,["Accuracy"]=5,["Ranged Accuracy"]=5}, -- Nyame Helm (Path B, Rank 25)
    [23768] = {["Attack"]=30,["Ranged Attack"]=30,["Weapon skill damage"]=12,["Double Attack"]=5,["STR"]=5,["VIT"]=5}, -- Nyame Mail (Path B, Rank 25)
    [23775] = {["Attack"]=30,["Ranged Attack"]=30,["Weapon skill damage"]=10,["Double Attack"]=4,["VIT"]=10}, -- Nyame Gauntlets (Path B, Rank 25)
    [23782] = {["Attack"]=30,["Ranged Attack"]=30,["Weapon skill damage"]=11,["Double Attack"]=5,["STR"]=10}, -- Nyame Flanchard (Path B, Rank 25)
    [23789] = {["Attack"]=30,["Ranged Attack"]=30,["Weapon skill damage"]=10,["Double Attack"]=4,["Accuracy"]=8,["Ranged Accuracy"]=8}, -- Nyame Sollerets (Path B, Rank 25)
 -- =========================
    -- Gleti's Set (Ngai) - Rank 30
    -- =========================
    [23756] = {["Attack"]=30,["Counter"]=10,["Accuracy"]=15,["Magic Accuracy"]=15,["Regen"]=3}, -- Gleti's Mask
    [23763] = {["Attack"]=30,["Double Attack"]=10,["Accuracy"]=15,["Magic Accuracy"]=15,["Occ. resists status ailments"]=10}, -- Gleti's Cuirass
    [23770] = {["Attack"]=30,["Store TP"]=8,["Accuracy"]=15,["Magic Accuracy"]=15,["DEX"]=5}, -- Gleti's Gauntlets
    [23777] = {["Attack"]=30,["Subtle Blow"]=15,["Accuracy"]=15,["Magic Accuracy"]=15,["Triple Attack"]=5}, -- Gleti's Breeches
    [23784] = {["Attack"]=30,["Evasion"]=15,["Accuracy"]=15,["Magic Accuracy"]=15,["STR"]=5}, -- Gleti's Boots

    -- =========================
    -- Sakpata's Set (Kalunga) - Rank 30
    -- =========================
    [23757] = {["Attack"]=30,["Double Attack dmg"]=15,["Accuracy"]=15,["Magic Accuracy"]=15,["Cure potency"]=5}, -- Sakpata's Helm
    [23764] = {["Attack"]=30,["Resist all status ailments"]=15,["Accuracy"]=15,["Magic Accuracy"]=15,["Critical hit rate"]=5}, -- Sakpata's Plate
    [23771] = {["Attack"]=30,["Store TP"]=8,["Accuracy"]=15,["Magic Accuracy"]=15,["VIT"]=5}, -- Sakpata's Gauntlets
    [23778] = {["Attack"]=30,["Skillchain Damage"]=15,["Accuracy"]=15,["Magic Accuracy"]=15,["STR"]=5}, -- Sakpata's Cuisses
    [23785] = {["Attack"]=30,["Subtle Blow"]=15,["Accuracy"]=15,["Magic Accuracy"]=15,["Block rate"]=5}, -- Sakpata's Leggings

    -- =========================
    -- Mpaca's Set (Arebati) - Rank 30
    -- =========================
    [23758] = {["Attack"]=30,["Skillchain Damage"]=15,["Accuracy"]=15,["Magic Accuracy"]=15,["Double Attack"]=5}, -- Mpaca's Cap
    [23765] = {["Attack"]=30,["Store TP"]=8,["Accuracy"]=15,["Magic Accuracy"]=15,["Regen"]=3}, -- Mpaca's Doublet
    [23772] = {["Attack"]=30,["Triple Attack dmg"]=10,["Accuracy"]=15,["Magic Accuracy"]=15,["DEX"]=5}, -- Mpaca's Gloves
    [23779] = {["Attack"]=30,["PDL"]=8,["Accuracy"]=15,["Magic Accuracy"]=15,["Magic Evasion"]=10}, -- Mpaca's Hose
    [23786] = {["Attack"]=30,["Magic Atk. Bonus"]=45,["Accuracy"]=15,["Magic Accuracy"]=15,["AGI"]=5}, -- Mpaca's Boots

    -- =========================
    -- Agwu's Set (Ongo) - Rank 30
    -- =========================
    [23759] = {["Magic Atk. Bonus"]=25,["Magic Damage"]=15,["Accuracy"]=15,["Magic Accuracy"]=15,["Enmity"]=-5}, -- Agwu's Cap
    [23766] = {["Magic Atk. Bonus"]=25,["Enmity"]=-8,["Accuracy"]=15,["Magic Accuracy"]=15,["Magic Damage"]=10}, -- Agwu's Robe
    [23773] = {["Magic Atk. Bonus"]=25,["Magic Burst Damage II"]=6,["Accuracy"]=15,["Magic Accuracy"]=15,["MND"]=5}, -- Agwu's Gages
    [23780] = {["Magic Atk. Bonus"]=25,["DT"]=-10,["Accuracy"]=15,["Magic Accuracy"]=15,["INT"]=5}, -- Agwu's Slops
    [23787] = {["Magic Atk. Bonus"]=25,["Drain/Aspir potency"]=15,["Accuracy"]=15,["Magic Accuracy"]=15,["SIRD"]=10}, -- Agwu's Pigaches
}
