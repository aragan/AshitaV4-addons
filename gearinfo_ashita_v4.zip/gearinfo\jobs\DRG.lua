return {
    code = 'DRG',
    extra2 = false,
    dd_melee = true,
    extra5 = false,
    extra_preset = {
        'show_petdt',
    },
}
