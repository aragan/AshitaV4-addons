local timer = {};

function timer.time(func, ...)
    local started = os.clock();
    local result = { func(...) };
    return os.clock() - started, (table.unpack or unpack)(result);
end

return timer;
