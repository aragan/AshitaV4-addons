addon.name      = 'gearinfo';
addon.author    = 'Sebyg666; Converted by Aragan';
addon.version   = '4.0.0 - version gate of transformers coming';
addon.desc      = 'Full Ashita v4 port of GearInfo.';
addon.link      = 'https://github.com/aragan/AshitaV4-addons';

require('common');

package.path = addon.path .. '?.lua;' .. addon.path .. '?\\init.lua;' .. package.path;

local compat = require('ashita_compat');
compat.initialize();

local ok, err = xpcall(function ()
    dofile(addon.path .. 'GearInfo_core.lua');
end, debug.traceback);

if (not ok) then
    compat.shutdown();
    print('[GearInfo] Failed to load GearInfo core: ' .. tostring(err));
    error(err);
end

compat.start();
