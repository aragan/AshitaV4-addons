return {
    code = 'GEO',
    extra2 = true,
    dd_melee = false,
    extra5 = false,
    extra_preset = {
        'show_ied',
        'show_pr',
        'show_petdt',
        'show_fc',
        'show_conserve_mp',
        'show_sird',
        'show_magic_damage',
        'show_mab',
        'show_mbd',
    },
}
