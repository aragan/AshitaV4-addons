# GearInfo for Ashita v4

Full Ashita v4 port of the Windower GearInfo addon.

- Original addon: Sebyg666
- Ashita v4 port and Aragan data: Aragan
- Version: 4.0.0
- Discord: https://discord.gg/TskRzqGUMG
- Ashita v4 addons: https://github.com/aragan/AshitaV4-addons

## Installation

1. Copy the `gearinfo` folder to:
   `Ashita-v4\addons\gearinfo`
2. Start Ashita v4 and log in to FFXI.
3. Load the addon:
   `/addon load gearinfo`
4. Display the command list:
   `/gi help`

To load it automatically, add this line to the Ashita boot configuration:

```text
/addon load gearinfo
```

## Configuration

GearInfo reads the existing XML settings when present and creates an Ashita JSON
settings file beside it. Gear data, job files, augment databases, textures, and
images are bundled in this folder. Windower and GearSwap are not required.

The original GearInfo commands are available through `/gi` and `/gearinfo`.
Examples:

```text
/gi help
/gi show
/gi hide
/gi reset
```

## Notes

- The HUD can be moved using the same GearInfo mouse behavior.
- Equipment, augments, buffs, job data, action packets, party data, haste and
  dual-wield calculations are adapted to Ashita v4 interfaces.
- Keep the entire folder structure. The `res`, `jobs`, `aug_gears`, `textures`,
  `images`, and bundled compatibility libraries are required.
