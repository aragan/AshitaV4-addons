return {
    [11575]={
        ["Aug2"]="DEX+12", 
        ["Aug3"]="Phalanx +4", 
        ["Aug1"]="\"Mag.Atk.Bns.\"+13"
    }, 
    [13658]={
        ["Aug1"]="Path: A"
    }, 
    [16259]={
        ["Aug2"]="\"Cure\" spellcasting time -7%", 
        ["Aug3"]="Magic dmg. taken -3", 
        ["Aug1"]="Healing magic skill +20"
    }, 
    [26245]={
        ["Aug1"]="Path: A"
    }, 
    [26246]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [26247]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="STR+10"
    }, 
    [26248]={
        ["Aug1"]="Path: B"
    }, 
    [26249]={
        ["Aug1"]="Path: A"
    }, 
    [26250]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [26251]={
        ["Aug2"]="Attack+20", 
        ["Aug3"]="\"Subtle Blow\"+8", 
        ["Aug1"]="Accuracy+20"
    }, 
    [26252]={
        ["Aug1"]="Path: A"
    }, 
    [26253]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="STR+10"
    }, 
    [26254]={
        ["Aug1"]="Path: A"
    }, 
    [26255]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [26256]={
        ["Aug2"]="AGI+12", 
        ["Aug3"]="Accuracy+20", 
        ["Aug1"]="DEX+12"
    }, 
    [26257]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [26258]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Attack+10"
    }, 
    [26259]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [26260]={
        ["Aug2"]="Eva.+20 /Mag. Eva.+20", 
        ["Aug3"]="Pet: Magic Damage+10", 
        ["Aug4"]="Pet: Haste+10", 
        ["Aug1"]="Pet: M.Acc.+20 Pet: M.Dmg.+20"
    }, 
    [26261]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [26262]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [26263]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="STR+10"
    }, 
    [26264]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [26265]={
        ["Aug1"]="Path: A"
    }, 
    [26266]={
        ["Aug2"]="Mag. Acc.+10", 
        ["Aug3"]="\"Fast Cast\"+3", 
        ["Aug1"]="MP+20"
    }, 
    [26267]={
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug3"]="\"Store TP\"+10", 
        ["Aug1"]="DEX+20"
    }, 
    [26269]={
        ["Aug2"]="Pet: \"Store TP\"+11", 
        ["Aug3"]="Pet: CHR+2", 
        ["Aug4"]="Pet: \"Mag.Atk.Bns.\"+8", 
        ["Aug1"]="Pet: Accuracy+9 Pet: Rng. Acc.+9"
    }, 
    [26270]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [26274]={
        ["Aug2"]="\"Store TP\"+5", 
        ["Aug3"]="\"Subtle Blow\"+8", 
        ["Aug1"]="HP+65"
    }, 
    [27595]={
        ["Aug1"]="Path: A"
    }, 
    [27596]={
        ["Aug2"]="\"Dual Wield\"+5", 
        ["Aug3"]="Phalanx +3", 
        ["Aug1"]="Accuracy+20"
    }, 
    [27610]={
        ["Aug1"]="Path: A"
    }, 
    [27615]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [27620]={
        ["Aug1"]="Path: A"
    }, 
    [28621]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [28623]={
        ["Aug2"]="Enmity+3", 
        ["Aug3"]="Phalanx +5", 
        ["Aug1"]="VIT+1"
    }, 
    [28624]={
        ["Aug2"]="Dark magic skill +10", 
        ["Aug3"]="\"Drain\" and \"Aspir\" potency +18", 
        ["Aug1"]="Attack+10"
    }, 
    [28632]={
        ["Aug2"]="INT+7", 
        ["Aug3"]="MND+7", 
        ["Aug1"]="Mag. Acc.+15"
    }, 
    [28634]={
        ["Aug2"]="Pet: TP Bonus+480", 
        ["Aug1"]="STR+1"
    }, 
    [28637]={
        ["Aug2"]="Mag. Acc.+10", 
        ["Aug3"]="\"Fast Cast\"+3", 
        ["Aug1"]="MP+20"
    }
}