local bit = require('bit');
local manager = AshitaCore:GetResourceManager();
local resources = {};

local slots = {
    [0] = 'Main', [1] = 'Sub', [2] = 'Range', [3] = 'Ammo',
    [4] = 'Head', [5] = 'Body', [6] = 'Hands', [7] = 'Legs',
    [8] = 'Feet', [9] = 'Neck', [10] = 'Waist', [11] = 'Left Ear',
    [12] = 'Right Ear', [13] = 'Left Ring', [14] = 'Right Ring', [15] = 'Back',
};

local bags = {
    [0] = 'Inventory', [1] = 'Safe', [2] = 'Storage', [3] = 'Temporary',
    [4] = 'Locker', [5] = 'Satchel', [6] = 'Sack', [7] = 'Case',
    [8] = 'Wardrobe', [9] = 'Safe 2', [10] = 'Wardrobe 2',
    [11] = 'Wardrobe 3', [12] = 'Wardrobe 4', [13] = 'Wardrobe 5',
    [14] = 'Wardrobe 6', [15] = 'Wardrobe 7', [16] = 'Wardrobe 8',
};

local skill_names = {
    [1]='Hand-to-Hand',[2]='Dagger',[3]='Sword',[4]='Great Sword',[5]='Axe',
    [6]='Great Axe',[7]='Scythe',[8]='Polearm',[9]='Katana',[10]='Great Katana',
    [11]='Club',[12]='Staff',[22]='Automaton Melee',[23]='Automaton Ranged',
    [24]='Automaton Magic',[25]='Archery',[26]='Marksmanship',[27]='Throwing',
    [28]='Guarding',[29]='Evasion',[30]='Shield',[31]='Parrying',
    [32]='Divine Magic',[33]='Healing Magic',[34]='Enhancing Magic',
    [35]='Enfeebling Magic',[36]='Elemental Magic',[37]='Dark Magic',
    [38]='Summoning Magic',[39]='Ninjutsu',[40]='Singing',[41]='Stringed Instrument',
    [42]='Wind Instrument',[43]='Blue Magic',[44]='Geomancy',[45]='Handbell',
};

local function text(value)
    if (value == nil) then return ''; end
    return tostring(value):gsub('%z+$', '');
end

local function lang(array)
    if (array == nil) then return ''; end
    local ok, value = pcall(function () return array[1] or array[0]; end);
    return ok and text(value) or '';
end

local function mask_table(mask, first, last)
    local result = {};
    mask = tonumber(mask) or 0;
    for id = first, last do
        local shift = id - first;
        if (bit.band(mask, bit.lshift(1, shift)) ~= 0) then result[id] = true; end
    end
    return result;
end

local states = setmetatable({}, { __mode = 'k' });
local methods = {};
function methods:with(field, value)
    local state = states[self];
    if (field == 'id') then return self[tonumber(value)]; end
    local key = tostring(value or '');
    local lower = key:lower();
    local found = state.names[lower];
    if (found ~= nil) then return found; end
    if (state.finder ~= nil) then
        found = state.finder(key);
        if (found ~= nil) then
            state.names[lower] = found;
            state.names[(found.en or found.name or ''):lower()] = found;
        end
        return found;
    end
    for _, entry in pairs(state.cache) do
        local candidate = entry[field] or ((field == 'english') and entry.en);
        if (candidate == value or (field == 'enl' and tostring(candidate):lower() == lower)) then return entry; end
    end
    return nil;
end

function methods:type(_)
    return self;
end

local function collection(builder, finder)
    local value = {};
    states[value] = { cache={}, names={}, builder=builder, finder=finder };
    return setmetatable(value, {
        __index = function(self, key)
            if (methods[key] ~= nil) then return methods[key]; end
            if (type(key) ~= 'number') then return nil; end
            local state = states[self];
            if (state.cache[key] == nil) then
                local entry = state.builder(key);
                if (entry ~= nil) then
                    state.cache[key] = entry;
                    state.names[(entry.en or entry.name or ''):lower()] = entry;
                end
            end
            return state.cache[key];
        end,
        __pairs = function(self) return next, states[self].cache, nil; end,
    });
end

local function build_item(id)
    local item = manager:GetItemById(id);
    if (item == nil) then return nil; end
    local name = lang(item.Name);
    local category = 'Item';
    if (item.Type == 4) then category = 'Weapon';
    elseif (item.Type == 5) then category = 'Armor'; end
    return {
        id=id, en=name, enl=name:lower(), name=name,
        description=lang(item.Description), category=category,
        jobs=mask_table(item.Jobs, 1, 22), slots=mask_table(item.Slots, 0, 15),
        level=tonumber(item.Level) or 0, item_level=tonumber(item.ItemLevel) or 0,
        superior_level=tonumber(item.SuperiorLevel) or 0,
        skill=tonumber(item.Skill) or 0, damage=tonumber(item.Damage) or 0,
        delay=tonumber(item.Delay) or 0, shield_size=tonumber(item.ShieldSize) or 0,
        type=tonumber(item.Type) or 0,
    };
end

resources.items = collection(build_item, function(name)
    local ok, item = pcall(manager.GetItemByName, manager, name, 0);
    return ok and item and build_item(item.Id) or nil;
end);

resources.item_descriptions = collection(function(id)
    local item = manager:GetItemById(id);
    if (item == nil) then return nil; end
    return { id=id, en=lang(item.Description), name=lang(item.Description) };
end);

resources.jobs = collection(function(id)
    local abbr = text(manager:GetString('jobs.names_abbr', id));
    if (abbr == '') then return nil; end
    local name = text(manager:GetString('jobs.names', id));
    return { id=id, en=name, english=name, ens=abbr, name=name };
end);

resources.skills = collection(function(id)
    local name = skill_names[id] or text(manager:GetString('skills.names', id));
    if (name == '') then return nil; end
    return { id=id, en=name, english=name, name=name };
end);

resources.slots = collection(function(id)
    local name = slots[id];
    if (name == nil) then return nil; end
    return { id=id, en=name, name=name };
end);

resources.bags = {};
for id, name in pairs(bags) do resources.bags[id] = { id=id, en=name, name=name }; end

resources.buffs = collection(function(id)
    local name = text(manager:GetString('buffs.names', id));
    if (name == '') then return nil; end
    return { id=id, en=name, english=name, name=name };
end, function(name)
    local lower = tostring(name or ''):lower();
    for id = 0, 1023 do
        local entry = resources.buffs[id];
        if (entry ~= nil and entry.en:lower() == lower) then return entry; end
    end
    return nil;
end);

local function build_string_resource(group, id)
    local name = text(manager:GetString(group, id));
    if (name == '') then return nil; end
    return { id=id, en=name, english=name, name=name };
end

resources.races = collection(function(id)
    return build_string_resource('races.names', id)
        or build_string_resource('races', id);
end);

resources.zones = collection(function(id)
    return build_string_resource('zones.names', id)
        or build_string_resource('zones', id);
end);

local function build_spell(id)
    local spell = manager:GetSpellById(id);
    if (spell == nil) then return nil; end
    local name = lang(spell.Name);
    return {
        id=tonumber(spell.Id) or id, index=tonumber(spell.Index) or id,
        en=name, english=name, name=name, type=tonumber(spell.Type) or 0,
        skill=tonumber(spell.Skill) or 0, element=tonumber(spell.Element) or 0,
        mp_cost=tonumber(spell.ManaCost) or 0,
    };
end

resources.spells = collection(build_spell, function(name)
    local ok, spell = pcall(manager.GetSpellByName, manager, name, 0);
    return ok and spell and build_spell(spell.Id) or nil;
end);

local function build_ability(id)
    local ability = manager:GetAbilityById(id);
    if (ability == nil) then return nil; end
    local name = lang(ability.Name);
    return {
        id=tonumber(ability.Id) or id, en=name, english=name, name=name,
        type=tonumber(ability.Type) or 0, element=tonumber(ability.Element) or 0,
    };
end

resources.job_abilities = collection(build_ability, function(name)
    local ok, ability = pcall(manager.GetAbilityByName, manager, name, 0);
    return ok and ability and build_ability(ability.Id) or nil;
end);

return resources;
