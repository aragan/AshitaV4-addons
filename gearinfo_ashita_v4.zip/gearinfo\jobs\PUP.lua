return {
    code = 'PUP',
    extra2 = false,
    dd_melee = true,
    extra5 = false,
    extra_preset = {
        'show_pethaste',
        'show_petdt',
        'show_petpdt',
        'show_petmdt',
        'show_pr',
        'show_pmacc',
        'show_pacc',
        'show_pda',
        'show_patt',
        'show_pmab',
    },
    default_overrides = {
        show_pdl = false,
        show_sc_bonus = false,
        show_sc_damage = false,
    },
}
