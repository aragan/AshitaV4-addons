local action = {};

function action.parse(packet)
    local result = {};
    if (type(packet) ~= 'string' or packet:byte(1) ~= 0x28) then return result; end
    local bytes = packet:totable();
    result.size = ashita.bits.unpack_be(bytes, 32, 8);
    result.actor_id = ashita.bits.unpack_be(bytes, 40, 32);
    result.target_count = ashita.bits.unpack_be(bytes, 72, 10);
    result.type = ashita.bits.unpack_be(bytes, 82, 4);
    result.category = result.type;
    result.param = ashita.bits.unpack_be(bytes, 86, 16);
    result.unknown = ashita.bits.unpack_be(bytes, 102, 16);
    result.recast = ashita.bits.unpack_be(bytes, 118, 32);
    result.targets = {};

    local offset = 150;
    for _ = 1, result.target_count do
        local target = {
            id = ashita.bits.unpack_be(bytes, offset, 32),
            action_count = ashita.bits.unpack_be(bytes, offset + 32, 4),
            actions = {},
        };
        offset = offset + 36;
        for _ = 1, target.action_count do
            local entry = {
                reaction = ashita.bits.unpack_be(bytes, offset, 5),
                animation = ashita.bits.unpack_be(bytes, offset + 5, 11),
                effect = ashita.bits.unpack_be(bytes, offset + 16, 5),
                stagger = ashita.bits.unpack_be(bytes, offset + 21, 6),
                param = ashita.bits.unpack_be(bytes, offset + 27, 17),
                message = ashita.bits.unpack_be(bytes, offset + 44, 10),
                unknown = ashita.bits.unpack_be(bytes, offset + 54, 31),
            };
            entry.has_add_effect = ashita.bits.unpack_be(bytes, offset + 85, 1) == 1;
            offset = offset + 86;
            if (entry.has_add_effect) then
                entry.add_effect_animation = ashita.bits.unpack_be(bytes, offset, 6);
                entry.add_effect_effect = ashita.bits.unpack_be(bytes, offset + 6, 4);
                entry.add_effect_param = ashita.bits.unpack_be(bytes, offset + 10, 17);
                entry.add_effect_message = ashita.bits.unpack_be(bytes, offset + 27, 10);
                offset = offset + 37;
            end
            entry.has_spike_effect = ashita.bits.unpack_be(bytes, offset, 1) == 1;
            offset = offset + 1;
            if (entry.has_spike_effect) then
                entry.spike_effect_animation = ashita.bits.unpack_be(bytes, offset, 6);
                entry.spike_effect_effect = ashita.bits.unpack_be(bytes, offset + 6, 4);
                entry.spike_effect_param = ashita.bits.unpack_be(bytes, offset + 10, 14);
                entry.spike_effect_message = ashita.bits.unpack_be(bytes, offset + 24, 10);
                offset = offset + 34;
            end
            table.insert(target.actions, entry);
        end
        table.insert(result.targets, target);
    end
    return result;
end

return action;
