local logger = {};

local function emit(_, value)
    local text = tostring(value or '');
    print(string.format('[GearInfo] %s', text));
end

function logger.log(value) emit('message', value); end
function logger.notice(value) emit('message', value); end
function logger.warning(value) emit('warning', value); end
function logger.error(value) emit('error', value); end
function logger.debug(value) emit('message', value); end

_G.log = logger.log;
_G.notice = logger.notice;
_G.warning = logger.warning;
_G.debug = logger.debug;

return logger;
