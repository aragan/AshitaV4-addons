return {
    code = 'SAM',
    extra2 = false,
    dd_melee = true,
    extra5 = false,
    extra_preset = {
        'show_zanshin',
        'show_tpb',
        'show_mab',
        'show_macc',
    },
}
