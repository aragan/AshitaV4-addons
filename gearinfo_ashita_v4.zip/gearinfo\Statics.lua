
player = windower.ffxi.get_player()
player.equipment = T{}
player.stats = T{STR = 0, DEX = 0, VIT = 0, AGI = 0, INT = 0, MND = 0, CHR = 0}
player.skill = player.skills
player_base_skills = player.skills
player.is_moving = false
player.position = T{x = 0, y = 0, x = 0} 
buff = 0
full_gear_table_from_file = T{}
Buffs_inform = {		['delay'] = 0,['damage'] = 0,
								['HP'] = 0,['MP'] = 0,
								['STR'] = 0,['DEX'] = 0,['VIT'] = 3,['AGI'] = 0,['INT'] = 0,['MND'] = 0,['CHR'] = 0,
								['Accuracy'] = 0, ['Ranged Accuracy'] = 0, 
								['Attack'] = 0, ['Attack perc'] = 0,
								['Evasion'] = 0,['DEF'] = 0,['Defence perc'] = 0,
								['Magic Accuracy'] = 0, ['Magic Atk. Bonus'] = 0,
								['Magic Evasion'] = 0,['Magic Def. Bonus'] = 0, ['Magic Damage'] = 0,
								['g_haste']=0,['ma_haste'] = 0,['ja_haste'] = 0,
								['PDT'] = 0,['MDT'] = 0,['BDT'] = 0,['DT'] = 0,['MDT2'] = 0,['PDT2'] = 0,
								['Store TP'] = 0,['Dual Wield'] = 0 ,['Fast Cast'] = 0 ,['Martial Arts'] = 0,
								['Regen'] = 0, ['Regain'] = 0, ['Refresh'] = 0, ['Enmity'] = 0, ['Parrying skill'] = 0,
								["Double Attack"] = 0,["Tripple Attack"] = 0,['Quadruple Attack'] = 0,
								["Critical hit rate"] = 0,["Critical hit damage"] = 0,["Subtle Blow"] = 0,["Subtle Blow II"] = 0,
								["Counter"] = 0, ["Conserve MP"] = 0,
								["Treasure Hunter"] = 0,
								["Fast Cast"] = 0,
								["Cure potency"] = 0, ["Cure Potency"] = 0,
								["Cure potency II"] = 0, ["Cure Potency II"] = 0,
								["Enemy critical hit rate"] = 0,
								["Waltz"] = 0, ["Waltz potency"] = 0,
								["Block rate"] = 0,
								["Zanshin"] = 0,
								["TP Bonus"] = 0,
								["Killer"] = 0, ["Killer effects"] = 0,
								["Samba"] = 0,
								["Healing Magic skill"] = 0,
								["Phalanx"] = 0,
								["Snapshot"] = 0,
								["Rapid Shot"] = 0,
								["Elemental magic casting time"] = 0,
								["Inquartata"] = 0,
								["Enhancing magic effect duration"] = 0,
								["Steal"] = 0,
								["Sneak Attack"] = 0,
								["Trick Attack"] = 0,
								["All songs"] = 0,
								["Song effect duration"] = 0,
								["Song spellcasting time"] = 0,
								["Pet: Regen"] = 0,
								["Pet: Damage Taken"] = 0,
								["Pet: Physical Damage Taken"] = 0,
								["Pet: Magic Damage Taken"] = 0,
								["Pet: Haste"] = 0,
								["Indicolure effect duration"] = 0,
								["Blood Pact Delay"] = 0,
								["Blood Pact Delay II"] = 0,
								["Blood Pact Damage"] = 0,
								["Avatar Perpetuation Cost"] = 0,
								["Pet: Magic Atk. Bonus"] = 0,
								["Pet: Attack"] = 0,
								["Pet: Double Attack"] = 0,
								["Pet: Accuracy"] = 0,
								["Pet: Magic Accuracy"] = 0,
								["Summoning Magic skill"] = 0,
								["Pet: Blood Pact Damage"] = 0,
								["Pet: Magic Damage"] = 0,
								["Cursna"] = 0,
								}
Geo_buffs = {
	{id=539,en="Regen",							},
	{id=541,en="Refresh",						},
	{id=580,en="Haste",							},
	{id=542,en="STR Boost",					},
	{id=543,en="DEX Boost",					},
	{id=544,en="VIT Boost",					},
	{id=545,en="AGI Boost",					},
	{id=546,en="INT Boost",					},
	{id=547,en="MND Boost",					},
	{id=548,en="CHR Boost",					},
	{id=549,en="Attack Boost",				},
	{id=550,en="Defense Boost",				},
	{id=551,en="Magic Atk. Boost",			},
	{id=552,en="Magic Def. Boost",			},
	{id=553,en="Accuracy Boost",			},
	{id=554,en="Evasion Boost",				},
	{id=555,en="Magic Acc. Boost",			},
	{id=556,en="Magic Evasion Boost",	},
}
ele_to_stat = {
	[0] = {id=0,en="STR"},
	[1] = {id=1,en="INT"},
	[2] = {id=2,en="AGI"},
	[3] = {id=3,en="VIT"},
	[4] = {id=4,en="DEX"},
	[5] = {id=5,en="MND"},
	[6] = {id=6,en="CHR"},
	[7] = {id=7,en={[1]="STR",[2]="INT",[3]="AGI",[4]="VIT",[5]="DEX",[6]="MND",[7]="CHR"}},
}
Gear_info = T{}
member_table = T{}
seen_0x063_type9 = false
delay_0x063_v9 = false
debug_mode = false
party_from_packet = {}

_ExtraData = {
        player = {buff_details = {}},
        pet = {},
        world = {in_mog_house = false,conquest=false},
    }

old_inform = {}
manual_stp = 0
manual_dw = 0
manual_ghaste = 0
manual_mhaste = 0
manual_jahaste = 0
manual_dw_needed = 0
manual_bard_duration_bonus = 0
manual_COR_bonus = 0
manual_GEO_bonus  = 0
manual_hide = false
WSTP = 0
update_gs = true
show_total_haste = true
show_tp_Stuff = true
show_acc_Stuff = true
old_DW_needed = 0
DW = false
dancer_main = false
Crooked_cards = {name = '', bool = false}
__raw = {lower = string.lower, upper = string.upper,}

function to_windower_api(str)
    return __raw.lower(str:gsub(' ','_'))
end
							
defaults = {}
defaults.player = {}
defaults.player.show_logo = true
defaults.player.show_total_haste = true
defaults.player.show_tp_Stuff = true
defaults.player.show_acc_Stuff = false
defaults.player.show_dt_Stuff = false
    -- DT contribution switches:
    -- pdt_include_dt : DT added into PDT display
    -- dt_include_dt  : DT added into MDT/BDT display
    defaults.player.pdt_include_dt = false
    defaults.player.dt_include_dt = false
defaults.player.auto_parse_gearswap = false
defaults.player.safe_mode = false
defaults.player.show_att_Stuff = false
defaults.player.show_Evasion = false
defaults.player.show_Defence = false
-- Prefer direct in-game Attack/Defense values when available (toggle via //gi real).
defaults.player.use_real_att_def = true
defaults.player.show_STP = false
defaults.player.show_DW_Stuff = false
defaults.player.show_MA_Stuff = false
defaults.player.show_qa_da_ta = false
defaults.player.show_total_da_ta_qa = false
defaults.player.show_sc_bonus = false
defaults.player.show_sc_damage = false
defaults.player.show_mab = false
defaults.player.show_mbd = false
defaults.player.show_mbd2 = false
defaults.player.show_pdl = false
defaults.player.show_sird = false
defaults.player.show_int = false
defaults.player.show_macc = false
defaults.player.show_regen = false
defaults.player.show_regain = false
defaults.player.show_refresh = false
defaults.player.show_parry = false
defaults.player.show_enmity = false
    -- Default: show full stats. Aug-only should be enabled manually via //gi show augonly.
    defaults.player.show_aug_only = false
defaults.player.show_crit_rate = false
defaults.player.show_crit_damage = false
defaults.player.show_subtle_blow = false
defaults.player.show_subtle_blow_ii = false
defaults.player.show_magic_damage = false
defaults.player.show_magic_def_bonus = false
defaults.player.show_magic_evasion = false
defaults.player.show_counter = false
defaults.player.show_conserve_mp = false
defaults.player.show_stats = false
defaults.player.show_th = false
defaults.player.show_fc = false
defaults.player.show_cp = false
defaults.player.show_cp2 = false
defaults.player.show_echr = false
defaults.player.show_waltz = false
defaults.player.show_br = false
defaults.player.show_zanshin = false
defaults.player.show_tpb = false
defaults.player.show_killer = false
defaults.player.show_samba = false
defaults.player.show_hms = false
defaults.player.show_phalanx = false
defaults.player.show_qc = false
defaults.player.show_cst = false
defaults.player.show_hmct = false
defaults.player.show_snapshot = false
defaults.player.show_rapid_shot = false
defaults.player.show_emct = false
defaults.player.show_inq = false
defaults.player.show_emed = false
defaults.player.show_steal = false
defaults.player.show_sa = false
defaults.player.show_ta = false
defaults.player.show_allsongs = false
defaults.player.show_sed = false
defaults.player.show_sst = false
defaults.player.show_pr = false
defaults.player.show_petdt = false
defaults.player.show_ied = false
defaults.player.show_petpdt = false
defaults.player.show_petmdt = false
defaults.player.show_pethaste = false
defaults.player.show_bpd = false
defaults.player.show_bpd2 = false
defaults.player.show_bpdmg = false
defaults.player.show_apc = false
defaults.player.show_pmab = false
defaults.player.show_patt = false
defaults.player.show_pda = false
defaults.player.show_pacc = false
defaults.player.show_pmacc = false
defaults.player.show_sms = false
defaults.player.show_pbpd = false
defaults.player.show_pmdmg = false
defaults.player.show_cursna = false
defaults.player.extra_all_override = false
defaults.player.show_COR_messages = true
defaults.player.update_gs = true
defaults.player.rank = 1
defaults.player.job_visibility = {}
-- Persisted per-job visibility presets (slots/extras/modes). These must exist in defaults,
-- otherwise Windower's config serializer may drop them on save/load.
defaults.player.job_visibility_slots = {}
defaults.player.job_visibility_extras = {}
defaults.player.job_visibility_modes = {}
defaults.player.job_visibility_active_slot = {}
defaults.player.job_visibility_active_extra_slot = {}
defaults.player.job_visibility_active_mode = {}
defaults.player.job_visibility_active_mode_slot = {}
defaults.Bards = {}
defaults.Cors = {}
defaults.Cors['qultada'] = 0
defaults.Geos = {}
defaults.Geos['Sylvie'] = 0
defaults.display = {}
defaults.display.pos = {}
defaults.display.pos.x = 0
defaults.display.pos.y = 0
defaults.display.mode = 1
defaults.display.style = "box"
defaults.display.size = 5
defaults.display.flat_theme = 1
defaults.display.label_size = 5
defaults.display.value_size = 5
defaults.display.bg_alpha = 5
defaults.display.label_font = "Tahoma"
defaults.display.value_font = "Tahoma"
defaults.display.bg_image = ""
defaults.image_folder_name = "default"

defaults.Bards["joachim"] = {
	['gjallarhorn'] = false,
	['merits'] = {
		['minne'] = 0,
		['minuet'] = 0,
		['madrigal'] = 0,
	},
	['jp'] = {
		['minne'] = 0,
		['minuet'] = 0,
	},
	['emperean_armor_bonus'] = 0,
	['song_bonus'] = {
		['all_songs'] = 0,
		['paeon'] = 0,
		['ballad'] = 0,
		['minne'] = 0,
		['minuet'] = 0,
		['madrigal'] = 0,
		['prelude'] = 0,
		['mambo'] = 0,
		['march'] = 0,
		['etude'] = 0,
		['carol'] = 0,
		['mazurka'] = 0,
	},
}
defaults.Bards["ulmia"] = {
	['gjallarhorn'] = false,
	['merits'] = {
		['minne'] = 0,
		['minuet'] = 0,
		['madrigal'] = 0,
	},
	['jp'] = {
		['minne'] = 0,
		['minuet'] = 0,
	},
	['emperean_armor_bonus'] = 0,
	['song_bonus'] = {
		['all_songs'] = 0,
		['paeon'] = 0,
		['ballad'] = 0,
		['minne'] = 0,
		['minuet'] = 0,
		['madrigal'] = 0,
		['prelude'] = 0,
		['mambo'] = 0,
		['march'] = 0,
		['etude'] = 0,
		['carol'] = 0,
		['mazurka'] = 0,
	},
}

default_bard_settings = {
	['gjallarhorn'] = true,
	['merits'] = {
		['minne'] = 0,
		['minuet'] = 5,
		['madrigal'] = 5,
	},
	['jp'] = {
		['minne'] = 20,
		['minuet'] = 20,
	},
	['emperean_armor_bonus'] = 3,
	['song_bonus'] = {
		['all_songs'] = 0,
		['paeon'] = 0,
		['ballad'] = 0,
		['minne'] = 0,
		['minuet'] = 0,
		['madrigal'] = 0,
		['prelude'] = 0,
		['mambo'] = 0,
		['march'] = 0,
		['etude'] = 0,
		['carol'] = 0,
		['mazurka'] = 0,
	},
}

sections = {}
sections.block= {}
