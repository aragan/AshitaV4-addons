return {
    [10286]={
        ["Aug1"]="Path: A"
    }, 
    [10326]={
        ["Aug2"]="Enmity+9", 
        ["Aug3"]="Potency of \"Cure\" effect received +15%", 
        ["Aug1"]="HP+105"
    }, 
    [10329]={
        ["Aug1"]="Path: A"
    }, 
    [10715]={
        ["Aug2"]="Mag. Acc.+15", 
        ["Aug3"]="\"Mag.Atk.Bns.\"+15", 
        ["Aug4"]="\"Fast Cast\"+3", 
        ["Aug1"]="Accuracy+15"
    }, 
    [11114]={
        ["Aug2"]="\"Mag.Atk.Bns.\"+12", 
        ["Aug3"]="\"Store TP\"+6", 
        ["Aug1"]="Rng.Atk.+20"
    }, 
    [11122]={
        ["Aug1"]="Phalanx +3"
    }, 
    [11157]={
        ["Aug1"]="Path: A"
    }, 
    [11331]={
        ["Aug1"]="Path: A"
    }, 
    [11363]={
        ["Aug1"]="Path: A"
    }, 
    [11380]={
        ["Aug1"]="Path: A"
    }, 
    [11430]={
        ["Aug2"]="AGI+12", 
        ["Aug3"]="Accuracy+20", 
        ["Aug1"]="DEX+12"
    }, 
    [11488]={
        ["Aug2"]="Pet: Damage taken -10%", 
        ["Aug3"]="ATTACK+3", 
        ["Aug4"]="PET: \"REGEN\"+1", 
        ["Aug1"]="Attack+3"
    }, 
    [11922]={
        ["Aug2"]="Mag. Acc.+5", 
        ["Aug3"]="Attack+3", 
        ["Aug4"]="Breath dmg. taken -2%", 
        ["Aug1"]="MND+5"
    }, 
    [11949]={
        ["Aug1"]="Path: A"
    }, 
    [12997]={
        ["Aug2"]="AGI+12", 
        ["Aug3"]="Accuracy+20", 
        ["Aug1"]="DEX+12"
    }, 
    [13945]={
        ["Aug1"]="Path: A"
    }, 
    [15131]={
        ["Aug1"]="Inc. Sp. \"Blood Pact\" magic burst dmg."
    }, 
    [15322]={
        ["Aug1"]="Path: A"
    }, 
    [16370]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Mag. Acc+20 /Mag. Dmg.+20", 
        ["Aug1"]="AGI+20", 
        ["Aug4"]="Weapon skill damage +10%", 
        ["Aug3"]="Magic Damage +10"
    }, 
    [23085]={
        ["Aug1"]="Path: A"
    }, 
    [23087]={
        ["Aug2"]="MND+12", 
        ["Aug3"]="Mag. Acc.+20", 
        ["Aug1"]="MP+80"
    }, 
    [23088]={
        ["Aug1"]="Path: A"
    }, 
    [23089]={
        ["Aug1"]="Path: A"
    }, 
    [23090]={
        ["Aug2"]="Attack+20", 
        ["Aug3"]="\"Subtle Blow\"+8", 
        ["Aug1"]="Accuracy+20"
    }, 
    [23092]={
        ["Aug1"]="Path: A"
    }, 
    [23093]={
        ["Aug1"]="Path: A"
    }, 
    [23094]={
        ["Aug1"]="Path: A"
    }, 
    [23096]={
        ["Aug1"]="Path: A"
    }, 
    [23097]={
        ["Aug1"]="Path: B"
    }, 
    [23099]={
        ["Aug1"]="Reduces Sp. \"Blood Pact\" MP cost"
    }, 
    [23100]={
        ["Aug1"]="Path: A"
    }, 
    [23101]={
        ["Aug2"]="\"Rapid Shot\"+13", 
        ["Aug3"]="Enmity-6", 
        ["Aug1"]="AGI+12"
    }, 
    [23102]={
        ["Aug2"]="DEX+10", 
        ["Aug3"]="\"Dbl.Atk.\"+3", 
        ["Aug4"]="\"Triple Atk.\"+3", 
        ["Aug1"]="STR+10"
    }, 
    [23103]={
        ["Aug1"]="Path: A"
    }, 
    [23104]={
        ["Aug1"]="Enhances \"Enlightenment\" effect"
    }, 
    [23105]={
        ["Aug1"]="Path: A"
    }, 
    [23106]={
        ["Aug2"]="Attack+12", 
        ["Aug3"]="\"Dual Wield\"+6", 
        ["Aug1"]="Accuracy+20"
    }, 
    [23153]={
        ["Aug1"]="Path: A"
    }, 
    [23154]={
        ["Aug2"]="MND+12", 
        ["Aug3"]="Mag. Acc.+20", 
        ["Aug1"]="MP+80"
    }, 
    [23159]={
        ["Aug1"]="Path: A"
    }, 
    [23160]={
        ["Aug1"]="Path: A"
    }, 
    [23161]={
        ["Aug1"]="Path: A"
    }, 
    [23162]={
        ["Aug1"]="Enhances \"Eagle Eye Shot\" effect"
    }, 
    [23163]={
        ["Aug1"]="Path: A"
    }, 
    [23164]={
        ["Aug1"]="Path: B"
    }, 
    [23167]={
        ["Aug1"]="Path: A"
    }, 
    [23168]={
        ["Aug1"]="Path: A"
    }, 
    [23169]={
        ["Aug2"]="DEX+10", 
        ["Aug3"]="\"Dbl.Atk.\"+3", 
        ["Aug4"]="\"Triple Atk.\"+3", 
        ["Aug1"]="STR+10"
    }, 
    [23170]={
        ["Aug1"]="Phalanx +3"
    }, 
    [23172]={
        ["Aug1"]="Path: A"
    }, 
    [23220]={
        ["Aug1"]="Path: A"
    }, 
    [23221]={
        ["Aug2"]="\"Cure\" spellcasting time -15%", 
        ["Aug3"]="\"Conserve MP\"+6", 
        ["Aug1"]="\"Cure\" potency +5%"
    }, 
    [23222]={
        ["Aug1"]="Path: A"
    }, 
    [23223]={
        ["Aug1"]="Path: A"
    }, 
    [23226]={
        ["Aug1"]="Path: A"
    }, 
    [23227]={
        ["Aug1"]="Path: A"
    }, 
    [23228]={
        ["Aug1"]="Path: A"
    }, 
    [23231]={
        ["Aug1"]="Enh. Ninj. Mag. Acc/Cast Time Red."
    }, 
    [23232]={
        ["Aug1"]="Path: A"
    }, 
    [23234]={
        ["Aug1"]="Path: A"
    }, 
    [23236]={
        ["Aug2"]="\"Store TP\"+5", 
        ["Aug3"]="\"Subtle Blow\"+8", 
        ["Aug1"]="HP+65"
    }, 
    [23237]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23240]={
        ["Aug1"]="Path: A"
    }, 
    [23287]={
        ["Aug1"]="Path: A"
    }, 
    [23288]={
        ["Aug1"]="Path: A"
    }, 
    [23290]={
        ["Aug1"]="Path: A"
    }, 
    [23293]={
        ["Aug1"]="Path: A"
    }, 
    [23294]={
        ["Aug1"]="Path: A"
    }, 
    [23295]={
        ["Aug1"]="Path: B"
    }, 
    [23297]={
        ["Aug2"]="\"Store TP\"+5", 
        ["Aug3"]="\"Subtle Blow\"+8", 
        ["Aug1"]="HP+65"
    }, 
    [23298]={
        ["Aug1"]="Path: B"
    }, 
    [23303]={
        ["Aug2"]="DEX+10", 
        ["Aug3"]="\"Dbl.Atk.\"+3", 
        ["Aug4"]="\"Triple Atk.\"+3", 
        ["Aug1"]="STR+10"
    }, 
    [23304]={
        ["Aug1"]="Path: A"
    }, 
    [23305]={
        ["Aug1"]="Path: A"
    }, 
    [23307]={
        ["Aug1"]="Path: A"
    }, 
    [23353]={
        ["Aug1"]="Path: A"
    }, 
    [23355]={
        ["Aug1"]="Path: A"
    }, 
    [23356]={
        ["Aug1"]="Path: A"
    }, 
    [23357]={
        ["Aug1"]="Path: A"
    }, 
    [23360]={
        ["Aug1"]="Path: A"
    }, 
    [23362]={
        ["Aug1"]="Path: A"
    }, 
    [23365]={
        ["Aug1"]="Path: B"
    }, 
    [23368]={
        ["Aug1"]="Path: A"
    }, 
    [23369]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23370]={
        ["Aug2"]="DEX+10", 
        ["Aug3"]="\"Dbl.Atk.\"+3", 
        ["Aug4"]="\"Triple Atk.\"+3", 
        ["Aug1"]="STR+10"
    }, 
    [23371]={
        ["Aug1"]="Path: A"
    }, 
    [23373]={
        ["Aug1"]="Path: A"
    }, 
    [23374]={
        ["Aug1"]="Path: A"
    }, 
    [23382]={
        ["Aug2"]="Mag. Acc.+12", 
        ["Aug3"]="\"Fast Cast\"+4", 
        ["Aug1"]="Accuracy+20"
    }, 
    [23385]={
        ["Aug2"]="\"Mag.Atk.Bns.\"+12", 
        ["Aug3"]="\"Store TP\"+6", 
        ["Aug1"]="Rng.Atk.+20"
    }, 
    [23386]={
        ["Aug1"]="Enhances \"Ikishoten\" effect"
    }, 
    [23393]={
        ["Aug2"]="AGI+12", 
        ["Aug3"]="Accuracy+20", 
        ["Aug1"]="DEX+12"
    }, 
    [23395]={
        ["Aug1"]="Path: B"
    }, 
    [23397]={
        ["Aug2"]="Accuracy+11 Attack+11", 
        ["Aug3"]="Phalanx +2", 
        ["Aug4"]="Mag. Acc.+18 \"Mag.Atk.Bns.\"+18", 
        ["Aug1"]="Phys. dmg. taken -1%"
    }, 
    [23398]={
        ["Aug1"]="Enhances \"Savagery\" effect"
    }, 
    [23402]={
        ["Aug2"]="Magic Accuracy", 
        ["Aug1"]="Enfeebling Magic duration"
    }, 
    [23404]={
        ["Aug2"]="Mag. Acc.+12", 
        ["Aug3"]="\"Fast Cast\"+4", 
        ["Aug1"]="Accuracy+20"
    }, 
    [23405]={
        ["Aug1"]="Enhances \"Blood Weapon\" effect"
    }, 
    [23406]={
        ["Aug1"]="Enhances \"Killer Instinct\" effect"
    }, 
    [23408]={
        ["Aug1"]="Phalanx +3"
    }, 
    [23409]={
        ["Aug1"]="Enhances \"Ikishoten\" effect"
    }, 
    [23410]={
        ["Aug1"]="Enhances \"Yonin\" and \"Innin\" effect"
    }, 
    [23412]={
        ["Aug1"]="Enhances \"Astral Flow\" effect"
    }, 
    [23413]={
        ["Aug1"]="Path: A"
    }, 
    [23415]={
        ["Aug1"]="Enhances \"Optimization\" effect"
    }, 
    [23416]={
        ["Aug1"]="Enhances \"Trance\" effect"
    }, 
    [23417]={
        ["Aug1"]="Path: A"
    }, 
    [23419]={
        ["Aug1"]="Path: A"
    }, 
    [23426]={
        ["Aug1"]="Path: A"
    }, 
    [23445]={
        ["Aug1"]="Path: A"
    }, 
    [23447]={
        ["Aug2"]="Attack+20", 
        ["Aug3"]="\"Subtle Blow\"+8", 
        ["Aug1"]="Accuracy+20"
    }, 
    [23448]={
        ["Aug2"]="Enmity+9", 
        ["Aug3"]="Potency of \"Cure\" effect received +15%", 
        ["Aug1"]="HP+105"
    }, 
    [23450]={
        ["Aug2"]="Pet: \"Dbl. Atk.\"+5", 
        ["Aug3"]="Pet: Damage taken -4%", 
        ["Aug1"]="Pet: Attack+25 Pet: Rng.Atk.+25"
    }, 
    [23456]={
        ["Aug2"]="Blood Pact Dmg.+10", 
        ["Aug3"]="Pet: CHR+1", 
        ["Aug4"]="Pet: \"Mag.Atk.Bns.\"+2", 
        ["Aug1"]="Pet: Attack+9 Pet: Rng.Atk.+9"
    }, 
    [23457]={
        ["Aug2"]="INT+7", 
        ["Aug3"]="MND+7", 
        ["Aug1"]="Mag. Acc.+15"
    }, 
    [23458]={
        ["Aug2"]="\"Mag.Atk.Bns.\"+12", 
        ["Aug3"]="\"Store TP\"+6", 
        ["Aug1"]="Rng.Atk.+20"
    }, 
    [23460]={
        ["Aug1"]="Path: B"
    }, 
    [23462]={
        ["Aug1"]="Path: A"
    }, 
    [23463]={
        ["Aug1"]="Path: A"
    }, 
    [23464]={
        ["Aug1"]="Path: A"
    }, 
    [23465]={
        ["Aug1"]="Path: A"
    }, 
    [23468]={
        ["Aug1"]="Enhances \"Manafont\" effect"
    }, 
    [23472]={
        ["Aug1"]="Enhances \"Blood Weapon\" effect"
    }, 
    [23473]={
        ["Aug1"]="Enhances \"Feral Howl\" effect"
    }, 
    [23475]={
        ["Aug1"]="Phalanx +3"
    }, 
    [23476]={
        ["Aug1"]="Enhances \"Ikishoten\" effect"
    }, 
    [23477]={
        ["Aug1"]="Enhances \"Mijin Gakure\" effect"
    }, 
    [23479]={
        ["Aug1"]="Reduces Sp. \"Blood Pact\" MP cost"
    }, 
    [23482]={
        ["Aug1"]="Enhances \"Overdrive\" effect"
    }, 
    [23483]={
        ["Aug1"]="Enhances \"Trance\" effect"
    }, 
    [23484]={
        ["Aug1"]="Enhances \"Enlightenment\" effect"
    }, 
    [23485]={
        ["Aug2"]="\"Fast Cast\"+10", 
        ["Aug3"]="Haste+2%", 
        ["Aug1"]="MP+50"
    }, 
    [23487]={
        ["Aug1"]="Path: A"
    }, 
    [23490]={
        ["Aug1"]="Path: A"
    }, 
    [23491]={
        ["Aug1"]="Path: A"
    }, 
    [23493]={
        ["Aug2"]="Enmity+9", 
        ["Aug3"]="Potency of \"Cure\" effect received +15%", 
        ["Aug1"]="HP+105"
    }, 
    [23500]={
        ["Aug1"]="Path: A"
    }, 
    [23506]={
        ["Aug1"]="Path: A"
    }, 
    [23508]={
        ["Aug1"]="Path: A"
    }, 
    [23512]={
        ["Aug1"]="Path: A"
    }, 
    [23515]={
        ["Aug2"]="Accuracy+15", 
        ["Aug3"]="Mag. Acc.+15", 
        ["Aug4"]="Magic dmg. taken -5%", 
        ["Aug1"]="DEX+10"
    }, 
    [23516]={
        ["Aug2"]="Mag. Acc.+12", 
        ["Aug3"]="\"Fast Cast\"+4", 
        ["Aug1"]="Accuracy+20"
    }, 
    [23520]={
        ["Aug1"]="Path: A"
    }, 
    [23526]={
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug3"]="Pet: Attack+10 Pet: Rng.Atk.+10", 
        ["Aug4"]="Pet: Haste+10", 
        ["Aug1"]="Pet: Acc.+20 Pet: R.Acc.+20 Pet: Atk.+20 Pet: R.Atk.+20"
    }, 
    [23527]={
        ["Aug1"]="Path: A"
    }, 
    [23529]={
        ["Aug1"]="Path: A"
    }, 
    [23530]={
        ["Aug1"]="Path: A"
    }, 
    [23531]={
        ["Aug1"]="Path: A"
    }, 
    [23532]={
        ["Aug1"]="Path: A"
    }, 
    [23533]={
        ["Aug1"]="Enhances \"Invigorate\" effect"
    }, 
    [23539]={
        ["Aug1"]="Enhances \"Diabolic Eye\" effect"
    }, 
    [23540]={
        ["Aug1"]="Enhances \"Beast Affinity\" effect"
    }, 
    [23543]={
        ["Aug1"]="Enhances \"Ikishoten\" effect"
    }, 
    [23545]={
        ["Aug1"]="Path: A"
    }, 
    [23546]={
        ["Aug1"]="Inc. Sp. \"Blood Pact\" magic burst dmg."
    }, 
    [23548]={
        ["Aug1"]="Path: C"
    }, 
    [23554]={
        ["Aug1"]="Path: B"
    }, 
    [23560]={
        ["Aug2"]="Mag. Acc.+5", 
        ["Aug3"]="Attack+3", 
        ["Aug4"]="Breath dmg. taken -2%", 
        ["Aug1"]="MND+5"
    }, 
    [23565]={
        ["Aug1"]="Path: B"
    }, 
    [23570]={
        ["Aug1"]="Path: A"
    }, 
    [23573]={
        ["Aug1"]="Path: A"
    }, 
    [23587]={
        ["Aug1"]="Enhances \"Ikishoten\" effect"
    }, 
    [23591]={
        ["Aug2"]="Mag. Acc.+12", 
        ["Aug3"]="\"Fast Cast\"+4", 
        ["Aug1"]="Accuracy+20"
    }, 
    [23597]={
        ["Aug1"]="Path: A"
    }, 
    [23598]={
        ["Aug1"]="Path: A"
    }, 
    [23599]={
        ["Aug1"]="Path: A"
    }, 
    [23600]={
        ["Aug1"]="Path: A"
    }, 
    [23601]={
        ["Aug1"]="Enhances \"Afflatus Misery\" effect"
    }, 
    [23602]={
        ["Aug1"]="Path: A"
    }, 
    [23603]={
        ["Aug2"]="Accuracy", 
        ["Aug1"]="Enspell Damage"
    }, 
    [23605]={
        ["Aug2"]="Mag. Acc.+12", 
        ["Aug3"]="\"Fast Cast\"+4", 
        ["Aug1"]="Accuracy+20"
    }, 
    [23606]={
        ["Aug1"]="Enhances \"Muted Soul\" effect"
    }, 
    [23607]={
        ["Aug1"]="Enhances \"Familiar\" effect"
    }, 
    [23608]={
        ["Aug1"]="Path: B"
    }, 
    [23609]={
        ["Aug1"]="Enhances \"Eagle Eye Shot\" effect"
    }, 
    [23611]={
        ["Aug1"]="Enhances \"Mijin Gakure\" effect"
    }, 
    [23612]={
        ["Aug1"]="Enhances \"Strafe\" effect"
    }, 
    [23613]={
        ["Aug1"]="Increases Sp. \"Blood Pact\" accuracy"
    }, 
    [23614]={
        ["Aug1"]="Enhances \"Assimilation\" effect"
    }, 
    [23616]={
        ["Aug1"]="Enhances \"Ventriloquy\" effect"
    }, 
    [23617]={
        ["Aug1"]="Path: A"
    }, 
    [23618]={
        ["Aug1"]="Path: A"
    }, 
    [23619]={
        ["Aug1"]="Enhances \"Mending Halation\" effect"
    }, 
    [23620]={
        ["Aug1"]="Path: A"
    }, 
    [23621]={
        ["Aug1"]="Path: A"
    }, 
    [23624]={
        ["Aug1"]="Path: A"
    }, 
    [23627]={
        ["Aug1"]="Path: A"
    }, 
    [23636]={
        ["Aug1"]="Path: A"
    }, 
    [23637]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23644]={
        ["Aug1"]="Path: A"
    }, 
    [23645]={
        ["Aug1"]="Path: A"
    }, 
    [23646]={
        ["Aug1"]="Path: A"
    }, 
    [23649]={
        ["Aug2"]="Enmity+9", 
        ["Aug3"]="Potency of \"Cure\" effect received +15%", 
        ["Aug1"]="HP+105"
    }, 
    [23650]={
        ["Aug2"]="Mag. Acc.+12", 
        ["Aug3"]="\"Fast Cast\"+4", 
        ["Aug1"]="Accuracy+20"
    }, 
    [23652]={
        ["Aug1"]="Path: A"
    }, 
    [23654]={
        ["Aug1"]="Path: A"
    }, 
    [23661]={
        ["Aug1"]="Path: A"
    }, 
    [23663]={
        ["Aug1"]="Path: A"
    }, 
    [23664]={
        ["Aug1"]="Path: A"
    }, 
    [23665]={
        ["Aug1"]="Path: A"
    }, 
    [23666]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23670]={
        ["Aug1"]="Immunobreak Chance"
    }, 
    [23671]={
        ["Aug1"]="Path: A"
    }, 
    [23673]={
        ["Aug1"]="Enhances \"Desperate Blows\" effect"
    }, 
    [23674]={
        ["Aug1"]="Enhances \"Beast Healer\" effect"
    }, 
    [23675]={
        ["Aug1"]="Path: B"
    }, 
    [23676]={
        ["Aug1"]="Enhances \"Eagle Eye Shot\" effect"
    }, 
    [23678]={
        ["Aug1"]="Enh. Ninj. Mag. Acc/Cast Time Red."
    }, 
    [23680]={
        ["Aug1"]="Inc. Sp. \"Blood Pact\" magic crit. dmg."
    }, 
    [23681]={
        ["Aug1"]="Path: A"
    }, 
    [23683]={
        ["Aug1"]="Enhances \"Role Reversal\" effect"
    }, 
    [23684]={
        ["Aug1"]="Path: A"
    }, 
    [23685]={
        ["Aug1"]="Path: A"
    }, 
    [23686]={
        ["Aug1"]="Path: A"
    }, 
    [23693]={
        ["Aug1"]="Path: A"
    }, 
    [23694]={
        ["Aug1"]="Path: A"
    }, 
    [23699]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="Weapon skill damage +10%", 
        ["Aug3"]="STR+10"
    }, 
    [23707]={
        ["Aug1"]="Path: A"
    }, 
    [23711]={
        ["Aug1"]="Path: A"
    }, 
    [23713]={
        ["Aug5"]="Mag. Acc.+9 \"Mag.Atk.Bns.\"+9", 
        ["Aug2"]="AGI+6", 
        ["Aug1"]="\"Dbl.Atk.\"+1", 
        ["Aug4"]="Accuracy+11 Attack+11", 
        ["Aug3"]="\"Treasure Hunter\"+2"
    }, 
    [23715]={
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug3"]="Pet: Attack+10 Pet: Rng.Atk.+10", 
        ["Aug4"]="Pet: Haste+10", 
        ["Aug1"]="Pet: Acc.+20 Pet: R.Acc.+20 Pet: Atk.+20 Pet: R.Atk.+20"
    }, 
    [23718]={
        ["Aug1"]="Path: A"
    }, 
    [23719]={
        ["Aug1"]="Path: A"
    }, 
    [23725]={
        ["Aug5"]="Mag. Acc.+9 \"Mag.Atk.Bns.\"+9", 
        ["Aug2"]="AGI+6", 
        ["Aug1"]="\"Dbl.Atk.\"+1", 
        ["Aug4"]="Accuracy+11 Attack+11", 
        ["Aug3"]="\"Treasure Hunter\"+2"
    }, 
    [23727]={
        ["Aug1"]="Path: A"
    }, 
    [23728]={
        ["Aug1"]="Path: A"
    }, 
    [23732]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23733]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23734]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23735]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23736]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23755]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23756]={
        ["Aug1"]="Path: A"
    }, 
    [23757]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="STR+10"
    }, 
    [23758]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="STR+10"
    }, 
    [23759]={
        ["Aug1"]="Path: A"
    }, 
    [23760]={
        ["Aug1"]="Path: A"
    }, 
    [23761]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23762]={
        ["Aug1"]="Path: A"
    }, 
    [23763]={
        ["Aug1"]="Path: A"
    }, 
    [23764]={
        ["Aug1"]="Path: A"
    }, 
    [23765]={
        ["Aug2"]="DEX+10", 
        ["Aug3"]="\"Dbl.Atk.\"+3", 
        ["Aug4"]="\"Triple Atk.\"+3", 
        ["Aug1"]="STR+10"
    }, 
    [23766]={
        ["Aug1"]="Path: A"
    }, 
    [23767]={
        ["Aug1"]="Path: A"
    }, 
    [23768]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23769]={
        ["Aug1"]="Path: A"
    }, 
    [23770]={
        ["Aug1"]="Path: A"
    }, 
    [23771]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="STR+10"
    }, 
    [23772]={
        ["Aug1"]="Path: A"
    }, 
    [23773]={
        ["Aug1"]="Path: A"
    }, 
    [23774]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23775]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23776]={
        ["Aug1"]="Path: A"
    }, 
    [23777]={
        ["Aug2"]="DEX+10", 
        ["Aug3"]="\"Dbl.Atk.\"+3", 
        ["Aug4"]="\"Triple Atk.\"+3", 
        ["Aug1"]="STR+10"
    }, 
    [23778]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="STR+10"
    }, 
    [23779]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="STR+10"
    }, 
    [23780]={
        ["Aug1"]="Path: A"
    }, 
    [23781]={
        ["Aug1"]="Path: A"
    }, 
    [23782]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23784]={
        ["Aug1"]="Path: A"
    }, 
    [23785]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="STR+10"
    }, 
    [23786]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="STR+10"
    }, 
    [23787]={
        ["Aug1"]="Path: A"
    }, 
    [23788]={
        ["Aug1"]="Path: A"
    }, 
    [23789]={
        ["Aug1"]="Path: B"
    }, 
    [23797]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23798]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23861]={
        ["Aug1"]="Path: B"
    }, 
    [23934]={
        ["Aug1"]="Enhances \"Winning Streak\" effect"
    }, 
    [23940]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23947]={
        ["Aug1"]="Enhances \"Diabolic Eye\" effect"
    }, 
    [23972]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [23979]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [24013]={
        ["Aug1"]="Enhances \"Perfect Dodge\" effect"
    }, 
    [24030]={
        ["Aug1"]="Path: A"
    }, 
    [24037]={
        ["Aug2"]="Accuracy+10", 
        ["Aug3"]="Attack+4", 
        ["Aug1"]="\"Store TP\"+7"
    }, 
    [24075]={
        ["Aug1"]="Path: A"
    }, 
    [24114]={
        ["Aug1"]="Path: A"
    }, 
    [24270]={
        ["Aug1"]="Path: A"
    }, 
    [25554]={
        ["Aug1"]="Path: A"
    }, 
    [25556]={
        ["Aug1"]="Path: A"
    }, 
    [25564]={
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug3"]="Pet: Attack+10 Pet: Rng.Atk.+10", 
        ["Aug4"]="Pet: Haste+10", 
        ["Aug1"]="Pet: Acc.+20 Pet: R.Acc.+20 Pet: Atk.+20 Pet: R.Atk.+20"
    }, 
    [25565]={
        ["Aug2"]="Eva.+20 /Mag. Eva.+20", 
        ["Aug3"]="Pet: Magic Damage+10", 
        ["Aug4"]="Pet: Haste+10", 
        ["Aug1"]="Pet: M.Acc.+20 Pet: M.Dmg.+20"
    }, 
    [25569]={
        ["Aug2"]="Accuracy+10", 
        ["Aug3"]="Attack+4", 
        ["Aug1"]="\"Store TP\"+7"
    }, 
    [25570]={
        ["Aug2"]="Mag. Acc.+12", 
        ["Aug3"]="\"Fast Cast\"+4", 
        ["Aug1"]="Accuracy+20"
    }, 
    [25571]={
        ["Aug2"]="\"Fast Cast\"+10", 
        ["Aug3"]="Haste+2%", 
        ["Aug1"]="MP+50"
    }, 
    [25572]={
        ["Aug1"]="Path: B"
    }, 
    [25573]={
        ["Aug1"]="Enhances \"Overdrive\" effect"
    }, 
    [25574]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="STR+10"
    }, 
    [25575]={
        ["Aug1"]="Path: A"
    }, 
    [25576]={
        ["Aug2"]="Pet: Accuracy+20", 
        ["Aug3"]="Pet: Damage taken -4%", 
        ["Aug1"]="Pet: HP+125"
    }, 
    [25577]={
        ["Aug2"]="MP+50", 
        ["Aug3"]="\"Refresh\"+2", 
        ["Aug1"]="HP+50"
    }, 
    [25578]={
        ["Aug1"]="Path: A"
    }, 
    [25592]={
        ["Aug1"]="Path: A"
    }, 
    [25593]={
        ["Aug2"]="Blood Pact Dmg.+10", 
        ["Aug3"]="Pet: CHR+1", 
        ["Aug4"]="Pet: \"Mag.Atk.Bns.\"+2", 
        ["Aug1"]="Pet: Attack+9 Pet: Rng.Atk.+9"
    }, 
    [25602]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [25603]={
        ["Aug1"]="Path: A"
    }, 
    [25610]={
        ["Aug2"]="Pet: Attack+20", 
        ["Aug3"]="Pet: \"Dbl. Atk.\"+4", 
        ["Aug1"]="Pet: Accuracy+20"
    }, 
    [25612]={
        ["Aug2"]="\"Store TP\"+5", 
        ["Aug3"]="\"Subtle Blow\"+8", 
        ["Aug1"]="HP+65"
    }, 
    [25614]={
        ["Aug2"]="AGI+12", 
        ["Aug3"]="Accuracy+20", 
        ["Aug1"]="DEX+12"
    }, 
    [25616]={
        ["Aug2"]="DEX+12", 
        ["Aug3"]="Phalanx +4", 
        ["Aug1"]="\"Mag.Atk.Bns.\"+13"
    }, 
    [25629]={
        ["Aug1"]="Path: B"
    }, 
    [25630]={
        ["Aug2"]="AGI+12", 
        ["Aug3"]="Accuracy+20", 
        ["Aug1"]="DEX+12"
    }, 
    [25636]={
        ["Aug1"]="Path: A"
    }, 
    [25640]={
        ["Aug5"]="Mag. Acc.+7 \"Mag.Atk.Bns.\"+7", 
        ["Aug2"]="\"Cure\" potency +8%", 
        ["Aug1"]="INT+5", 
        ["Aug4"]="Accuracy+15 Attack+15", 
        ["Aug3"]="Phalanx +4"
    }, 
    [25641]={
        ["Aug2"]="Pet: \"Subtle Blow\"+10", 
        ["Aug3"]="Pet: STR+2", 
        ["Aug1"]="Pet: \"Mag.Atk.Bns.\"+30"
    }, 
    [25642]={
        ["Aug2"]="Pet: \"Store TP\"+11", 
        ["Aug3"]="Pet: CHR+2", 
        ["Aug4"]="Pet: \"Mag.Atk.Bns.\"+8", 
        ["Aug1"]="Pet: Accuracy+9 Pet: Rng. Acc.+9"
    }, 
    [25643]={
        ["Aug2"]="DEX+12", 
        ["Aug3"]="Phalanx +4", 
        ["Aug1"]="\"Mag.Atk.Bns.\"+13"
    }, 
    [25653]={
        ["Aug1"]="Path: A"
    }, 
    [25681]={
        ["Aug1"]="Path: A"
    }, 
    [25683]={
        ["Aug2"]="Pet: Attack+20", 
        ["Aug3"]="Pet: \"Dbl. Atk.\"+4", 
        ["Aug1"]="Pet: Accuracy+20"
    }, 
    [25687]={
        ["Aug2"]="AGI+12", 
        ["Aug3"]="Accuracy+20", 
        ["Aug1"]="DEX+12"
    }, 
    [25706]={
        ["Aug2"]="\"Fast Cast\"+6", 
        ["Aug3"]="CHR+1", 
        ["Aug4"]="\"Mag.Atk.Bns.\"+4", 
        ["Aug1"]="Mag. Acc.+3"
    }, 
    [25708]={
        ["Aug1"]="Enh. Ninj. Mag. Acc/Cast Time Red."
    }, 
    [25716]={
        ["Aug2"]="Enmity+9", 
        ["Aug3"]="Potency of \"Cure\" effect received +15%", 
        ["Aug1"]="HP+105"
    }, 
    [25717]={
        ["Aug2"]="Accuracy+10", 
        ["Aug3"]="Attack+4", 
        ["Aug1"]="\"Store TP\"+7"
    }, 
    [25718]={
        ["Aug2"]="Accuracy+11 Attack+11", 
        ["Aug3"]="Phalanx +2", 
        ["Aug4"]="Mag. Acc.+18 \"Mag.Atk.Bns.\"+18", 
        ["Aug1"]="Phys. dmg. taken -1%"
    }, 
    [25720]={
        ["Aug2"]="\"Cure\" potency +10%", 
        ["Aug3"]="MND+4", 
        ["Aug4"]="Mag. Acc.+1", 
        ["Aug1"]="\"Mag.Atk.Bns.\"+5"
    }, 
    [25721]={
        ["Aug2"]="\"Cure\" spellcasting time -15%", 
        ["Aug3"]="\"Conserve MP\"+6", 
        ["Aug1"]="\"Cure\" potency +5%"
    }, 
    [25727]={
        ["Aug1"]="Path: A"
    }, 
    [25733]={
        ["Aug1"]="Path: A"
    }, 
    [25766]={
        ["Aug1"]="Path: A"
    }, 
    [25767]={
        ["Aug1"]="Path: A"
    }, 
    [25785]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="STR+10"
    }, 
    [25786]={
        ["Aug1"]="Path: B"
    }, 
    [25787]={
        ["Aug1"]="Path: A"
    }, 
    [25788]={
        ["Aug2"]="Pet: \"Store TP\"+6", 
        ["Aug3"]="Pet: DEX+1", 
        ["Aug1"]="Pet: \"Mag.Atk.Bns.\"+28"
    }, 
    [25789]={
        ["Aug2"]="AGI+12", 
        ["Aug3"]="Accuracy+20", 
        ["Aug1"]="DEX+12"
    }, 
    [25791]={
        ["Aug2"]="DEX+10", 
        ["Aug3"]="\"Dbl.Atk.\"+3", 
        ["Aug4"]="\"Triple Atk.\"+3", 
        ["Aug1"]="STR+10"
    }, 
    [25792]={
        ["Aug2"]="Pet: Accuracy+20", 
        ["Aug3"]="Pet: Damage taken -4%", 
        ["Aug1"]="Pet: HP+125"
    }, 
    [25793]={
        ["Aug1"]="Path: A"
    }, 
    [25794]={
        ["Aug1"]="Path: A"
    }, 
    [25795]={
        ["Aug1"]="Path: B"
    }, 
    [25796]={
        ["Aug2"]="Eva.+20 /Mag. Eva.+20", 
        ["Aug3"]="Pet: Magic Damage+10", 
        ["Aug4"]="Pet: Haste+10", 
        ["Aug1"]="Pet: M.Acc.+20 Pet: M.Dmg.+20"
    }, 
    [25798]={
        ["Aug2"]="Attack+20", 
        ["Aug3"]="\"Subtle Blow\"+8", 
        ["Aug1"]="Accuracy+20"
    }, 
    [25824]={
        ["Aug1"]="Path: A"
    }, 
    [25826]={
        ["Aug1"]="Path: A"
    }, 
    [25827]={
        ["Aug2"]="MND+7", 
        ["Aug3"]="\"Mag.Atk.Bns.\"+10", 
        ["Aug1"]="Mag. Acc.+25 \"Mag.Atk.Bns.\"+25"
    }, 
    [25829]={
        ["Aug2"]="TP Bonus +250", 
        ["Aug1"]="Accuracy+4"
    }, 
    [25831]={
        ["Aug1"]="Path: A"
    }, 
    [25832]={
        ["Aug1"]="Path: A"
    }, 
    [25833]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [25834]={
        ["Aug1"]="Path: B"
    }, 
    [25835]={
        ["Aug1"]="Path: A"
    }, 
    [25836]={
        ["Aug2"]="AGI+12", 
        ["Aug3"]="Accuracy+20", 
        ["Aug1"]="DEX+12"
    }, 
    [25840]={
        ["Aug2"]="\"Fast Cast\"+5", 
        ["Aug3"]="CHR+10", 
        ["Aug1"]="Attack+29"
    }, 
    [25841]={
        ["Aug2"]="Pet: \"Dbl. Atk.\"+2", 
        ["Aug3"]="Pet: Accuracy+7 Pet: Rng. Acc.+7", 
        ["Aug4"]="Pet: Attack+10 Pet: Rng.Atk.+10", 
        ["Aug1"]="Pet: \"Mag.Atk.Bns.\"+29"
    }, 
    [25842]={
        ["Aug2"]="Pet: \"Store TP\"+11", 
        ["Aug1"]="Pet: Accuracy+28 Pet: Rng. Acc.+28"
    }, 
    [25843]={
        ["Aug2"]="\"Drain\" and \"Aspir\" potency +10", 
        ["Aug3"]="CHR+5", 
        ["Aug4"]="Mag. Acc.+4", 
        ["Aug1"]="\"Mag.Atk.Bns.\"+1"
    }, 
    [25844]={
        ["Aug2"]="MND+7", 
        ["Aug3"]="\"Mag.Atk.Bns.\"+10", 
        ["Aug1"]="Mag. Acc.+25 \"Mag.Atk.Bns.\"+25"
    }, 
    [25849]={
        ["Aug1"]="Path: B"
    }, 
    [25856]={
        ["Aug1"]="Path: A"
    }, 
    [25879]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="STR+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="STR+10"
    }, 
    [25880]={
        ["Aug2"]="\"Triple Atk.\"+4", 
        ["Aug3"]="AGI+4", 
        ["Aug4"]="Accuracy+1", 
        ["Aug1"]="Attack+5"
    }, 
    [25882]={
        ["Aug1"]="Path: B"
    }, 
    [25883]={
        ["Aug1"]="Path: A"
    }, 
    [25884]={
        ["Aug1"]="Path: A"
    }, 
    [25885]={
        ["Aug1"]="Enhances \"Beast Healer\" effect"
    }, 
    [25886]={
        ["Aug2"]="MP+80", 
        ["Aug3"]="Phys. dmg. taken -4", 
        ["Aug1"]="HP+80"
    }, 
    [25887]={
        ["Aug2"]="AGI+12", 
        ["Aug3"]="Accuracy+20", 
        ["Aug1"]="DEX+12"
    }, 
    [25890]={
        ["Aug1"]="Phalanx +3"
    }, 
    [25893]={
        ["Aug1"]="Path: A"
    }, 
    [25896]={
        ["Aug1"]="Path: A"
    }, 
    [25900]={
        ["Aug1"]="Path: A"
    }, 
    [25904]={
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug3"]="Pet: Attack+10 Pet: Rng.Atk.+10", 
        ["Aug4"]="Pet: Haste+10", 
        ["Aug1"]="Pet: Acc.+20 Pet: R.Acc.+20 Pet: Atk.+20 Pet: R.Atk.+20"
    }, 
    [25905]={
        ["Aug2"]="Eva.+20 /Mag. Eva.+20", 
        ["Aug3"]="Pet: Magic Damage+10", 
        ["Aug4"]="Pet: Haste+10", 
        ["Aug1"]="Pet: M.Acc.+20 Pet: M.Dmg.+20"
    }, 
    [25920]={
        ["Aug1"]="Path: A"
    }, 
    [25924]={
        ["Aug1"]="Path: A"
    }, 
    [25947]={
        ["Aug2"]="\"Mag.Atk.Bns.\"+12", 
        ["Aug3"]="\"Store TP\"+6", 
        ["Aug1"]="Rng.Atk.+20"
    }, 
    [25948]={
        ["Aug5"]="Mag. Acc.+9 \"Mag.Atk.Bns.\"+9", 
        ["Aug2"]="AGI+6", 
        ["Aug1"]="\"Dbl.Atk.\"+1", 
        ["Aug4"]="Accuracy+11 Attack+11", 
        ["Aug3"]="\"Treasure Hunter\"+2"
    }, 
    [25950]={
        ["Aug1"]="Path: A"
    }, 
    [25951]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [25952]={
        ["Aug1"]="Enhances \"Optimization\" effect"
    }, 
    [25953]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [25954]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Dbl.Atk.\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [25957]={
        ["Aug1"]="Phalanx +3"
    }, 
    [25961]={
        ["Aug1"]="Path: A"
    }, 
    [25963]={
        ["Aug1"]="Path: A"
    }, 
    [25972]={
        ["Aug2"]="Eva.+20 /Mag. Eva.+20", 
        ["Aug3"]="Pet: Magic Damage+10", 
        ["Aug4"]="Pet: Haste+10", 
        ["Aug1"]="Pet: M.Acc.+20 Pet: M.Dmg.+20"
    }, 
    [25975]={
        ["Aug1"]="Path: A"
    }, 
    [25977]={
        ["Aug1"]="Phalanx +3"
    }, 
    [25980]={
        ["Aug1"]="Path: A"
    }, 
    [25983]={
        ["Aug1"]="Path: A"
    }, 
    [25992]={
        ["Aug2"]="Eva.+20 /Mag. Eva.+20", 
        ["Aug3"]="Pet: Magic Damage+10", 
        ["Aug4"]="Pet: Haste+10", 
        ["Aug1"]="Pet: M.Acc.+20 Pet: M.Dmg.+20"
    }, 
    [25995]={
        ["Aug1"]="Path: A"
    }, 
    [26526]={
        ["Aug2"]="\"Mag.Atk.Bns.\"+12", 
        ["Aug3"]="\"Store TP\"+6", 
        ["Aug1"]="Rng.Atk.+20"
    }, 
    [26529]={
        ["Aug1"]="Path: A"
    }, 
    [26532]={
        ["Aug1"]="Path: A"
    }, 
    [26536]={
        ["Aug2"]="MND+12", 
        ["Aug3"]="Mag. Acc.+20", 
        ["Aug1"]="MP+80"
    }, 
    [26541]={
        ["Aug2"]="Eva.+20 /Mag. Eva.+20", 
        ["Aug3"]="Pet: Magic Damage+10", 
        ["Aug4"]="Pet: Haste+10", 
        ["Aug1"]="Pet: M.Acc.+20 Pet: M.Dmg.+20"
    }, 
    [26641]={
        ["Aug1"]="Enhances \"Beast Affinity\" effect"
    }, 
    [26671]={
        ["Aug2"]="Enmity+9", 
        ["Aug3"]="Potency of \"Cure\" effect received +15%", 
        ["Aug1"]="HP+105"
    }, 
    [26675]={
        ["Aug2"]="Pet: Accuracy+20", 
        ["Aug3"]="Pet: Damage taken -4%", 
        ["Aug1"]="Pet: HP+125"
    }, 
    [26677]={
        ["Aug2"]="Pet: Attack+35", 
        ["Aug3"]="Blood Pact Dmg.+8", 
        ["Aug1"]="MP+80"
    }, 
    [26679]={
        ["Aug2"]="\"Mag.Atk.Bns.\"+12", 
        ["Aug3"]="\"Store TP\"+6", 
        ["Aug1"]="Rng.Atk.+20"
    }, 
    [26696]={
        ["Aug1"]="Path: A"
    }, 
    [26702]={
        ["Aug1"]="Path: A"
    }, 
    [26735]={
        ["Aug1"]="Phalanx +3"
    }, 
    [26736]={
        ["Aug1"]="Path: A"
    }, 
    [26790]={
        ["Aug2"]="Spell interruption rate down -10%", 
        ["Aug3"]="MND+8", 
        ["Aug1"]="Mag. Acc.+11"
    }, 
    [26797]={
        ["Aug2"]="\"Fast Cast\"+10", 
        ["Aug3"]="Haste+2%", 
        ["Aug1"]="MP+50"
    }, 
    [26802]={
        ["Aug1"]="Path: A"
    }, 
    [26813]={
        ["Aug2"]="Mag. Acc.+12", 
        ["Aug3"]="\"Fast Cast\"+4", 
        ["Aug1"]="Accuracy+20"
    }, 
    [26847]={
        ["Aug2"]="Enmity+9", 
        ["Aug3"]="Potency of \"Cure\" effect received +15%", 
        ["Aug1"]="HP+105"
    }, 
    [26851]={
        ["Aug2"]="Pet: Accuracy+20", 
        ["Aug3"]="Pet: Damage taken -4%", 
        ["Aug1"]="Pet: HP+125"
    }, 
    [26869]={
        ["Aug1"]="Path: A"
    }, 
    [26871]={
        ["Aug1"]="Path: A"
    }, 
    [26893]={
        ["Aug1"]="Phalanx +3"
    }, 
    [26894]={
        ["Aug1"]="Path: A"
    }, 
    [26897]={
        ["Aug1"]="Path: A"
    }, 
    [26944]={
        ["Aug1"]="Path: A"
    }, 
    [26953]={
        ["Aug2"]="MP+50", 
        ["Aug3"]="\"Refresh\"+2", 
        ["Aug1"]="HP+50"
    }, 
    [26955]={
        ["Aug1"]="Path: A"
    }, 
    [26960]={
        ["Aug1"]="Path: B"
    }, 
    [26961]={
        ["Aug1"]="Path: A"
    }, 
    [26972]={
        ["Aug1"]="Path: A"
    }, 
    [26989]={
        ["Aug2"]="Mag. Acc.+12", 
        ["Aug3"]="\"Fast Cast\"+4", 
        ["Aug1"]="Accuracy+20"
    }, 
    [27017]={
        ["Aug2"]="\"Fast Cast\"+10", 
        ["Aug3"]="Haste+2%", 
        ["Aug1"]="MP+50"
    }, 
    [27023]={
        ["Aug2"]="Enmity+9", 
        ["Aug3"]="Potency of \"Cure\" effect received +15%", 
        ["Aug1"]="HP+105"
    }, 
    [27027]={
        ["Aug2"]="Pet: Accuracy+20", 
        ["Aug3"]="Pet: Damage taken -4%", 
        ["Aug1"]="Pet: HP+125"
    }, 
    [27031]={
        ["Aug2"]="\"Mag.Atk.Bns.\"+12", 
        ["Aug3"]="\"Store TP\"+6", 
        ["Aug1"]="Rng.Atk.+20"
    }, 
    [27047]={
        ["Aug2"]="Pet: \"Dbl. Atk.\"+5", 
        ["Aug3"]="Pet: Damage taken -4%", 
        ["Aug1"]="Pet: Attack+23 Pet: Rng.Atk.+23"
    }, 
    [27048]={
        ["Aug1"]="Path: A"
    }, 
    [27081]={
        ["Aug1"]="Path: B"
    }, 
    [27100]={
        ["Aug2"]="INT+7", 
        ["Aug3"]="MND+7", 
        ["Aug1"]="Mag. Acc.+15"
    }, 
    [27118]={
        ["Aug2"]="DEX+10", 
        ["Aug3"]="\"Dbl.Atk.\"+3", 
        ["Aug4"]="\"Triple Atk.\"+3", 
        ["Aug1"]="STR+10"
    }, 
    [27120]={
        ["Aug1"]="Path: A"
    }, 
    [27122]={
        ["Aug2"]="MND+12", 
        ["Aug3"]="Mag. Acc.+20", 
        ["Aug1"]="MP+80"
    }, 
    [27134]={
        ["Aug1"]="Path: A"
    }, 
    [27135]={
        ["Aug2"]="Mag. Acc.+15", 
        ["Aug3"]="\"Mag.Atk.Bns.\"+15", 
        ["Aug4"]="\"Fast Cast\"+3", 
        ["Aug1"]="Accuracy+15"
    }, 
    [27136]={
        ["Aug2"]="\"Cure\" spellcasting time -15%", 
        ["Aug3"]="\"Conserve MP\"+6", 
        ["Aug1"]="\"Cure\" potency +5%"
    }, 
    [27137]={
        ["Aug2"]="AGI+12", 
        ["Aug3"]="Accuracy+20", 
        ["Aug1"]="DEX+12"
    }, 
    [27139]={
        ["Aug2"]="Weapon skill damage +2%", 
        ["Aug3"]="STR+10", 
        ["Aug4"]="Attack+10", 
        ["Aug1"]="Accuracy+30"
    }, 
    [27140]={
        ["Aug2"]="Pet: \"Store TP\"+6", 
        ["Aug3"]="Pet: DEX+1", 
        ["Aug1"]="Pet: \"Mag.Atk.Bns.\"+28"
    }, 
    [27141]={
        ["Aug2"]="Blood Pact Dmg.+10", 
        ["Aug3"]="Pet: CHR+1", 
        ["Aug4"]="Pet: \"Mag.Atk.Bns.\"+2", 
        ["Aug1"]="Pet: Attack+9 Pet: Rng.Atk.+9"
    }, 
    [27142]={
        ["Aug2"]="Spell interruption rate down -10%", 
        ["Aug3"]="MND+8", 
        ["Aug1"]="Mag. Acc.+11"
    }, 
    [27149]={
        ["Aug1"]="Path: A"
    }, 
    [27151]={
        ["Aug1"]="Path: A"
    }, 
    [27197]={
        ["Aug2"]="TP Bonus +250", 
        ["Aug1"]="Accuracy+4"
    }, 
    [27199]={
        ["Aug2"]="Enmity+9", 
        ["Aug3"]="Potency of \"Cure\" effect received +15%", 
        ["Aug1"]="HP+105"
    }, 
    [27203]={
        ["Aug2"]="Pet: Accuracy+20", 
        ["Aug3"]="Pet: Damage taken -4%", 
        ["Aug1"]="Pet: HP+125"
    }, 
    [27205]={
        ["Aug2"]="Blood Pact Dmg.+14", 
        ["Aug3"]="Pet: \"Dbl. Atk.\"+4", 
        ["Aug1"]="Pet: STR+20"
    }, 
    [27207]={
        ["Aug2"]="AGI+12", 
        ["Aug3"]="Accuracy+20", 
        ["Aug1"]="DEX+12"
    }, 
    [27231]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [27234]={
        ["Aug1"]="Phalanx +3"
    }, 
    [27235]={
        ["Aug1"]="Path: A"
    }, 
    [27287]={
        ["Aug2"]="Mag. Acc.+15", 
        ["Aug3"]="\"Fast Cast\"+7", 
        ["Aug1"]="MP+80"
    }, 
    [27288]={
        ["Aug2"]="\"Cure\" spellcasting time -7%", 
        ["Aug3"]="Magic dmg. taken -3", 
        ["Aug1"]="Healing magic skill +20"
    }, 
    [27289]={
        ["Aug2"]="TP Bonus +250", 
        ["Aug1"]="Accuracy+4"
    }, 
    [27295]={
        ["Aug2"]="DEX+10", 
        ["Aug3"]="\"Dbl.Atk.\"+3", 
        ["Aug4"]="\"Triple Atk.\"+3", 
        ["Aug1"]="STR+10"
    }, 
    [27301]={
        ["Aug2"]="\"Store TP\"+5", 
        ["Aug3"]="\"Subtle Blow\"+8", 
        ["Aug1"]="HP+65"
    }, 
    [27303]={
        ["Aug2"]="\"Rapid Shot\"+13", 
        ["Aug3"]="Enmity-6", 
        ["Aug1"]="AGI+12"
    }, 
    [27318]={
        ["Aug2"]="AGI+12", 
        ["Aug3"]="Accuracy+20", 
        ["Aug1"]="DEX+12"
    }, 
    [27321]={
        ["Aug1"]="Path: B"
    }, 
    [27323]={
        ["Aug2"]="Pet: \"Mag.Atk.Bns.\"+25", 
        ["Aug3"]="Blood Pact Dmg.+8", 
        ["Aug1"]="Pet: Attack+25"
    }, 
    [27324]={
        ["Aug1"]="Enh. Ninj. Mag. Acc/Cast Time Red."
    }, 
    [27373]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [27375]={
        ["Aug2"]="Enmity+9", 
        ["Aug3"]="Potency of \"Cure\" effect received +15%", 
        ["Aug1"]="HP+105"
    }, 
    [27379]={
        ["Aug2"]="Pet: Accuracy+20", 
        ["Aug3"]="Pet: Damage taken -4%", 
        ["Aug1"]="Pet: HP+125"
    }, 
    [27381]={
        ["Aug2"]="Pet: \"Mag.Atk.Bns.\"+25", 
        ["Aug3"]="Blood Pact Dmg.+8", 
        ["Aug1"]="Pet: Attack+25"
    }, 
    [27383]={
        ["Aug2"]="Accuracy+10", 
        ["Aug3"]="Attack+4", 
        ["Aug1"]="\"Store TP\"+7"
    }, 
    [27404]={
        ["Aug2"]="Pet: \"Dbl. Atk.\"+5", 
        ["Aug3"]="Pet: Damage taken -4%", 
        ["Aug1"]="Pet: Attack+25 Pet: Rng.Atk.+25"
    }, 
    [27405]={
        ["Aug1"]="Path: A"
    }, 
    [27410]={
        ["Aug1"]="Path: A"
    }, 
    [27457]={
        ["Aug2"]="Enmity+7", 
        ["Aug3"]="Phys. dmg. taken -4", 
        ["Aug1"]="HP+80"
    }, 
    [27463]={
        ["Aug2"]="\"Cure\" spellcasting time -15%", 
        ["Aug3"]="\"Conserve MP\"+6", 
        ["Aug1"]="\"Cure\" potency +5%"
    }, 
    [27464]={
        ["Aug2"]="DEX+12", 
        ["Aug3"]="Phalanx +4", 
        ["Aug1"]="\"Mag.Atk.Bns.\"+13"
    }, 
    [27472]={
        ["Aug2"]="\"Store TP\"+5", 
        ["Aug3"]="\"Subtle Blow\"+8", 
        ["Aug1"]="HP+65"
    }, 
    [27493]={
        ["Aug1"]="Path: A"
    }, 
    [27494]={
        ["Aug2"]="Magic dmg. taken -5%", 
        ["Aug3"]="INT+9", 
        ["Aug1"]="\"Mag.Atk.Bns.\"+23"
    }, 
    [27496]={
        ["Aug2"]="Pet: \"Store TP\"+11", 
        ["Aug3"]="Pet: MND+2", 
        ["Aug4"]="Pet: \"Mag.Atk.Bns.\"+13", 
        ["Aug1"]="Pet: Accuracy+12 Pet: Rng. Acc.+12"
    }, 
    [27497]={
        ["Aug2"]="\"Fast Cast\"+6", 
        ["Aug3"]="CHR+1", 
        ["Aug4"]="\"Mag.Atk.Bns.\"+4", 
        ["Aug1"]="Mag. Acc.+3"
    }, 
    [27503]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [27685]={
        ["Aug1"]="Path: A"
    }, 
    [27721]={
        ["Aug1"]="Path: A"
    }, 
    [27764]={
        ["Aug2"]="Accuracy+15", 
        ["Aug3"]="Mag. Acc.+15", 
        ["Aug4"]="Magic dmg. taken -5%", 
        ["Aug1"]="DEX+10"
    }, 
    [27838]={
        ["Aug2"]="\"Mag.Atk.Bns.\"+12", 
        ["Aug3"]="\"Store TP\"+6", 
        ["Aug1"]="Rng.Atk.+20"
    }, 
    [27892]={
        ["Aug2"]="Enmity+9", 
        ["Aug3"]="Potency of \"Cure\" effect received +15%", 
        ["Aug1"]="HP+105"
    }, 
    [27923]={
        ["Aug2"]="Enmity+9", 
        ["Aug3"]="Potency of \"Cure\" effect received +15%", 
        ["Aug1"]="HP+105"
    }, 
    [27965]={
        ["Aug1"]="Path: A"
    }, 
    [27994]={
        ["Aug1"]="Path: A"
    }, 
    [28050]={
        ["Aug1"]="Phalanx +3"
    }, 
    [28121]={
        ["Aug2"]="\"Mag.Atk.Bns.\"+12", 
        ["Aug3"]="\"Store TP\"+6", 
        ["Aug1"]="Rng.Atk.+20"
    }, 
    [28135]={
        ["Aug1"]="Path: A"
    }, 
    [28137]={
        ["Aug1"]="Path: A"
    }, 
    [28148]={
        ["Aug2"]="\"Fast Cast\"+10", 
        ["Aug3"]="Haste+2%", 
        ["Aug1"]="MP+50"
    }, 
    [28179]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [28191]={
        ["Aug2"]="Mag. Acc.+5", 
        ["Aug3"]="Attack+3", 
        ["Aug4"]="Breath dmg. taken -2%", 
        ["Aug1"]="MND+5"
    }, 
    [28254]={
        ["Aug2"]="\"Mag.Atk.Bns.\"+12", 
        ["Aug3"]="\"Store TP\"+6", 
        ["Aug1"]="Rng.Atk.+20"
    }, 
    [28274]={
        ["Aug1"]="Path: A"
    }, 
    [28276]={
        ["Aug1"]="Path: A"
    }, 
    [28292]={
        ["Aug5"]="Phys. dmg. taken-10%", 
        ["Aug2"]="Accuracy+20 Attack+20", 
        ["Aug1"]="DEX+20", 
        ["Aug4"]="\"Store TP\"+10", 
        ["Aug3"]="Accuracy+10"
    }, 
    [28316]={
        ["Aug1"]="Path: A"
    }
}